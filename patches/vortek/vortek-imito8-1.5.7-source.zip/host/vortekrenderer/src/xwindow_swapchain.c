#include "xwindow_swapchain.h"
#include "vulkan_helper.h"
#include "linear_buffer_import.h"

void reportSwapchainStartup(JMethods* methods, int stage, VkResult result,
        VkFormat format, VkExtent2D extent, int windowId) {
    // Do not disturb a Java allocation exception already propagating to the
    // caller. No paths, messages or per-frame logging cross this callback.
    if (!methods->recordSwapchainStartup || (*methods->env)->ExceptionCheck(methods->env)) return;
    (*methods->env)->CallVoidMethod(methods->env, methods->obj, methods->recordSwapchainStartup,
            stage, (int)result, (int)format, (int)extent.width, (int)extent.height, windowId);
    // Only an exception raised by this diagnostic callback is discarded.
    // The early guard above preserves any original renderer exception.
    if ((*methods->env)->ExceptionCheck(methods->env)) (*methods->env)->ExceptionClear(methods->env);
}

static VkResult failedSwapchainStep(XWindowSwapchain* swapchain, int stage, VkResult result) {
    reportSwapchainStartup(swapchain->jmethods, stage, result,
            swapchain->imageFormat, swapchain->imageExtent, swapchain->windowId);
    return result;
}

void getWindowExtent(JMethods* jmethods, int windowId, VkExtent2D* extent) {
    extent->width = (*jmethods->env)->CallIntMethod(jmethods->env, jmethods->obj, jmethods->getWindowWidth, windowId);
    extent->height = (*jmethods->env)->CallIntMethod(jmethods->env, jmethods->obj, jmethods->getWindowHeight, windowId);
}

static uint32_t localMemoryType(VkPhysicalDevice physical,uint32_t bits);

static VkResult createImageMemory(VkPhysicalDevice physical, VkDevice device, XWindowSwapchain* swapchain, VkImage image, AHardwareBuffer* hardwareBuffer, VkDeviceMemory* pMemory) {
    VkAndroidHardwareBufferPropertiesANDROID ahbProperties = {0};
    ahbProperties.sType = VK_STRUCTURE_TYPE_ANDROID_HARDWARE_BUFFER_PROPERTIES_ANDROID;
    VkResult result = vulkanWrapper.vkGetAndroidHardwareBufferPropertiesANDROID(device, hardwareBuffer, &ahbProperties);
    if (result != VK_SUCCESS) return failedSwapchainStep(swapchain, SWAPCHAIN_AHB_PROPERTIES, result);

    VkImportAndroidHardwareBufferInfoANDROID memoryImportInfo = {0};
    memoryImportInfo.sType = VK_STRUCTURE_TYPE_IMPORT_ANDROID_HARDWARE_BUFFER_INFO_ANDROID;
    memoryImportInfo.buffer = hardwareBuffer;

    VkMemoryDedicatedAllocateInfo memoryDedicatedInfo = {0};
    memoryDedicatedInfo.sType = VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO;
    memoryDedicatedInfo.pNext = &memoryImportInfo;
    memoryDedicatedInfo.image = image;
    memoryDedicatedInfo.buffer = VK_NULL_HANDLE;

    VkMemoryAllocateInfo memoryInfo = {0};
    memoryInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    memoryInfo.pNext = &memoryDedicatedInfo;
    memoryInfo.allocationSize = ahbProperties.allocationSize;
    memoryInfo.memoryTypeIndex = localMemoryType(physical, ahbProperties.memoryTypeBits);
    // Device-local memory is preferred, but an imported AHB may only allow
    // another type. Never fall back to an index absent from the import mask.
    if (memoryInfo.memoryTypeIndex == UINT32_MAX) return failedSwapchainStep(swapchain, SWAPCHAIN_MEMORY_TYPE, VK_ERROR_OUT_OF_DEVICE_MEMORY);

    VkDeviceMemory memory;
    result = vulkanWrapper.vkAllocateMemory(device, &memoryInfo, NULL, &memory);
    if (result != VK_SUCCESS) return failedSwapchainStep(swapchain, SWAPCHAIN_MEMORY_ALLOCATE, result);

    result = vulkanWrapper.vkBindImageMemory(device, image, memory, 0);
    if (result != VK_SUCCESS) {
        vulkanWrapper.vkFreeMemory(device, memory, NULL);
        return failedSwapchainStep(swapchain, SWAPCHAIN_MEMORY_BIND, result);
    }

    *pMemory = memory;
    return VK_SUCCESS;
}

static uint32_t localMemoryType(VkPhysicalDevice physical,uint32_t bits) {
    VkPhysicalDeviceMemoryProperties properties={0};
    vulkanWrapper.vkGetPhysicalDeviceMemoryProperties(physical,&properties);
    for(unsigned preferred=1;preferred!=(unsigned)-1;preferred--)
        for(uint32_t i=0;i<properties.memoryTypeCount && i<32;i++)
            if((bits&(1u<<i)) && (!preferred || (properties.memoryTypes[i].propertyFlags&VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)))return i;
    return UINT32_MAX;
}

static VkResult createPrivateImage(VkPhysicalDevice physical,VkDevice device,XWindowSwapchain* swapchain,
        const VkSwapchainCreateInfoKHR* requested,XWindowSwapchain_Image* output) {
    VkImageFormatListCreateInfo* requestedFormats=findNextVkStructure((void*)requested->pNext,VK_STRUCTURE_TYPE_IMAGE_FORMAT_LIST_CREATE_INFO);
    VkImageFormatListCreateInfo formats={0};
    if(requestedFormats){formats=*requestedFormats;formats.pNext=NULL;}
    VkImageCreateInfo info={.sType=VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
        .pNext=requestedFormats?&formats:NULL,.imageType=VK_IMAGE_TYPE_2D,
        .format=swapchain->imageFormat,.extent={swapchain->imageExtent.width,swapchain->imageExtent.height,1},
        .mipLevels=1,.arrayLayers=1,.samples=VK_SAMPLE_COUNT_1_BIT,.tiling=VK_IMAGE_TILING_OPTIMAL,
        .usage=swapchain->imageUsage|VK_IMAGE_USAGE_TRANSFER_SRC_BIT,.sharingMode=requested->imageSharingMode,
        .queueFamilyIndexCount=requested->queueFamilyIndexCount,.pQueueFamilyIndices=requested->pQueueFamilyIndices,
        .initialLayout=VK_IMAGE_LAYOUT_UNDEFINED};
    if(requested->flags&VK_SWAPCHAIN_CREATE_MUTABLE_FORMAT_BIT_KHR)
        info.flags=VK_IMAGE_CREATE_MUTABLE_FORMAT_BIT|VK_IMAGE_CREATE_EXTENDED_USAGE_BIT;
    VkResult result=vulkanWrapper.vkCreateImage(device,&info,NULL,&output->image);
    if(result!=VK_SUCCESS)return failedSwapchainStep(swapchain,SWAPCHAIN_IMAGE,result);
    VkMemoryRequirements requirements={0};vulkanWrapper.vkGetImageMemoryRequirements(device,output->image,&requirements);
    uint32_t type=localMemoryType(physical,requirements.memoryTypeBits);
    if(type==UINT32_MAX)return failedSwapchainStep(swapchain,SWAPCHAIN_MEMORY_TYPE,VK_ERROR_OUT_OF_DEVICE_MEMORY);
    VkMemoryDedicatedAllocateInfo dedicated={.sType=VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO,.image=output->image};
    VkMemoryAllocateInfo allocation={.sType=VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,.pNext=&dedicated,
        .allocationSize=requirements.size,.memoryTypeIndex=type};
    result=vulkanWrapper.vkAllocateMemory(device,&allocation,NULL,&output->memory);
    if(result!=VK_SUCCESS)return failedSwapchainStep(swapchain,SWAPCHAIN_MEMORY_ALLOCATE,result);
    result=vulkanWrapper.vkBindImageMemory(device,output->image,output->memory,0);
    return result==VK_SUCCESS?result:failedSwapchainStep(swapchain,SWAPCHAIN_MEMORY_BIND,result);
}

static VkFormat nativeAhbFormat(VkPhysicalDevice physical, VkFormat requested) {
    if (requested != VK_FORMAT_B8G8R8A8_UNORM && requested != VK_FORMAT_B8G8R8A8_SRGB) return requested;
    // On this Mali-G615, PanVK's native BGRA buffer presents red as blue in
    // GLES. Keep the guest format and convert to RGBA for Android presentation.
    VkPhysicalDeviceProperties gpu;
    vulkanWrapper.vkGetPhysicalDeviceProperties(physical, &gpu);
    if (gpu.vendorID != 0x13b5 || gpu.deviceID != 0xb8a31030 || gpu.apiVersion < VK_API_VERSION_1_2 ||
        !vulkanWrapper.vkGetPhysicalDeviceProperties2 || !vulkanWrapper.vkCmdBlitImage) return requested;
    VkPhysicalDeviceDriverProperties driver = {.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRIVER_PROPERTIES};
    VkPhysicalDeviceProperties2 properties = {.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2,.pNext=&driver};
    vulkanWrapper.vkGetPhysicalDeviceProperties2(physical, &properties);
    if (driver.driverID != VK_DRIVER_ID_MESA_PANVK) return requested;
    VkFormat rgba = requested == VK_FORMAT_B8G8R8A8_SRGB ? VK_FORMAT_R8G8B8A8_SRGB : VK_FORMAT_R8G8B8A8_UNORM;
    VkFormatProperties src, dst;
    vulkanWrapper.vkGetPhysicalDeviceFormatProperties(physical, requested, &src);
    vulkanWrapper.vkGetPhysicalDeviceFormatProperties(physical, rgba, &dst);
    if (!(src.optimalTilingFeatures & VK_FORMAT_FEATURE_BLIT_SRC_BIT) ||
        !(dst.optimalTilingFeatures & VK_FORMAT_FEATURE_BLIT_DST_BIT)) return requested;
    return rgba;
}

static VkResult createSharedImage(VkPhysicalDevice physical,XWindowSwapchain* swapchain,bool linearDma) {
    uint32_t format=(swapchain->imageFormat==VK_FORMAT_B8G8R8A8_UNORM || swapchain->imageFormat==VK_FORMAT_B8G8R8A8_SRGB)?5:1;
    const VkImageUsageFlags usage=VK_IMAGE_USAGE_TRANSFER_DST_BIT|VK_IMAGE_USAGE_SAMPLED_BIT|VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    FreshLinearBuffer* b=&swapchain->sharedBuffer;
    if(linearDma) {
        GetAhbHandle getHandle=(void*)dlsym(RTLD_DEFAULT,"AHardwareBuffer_getNativeHandle");
        if(!freshLinearBufferCreate(swapchain->imageExtent.width,swapchain->imageExtent.height,format,getHandle,b))
            return failedSwapchainStep(swapchain,SWAPCHAIN_AHB,VK_ERROR_INVALID_EXTERNAL_HANDLE);
        LinearBufferDispatch dispatch={
            .getImageProperties=vulkanWrapper.vkGetPhysicalDeviceImageFormatProperties2,
            .createImage=vulkanWrapper.vkCreateImage,.destroyImage=vulkanWrapper.vkDestroyImage,
            .getImageRequirements=vulkanWrapper.vkGetImageMemoryRequirements,
            .getFdProperties=(void*)vulkanWrapper.vkGetDeviceProcAddr(swapchain->device,"vkGetMemoryFdPropertiesKHR"),
            .allocateMemory=vulkanWrapper.vkAllocateMemory,.freeMemory=vulkanWrapper.vkFreeMemory,
            .bindImageMemory=vulkanWrapper.vkBindImageMemory};
        LinearBufferLayout layout={b->fd,b->bytes,b->width,b->height,b->pitch,b->format};
        VkResult result=importLinearBufferImage(&dispatch,physical,swapchain->device,&layout,swapchain->imageFormat,
            usage,0,&swapchain->sharedImage,&swapchain->sharedMemory);
        return result==VK_SUCCESS?result:failedSwapchainStep(swapchain,SWAPCHAIN_MEMORY_ALLOCATE,result);
    }
    VkFormat sharedFormat = nativeAhbFormat(physical, swapchain->imageFormat);
    swapchain->blitToRgba = sharedFormat != swapchain->imageFormat;
    if (swapchain->blitToRgba) format = AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM;
    AHardwareBuffer_Desc desc={.width=swapchain->imageExtent.width,.height=swapchain->imageExtent.height,
        .layers=1,.format=format,.usage=AHARDWAREBUFFER_USAGE_GPU_COLOR_OUTPUT|AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE};
    if(AHardwareBuffer_allocate(&desc,&b->buffer)!=0)return failedSwapchainStep(swapchain,SWAPCHAIN_AHB,VK_ERROR_OUT_OF_DEVICE_MEMORY);
    VkExternalMemoryImageCreateInfo external={.sType=VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_IMAGE_CREATE_INFO,
        .handleTypes=VK_EXTERNAL_MEMORY_HANDLE_TYPE_ANDROID_HARDWARE_BUFFER_BIT_ANDROID};
    VkImageCreateInfo info={.sType=VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,.pNext=&external,.imageType=VK_IMAGE_TYPE_2D,
        .format=sharedFormat,.extent={desc.width,desc.height,1},.mipLevels=1,.arrayLayers=1,
        .samples=VK_SAMPLE_COUNT_1_BIT,.tiling=VK_IMAGE_TILING_OPTIMAL,.usage=usage,
        .sharingMode=VK_SHARING_MODE_EXCLUSIVE,.initialLayout=VK_IMAGE_LAYOUT_UNDEFINED};
    VkResult result=vulkanWrapper.vkCreateImage(swapchain->device,&info,NULL,&swapchain->sharedImage);
    if(result!=VK_SUCCESS)return failedSwapchainStep(swapchain,SWAPCHAIN_IMAGE,result);
    return createImageMemory(physical,swapchain->device,swapchain,swapchain->sharedImage,b->buffer,&swapchain->sharedMemory);
}

int getSurfaceMinImageCount() {
    return 1;
}

XWindowSwapchain* XWindowSwapchain_create(VkPhysicalDevice physical,VkDevice device,uint32_t graphicsQueueIndex,
        VkSwapchainCreateInfoKHR* swapchainInfo,JMethods* jmethods,int windowId,bool linearDma) {
    if(!swapchainInfo->minImageCount || swapchainInfo->minImageCount>8 || swapchainInfo->imageArrayLayers!=1 ||
            (swapchainInfo->flags&VK_SWAPCHAIN_CREATE_PROTECTED_BIT_KHR))return NULL;
    XWindowSwapchain* swapchain=calloc(1,sizeof(*swapchain));if(!swapchain)return NULL;
    swapchain->sharedBuffer.fd=-1;swapchain->device=device;swapchain->windowId=windowId;
    swapchain->imageCount=swapchainInfo->minImageCount;swapchain->imageFormat=swapchainInfo->imageFormat;
    swapchain->imageUsage=swapchainInfo->imageUsage;swapchain->imageExtent=swapchainInfo->imageExtent;
    swapchain->jmethods=jmethods;swapchain->graphicsFamily=graphicsQueueIndex;
    swapchain->images=calloc(swapchain->imageCount,sizeof(*swapchain->images));
    if(!swapchain->images)goto error;
    for(int i=0;i<swapchain->imageCount;i++)
        if(createPrivateImage(physical,device,swapchain,swapchainInfo,&swapchain->images[i])!=VK_SUCCESS)goto error;
    if(createSharedImage(physical,swapchain,linearDma)!=VK_SUCCESS)goto error;
    JNIEnv* env=jmethods->env;
    swapchain->javaAttached=(*env)->CallBooleanMethod(env,jmethods->obj,jmethods->attachWindowHardwareBuffer,
        windowId,(int)swapchain->imageFormat,(jlong)(uintptr_t)swapchain->sharedBuffer.buffer);
    if((*env)->ExceptionCheck(env)) {(*env)->ExceptionClear(env);swapchain->javaAttached=false;}
    if(!swapchain->javaAttached)goto error;
    vulkanWrapper.vkGetDeviceQueue(device,graphicsQueueIndex,0,&swapchain->queue);
    reportSwapchainStartup(jmethods,SWAPCHAIN_READY,VK_SUCCESS,swapchain->imageFormat,swapchain->imageExtent,windowId);
    return swapchain;
error:
    XWindowSwapchain_destroy(device,swapchain);return NULL;
}

void XWindowSwapchain_destroy(VkDevice device,XWindowSwapchain* swapchain) {
    if(!swapchain || swapchain->presentFencePending)return;
    if(swapchain->presentFence)vulkanWrapper.vkDestroyFence(device,swapchain->presentFence,NULL);
    if(swapchain->copyPool)vulkanWrapper.vkDestroyCommandPool(device,swapchain->copyPool,NULL);
    if(swapchain->images)for(int i=0;i<swapchain->imageCount;i++) {
        if(swapchain->images[i].image)vulkanWrapper.vkDestroyImage(device,swapchain->images[i].image,NULL);
        if(swapchain->images[i].memory)vulkanWrapper.vkFreeMemory(device,swapchain->images[i].memory,NULL);
    }
    if(swapchain->sharedImage)vulkanWrapper.vkDestroyImage(device,swapchain->sharedImage,NULL);
    if(swapchain->sharedMemory)vulkanWrapper.vkFreeMemory(device,swapchain->sharedMemory,NULL);
    if(swapchain->javaAttached) {
        JMethods* m=swapchain->jmethods;
        (*m->env)->CallVoidMethod(m->env,m->obj,m->releaseWindowHardwareBuffer,(jlong)(uintptr_t)swapchain->sharedBuffer.buffer);
        if((*m->env)->ExceptionCheck(m->env))(*m->env)->ExceptionClear(m->env);
    }
    freshLinearBufferDestroy(&swapchain->sharedBuffer);
    free(swapchain->images);free(swapchain);
}

VkResult XWindowSwapchain_acquireNextImage(XWindowSwapchain* swapchain,uint64_t timeout,VkSemaphore signalSemaphore,
        VkFence fence,uint32_t* imageIndex) {
    if(!swapchain || !imageIndex || swapchain->presentFencePending)return VK_ERROR_DEVICE_LOST;
    VkExtent2D size;getWindowExtent(swapchain->jmethods,swapchain->windowId,&size);
    if(size.width!=swapchain->imageExtent.width || size.height!=swapchain->imageExtent.height)return VK_ERROR_OUT_OF_DATE_KHR;
    uint32_t selected=UINT32_MAX;
    for(uint32_t n=0;n<(uint32_t)swapchain->imageCount;n++) {
        uint32_t i=(swapchain->nextAcquire+n)%swapchain->imageCount;
        if(!swapchain->images[i].acquired){selected=i;break;}
    }
    if(selected==UINT32_MAX)return timeout?VK_TIMEOUT:VK_NOT_READY;
    if(signalSemaphore || fence) {
        VkSubmitInfo submit={.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO,
            .signalSemaphoreCount=signalSemaphore?1:0,.pSignalSemaphores=signalSemaphore?&signalSemaphore:NULL};
        VkResult result=vulkanWrapper.vkQueueSubmit(swapchain->queue,1,&submit,fence);
        if(result!=VK_SUCCESS) {
            if(!swapchain->acquireFailureReported){swapchain->acquireFailureReported=true;failedSwapchainStep(swapchain,SWAPCHAIN_ACQUIRE_SUBMIT,result);}
            return result;
        }
    }
    swapchain->images[selected].acquired=true;swapchain->nextAcquire=(selected+1)%swapchain->imageCount;
    *imageIndex=selected;return VK_SUCCESS;
}

static VkResult preparePresentCopy(XWindowSwapchain* s,uint32_t family,uint32_t index) {
    if(index >= (uint32_t)s->imageCount || index >= ARRAY_SIZE(s->copyCommands))
        return VK_ERROR_OUT_OF_DATE_KHR;
    // The caller has completed the preceding copy fence before coming here.
    // Each private image and the shared destination are immutable for this
    // swapchain. Record their copy/barriers once, not on every game frame.
    // The first submission needs UNDEFINED -> GENERAL; retire that recording
    // after completion so later copies preserve the external ownership/layout.
    if(s->copyPool && (s->copyFamily!=family || s->copyCommandsInitialized!=s->sharedInitialized)) {
        vulkanWrapper.vkDestroyCommandPool(s->device,s->copyPool,NULL);s->copyPool=VK_NULL_HANDLE;s->copyCommand=VK_NULL_HANDLE;
        memset(s->copyCommands,0,sizeof(s->copyCommands));
    }
    VkResult result;
    if(!s->copyPool) {
        VkCommandPoolCreateInfo pool={.sType=VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,.queueFamilyIndex=family};
        result=vulkanWrapper.vkCreateCommandPool(s->device,&pool,NULL,&s->copyPool);if(result!=VK_SUCCESS)return result;
        s->copyFamily=family;
        s->copyCommandsInitialized=s->sharedInitialized;
    }
    if(s->copyCommands[index]) {
        s->copyCommand=s->copyCommands[index];
        return VK_SUCCESS;
    }
    VkCommandBufferAllocateInfo allocate={.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,.commandPool=s->copyPool,
        .level=VK_COMMAND_BUFFER_LEVEL_PRIMARY,.commandBufferCount=1};
    result=vulkanWrapper.vkAllocateCommandBuffers(s->device,&allocate,&s->copyCommand);if(result!=VK_SUCCESS)return result;
    // A completed command remains executable. ONE_TIME_SUBMIT would invalidate
    // it and SIMULTANEOUS_USE is unnecessary: present still waits its fence.
    VkCommandBufferBeginInfo begin={.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    result=vulkanWrapper.vkBeginCommandBuffer(s->copyCommand,&begin);if(result!=VK_SUCCESS)goto recordingFailed;
    VkImageSubresourceRange range={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
    VkImageMemoryBarrier barriers[2]={
        {.sType=VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,.srcAccessMask=VK_ACCESS_MEMORY_WRITE_BIT,.dstAccessMask=VK_ACCESS_TRANSFER_READ_BIT,
         .oldLayout=VK_IMAGE_LAYOUT_GENERAL,.newLayout=VK_IMAGE_LAYOUT_GENERAL,.srcQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED,
         .dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED,.image=s->images[index].image,.subresourceRange=range},
        {.sType=VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,.dstAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT,
         .oldLayout=s->sharedInitialized?VK_IMAGE_LAYOUT_GENERAL:VK_IMAGE_LAYOUT_UNDEFINED,.newLayout=VK_IMAGE_LAYOUT_GENERAL,
         .srcQueueFamilyIndex=VK_QUEUE_FAMILY_FOREIGN_EXT,.dstQueueFamilyIndex=family,.image=s->sharedImage,.subresourceRange=range}};
    vulkanWrapper.vkCmdPipelineBarrier(s->copyCommand,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,
        0,0,NULL,0,NULL,2,barriers);
    VkImageCopy copy={.srcSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1},.dstSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1},
        .extent={s->imageExtent.width,s->imageExtent.height,1}};
    if (s->blitToRgba) {
        VkOffset3D end = {(int32_t)s->imageExtent.width,(int32_t)s->imageExtent.height,1};
        VkImageBlit blit = {.srcSubresource=copy.srcSubresource,.dstSubresource=copy.dstSubresource,
            .srcOffsets={{0,0,0},end},.dstOffsets={{0,0,0},end}};
        vulkanWrapper.vkCmdBlitImage(s->copyCommand,s->images[index].image,VK_IMAGE_LAYOUT_GENERAL,
            s->sharedImage,VK_IMAGE_LAYOUT_GENERAL,1,&blit,VK_FILTER_NEAREST);
    } else {
        vulkanWrapper.vkCmdCopyImage(s->copyCommand,s->images[index].image,VK_IMAGE_LAYOUT_GENERAL,
            s->sharedImage,VK_IMAGE_LAYOUT_GENERAL,1,&copy);
    }
    VkImageMemoryBarrier release=barriers[1];release.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;release.dstAccessMask=0;
    release.oldLayout=VK_IMAGE_LAYOUT_GENERAL;release.srcQueueFamilyIndex=family;release.dstQueueFamilyIndex=VK_QUEUE_FAMILY_FOREIGN_EXT;
    vulkanWrapper.vkCmdPipelineBarrier(s->copyCommand,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
        0,0,NULL,0,NULL,1,&release);
    result=vulkanWrapper.vkEndCommandBuffer(s->copyCommand);
    if(result==VK_SUCCESS) {
        s->copyCommands[index]=s->copyCommand;
        return VK_SUCCESS;
    }
recordingFailed:
    // Nothing from this pool is pending here. Do not cache an incomplete
    // recording or retain its allocation when a driver rejects recording.
    vulkanWrapper.vkDestroyCommandPool(s->device,s->copyPool,NULL);
    s->copyPool=VK_NULL_HANDLE;s->copyCommand=VK_NULL_HANDLE;
    memset(s->copyCommands,0,sizeof(s->copyCommands));
    return result;
}

static VkResult failedPresentStep(XWindowSwapchain* swapchain, int stage, VkResult result) {
    if (!swapchain->presentFailureReported) {
        swapchain->presentFailureReported = true;
        failedSwapchainStep(swapchain, stage, result);
    }
    return result;
}

static VkResult awaitPresentationRead(XWindowSwapchain* swapchain,const _Atomic VkResult* contextStatus) {
    JMethods* m=swapchain->jmethods;
    VkResult result;
    do {
        result=(*m->env)->CallIntMethod(m->env,m->obj,m->awaitWindowContent,
            (jlong)(uintptr_t)swapchain->sharedBuffer.buffer,*contextStatus<0?JNI_TRUE:JNI_FALSE);
        if((*m->env)->ExceptionCheck(m->env)){(*m->env)->ExceptionClear(m->env);result=VK_ERROR_DEVICE_LOST;}
    } while(result==VK_NOT_READY);
    return result;
}

VkResult XWindowSwapchain_waitForPresent(VkQueue queue, uint32_t queueFamily, const VkPresentInfoKHR* presentInfo,
        const _Atomic VkResult* contextStatus) {
    if (!queue || queueFamily==UINT32_MAX || !presentInfo->swapchainCount || !presentInfo->pSwapchains ||
            !presentInfo->pImageIndices || (presentInfo->waitSemaphoreCount && !presentInfo->pWaitSemaphores))
        return VK_ERROR_INITIALIZATION_FAILED;
    XWindowSwapchain* first = (XWindowSwapchain*)presentInfo->pSwapchains[0];
    if (!first) return VK_ERROR_INITIALIZATION_FAILED;
    // Validate the complete batch before consuming any render-finished signal.
    for (uint32_t i=0; i<presentInfo->swapchainCount; ++i) {
        XWindowSwapchain* swapchain = (XWindowSwapchain*)presentInfo->pSwapchains[i];
        if (!swapchain || swapchain->device != first->device || !swapchain->imageCount ||
                presentInfo->pImageIndices[i] >= (uint32_t)swapchain->imageCount ||
                !swapchain->images[presentInfo->pImageIndices[i]].acquired)
            return failedPresentStep(first, SWAPCHAIN_PRESENT_INDEX, VK_ERROR_OUT_OF_DATE_KHR);
        for(uint32_t previous=0;previous<i;previous++)if(presentInfo->pSwapchains[previous]==presentInfo->pSwapchains[i])
            return failedPresentStep(first,SWAPCHAIN_PRESENT_INDEX,VK_ERROR_OUT_OF_DATE_KHR);
    }
    if (*contextStatus < 0 || first->presentFencePending) return VK_ERROR_DEVICE_LOST;
    VkResult result;
    // The preceding Present may still be copying this AHB into the compositor
    // snapshot. Overlap that GL work with the next private game image, but
    // never submit a write to shared storage until its read has completed.
    for(uint32_t i=0;i<presentInfo->swapchainCount;i++) {
        XWindowSwapchain* s=(XWindowSwapchain*)presentInfo->pSwapchains[i];
        result=awaitPresentationRead(s,contextStatus);
        if(result!=VK_SUCCESS)return failedPresentStep(s,SWAPCHAIN_PRESENT_GLES,result);
    }
    if (!first->presentFence) {
        VkFenceCreateInfo info = { .sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO };
        result = vulkanWrapper.vkCreateFence(first->device, &info, NULL, &first->presentFence);
    } else result = vulkanWrapper.vkResetFences(first->device, 1, &first->presentFence);
    if (result != VK_SUCCESS) return failedPresentStep(first, SWAPCHAIN_PRESENT_FENCE, result);

    VkPipelineStageFlags* stages = presentInfo->waitSemaphoreCount ?
            calloc(presentInfo->waitSemaphoreCount, sizeof(*stages)) : NULL;
    if (presentInfo->waitSemaphoreCount && !stages) return VK_ERROR_OUT_OF_HOST_MEMORY;
    for (uint32_t i=0; i<presentInfo->waitSemaphoreCount; ++i) stages[i] = VK_PIPELINE_STAGE_ALL_COMMANDS_BIT;
    VkCommandBuffer* commands=calloc(presentInfo->swapchainCount,sizeof(*commands));
    if(!commands){free(stages);return VK_ERROR_OUT_OF_HOST_MEMORY;}
    for(uint32_t i=0;i<presentInfo->swapchainCount;i++) {
        XWindowSwapchain* s=(XWindowSwapchain*)presentInfo->pSwapchains[i];
        result=preparePresentCopy(s,queueFamily,presentInfo->pImageIndices[i]);
        if(result!=VK_SUCCESS){free(commands);free(stages);return failedPresentStep(s,SWAPCHAIN_PRESENT_COPY,result);}
        commands[i]=s->copyCommand;
    }
    VkSubmitInfo submit = { .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .commandBufferCount=presentInfo->swapchainCount,.pCommandBuffers=commands,
        .waitSemaphoreCount = presentInfo->waitSemaphoreCount,
        .pWaitSemaphores = presentInfo->pWaitSemaphores, .pWaitDstStageMask = stages };
    // Consume each binary render-finished semaphore exactly once for the entire
    // present batch. Otherwise its next signal is invalid (VUID00067).
    // The context's single request thread also owns all normal queue submits.
    result = vulkanWrapper.vkQueueSubmit(queue, 1, &submit, first->presentFence);
    free(commands);free(stages);
    if (result != VK_SUCCESS) return failedPresentStep(first, SWAPCHAIN_PRESENT_SUBMIT, result);
    first->presentFencePending = true;
    // GLES cannot import this VkFence. Publish only after the submitted waits
    // complete, without draining unrelated later work with QueueWaitIdle.
    // Fifty-ms slices let session shutdown interrupt a never-signalled present;
    // a five-second watchdog retires this virtual device instead of hanging it.
    for (unsigned slice=0; slice<100; ++slice) {
        if (*contextStatus < 0) return VK_ERROR_DEVICE_LOST;
        result = vulkanWrapper.vkWaitForFences(first->device, 1, &first->presentFence, VK_TRUE, 50000000ULL);
        if (result == VK_SUCCESS) {
            first->presentFencePending=false;
            for(uint32_t i=0;i<presentInfo->swapchainCount;i++)((XWindowSwapchain*)presentInfo->pSwapchains[i])->sharedInitialized=true;
            return VK_SUCCESS;
        }
        if (result != VK_TIMEOUT) return failedPresentStep(first, SWAPCHAIN_PRESENT_WAIT, result);
    }
    // A pending fence is retained until normal swapchain/device teardown. Never
    // reset/free it while its submission can still be in flight. The distinct
    // stage identifies our watchdog, not a driver-returned DEVICE_LOST.
    return failedPresentStep(first, SWAPCHAIN_PRESENT_TIMEOUT, VK_ERROR_DEVICE_LOST);
}

VkResult XWindowSwapchain_presentImage(XWindowSwapchain* swapchain,uint32_t index) {
    JMethods* m=swapchain->jmethods;
    VkResult result=(*m->env)->CallIntMethod(m->env,m->obj,m->updateWindowContent,
        swapchain->windowId,(jlong)(uintptr_t)swapchain->sharedBuffer.buffer);
    if((*m->env)->ExceptionCheck(m->env)){(*m->env)->ExceptionClear(m->env);result=VK_ERROR_DEVICE_LOST;}
    if(result!=VK_SUCCESS)return failedPresentStep(swapchain,SWAPCHAIN_PRESENT_GLES,result);
    swapchain->images[index].acquired=false;
    // Java reports FIRST_PRESENT only after the asynchronous GL copy succeeds.
    return VK_SUCCESS;
}
