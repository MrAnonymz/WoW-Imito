package com.winlator.renderer;

import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLES30;

import com.winlator.xserver.Drawable;

import java.nio.ByteBuffer;

public class Texture {
    protected int textureId = 0;
    protected int wrapS = GLES20.GL_CLAMP_TO_EDGE;
    protected int wrapT = GLES20.GL_CLAMP_TO_EDGE;
    protected int magFilter = GLES20.GL_LINEAR;
    protected int minFilter = GLES20.GL_LINEAR;
    protected int format = GLES11Ext.GL_BGRA;
    protected boolean needsUpdate = true;
    private short copiedWidth, copiedHeight;
    // Access under Drawable.renderLock, with a current context in its share group.
    // CPU exclusion alone does not order GPU commands in different contexts.
    private boolean sharedCopy;
    private boolean copiedFromFramebuffer;
    private long sharedFence;
    private boolean flipY = false;
    protected Drawable owner;

    public Texture(Drawable owner) {
        this.owner = owner;
    }

    protected void generateTextureId() {
        int[] textureIds = new int[1];
        GLES20.glGenTextures(1, textureIds, 0);
        textureId = textureIds[0];
    }

    protected void setTextureParameters() {
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, wrapS);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, wrapT);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, magFilter);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, minFilter);
    }

    public void allocateTexture(short width, short height, ByteBuffer data) {
        generateTextureId();
        copiedWidth = copiedHeight = 0;

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);

        if (data != null) {
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, format, width, height, 0, format, GLES20.GL_UNSIGNED_BYTE, data);
            needsUpdate = false;
        }

        setTextureParameters();
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
    }

    public Drawable getOwner() {
        return owner;
    }

    public void setOwner(Drawable owner) {
        this.owner = owner;
    }

    public boolean isFlipY() {
        return flipY;
    }

    public void setFlipY(boolean flipY) {
        this.flipY = flipY;
    }

    public int getWrapS() {
        return wrapS;
    }

    public void setWrapS(int wrapS) {
        this.wrapS = wrapS;
    }

    public int getWrapT() {
        return wrapT;
    }

    public void setWrapT(int wrapT) {
        this.wrapT = wrapT;
    }

    public int getMagFilter() {
        return magFilter;
    }

    public void setMagFilter(int magFilter) {
        this.magFilter = magFilter;
    }

    public int getMinFilter() {
        return minFilter;
    }

    public void setMinFilter(int minFilter) {
        this.minFilter = minFilter;
    }

    public int getFormat() {
        return format;
    }

    public void setFormat(int format) {
        this.format = format;
    }

    public boolean isNeedsUpdate() {
        return needsUpdate;
    }

    public boolean isSharedFramebufferCopy() {
        return copiedFromFramebuffer && sharedCopy;
    }

    public void setNeedsUpdate(boolean needsUpdate) {
        this.needsUpdate = needsUpdate;
    }

    public void updateFromDrawable() {
        if (owner == null || owner.getData() == null) return;

        ByteBuffer data = owner.getData();
        if (!isAllocated()) {
            allocateTexture(owner.width, owner.height, data);
        }
        else if (needsUpdate) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
            GLES20.glTexSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, owner.width, owner.height, format, GLES20.GL_UNSIGNED_BYTE, data);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
            needsUpdate = false;
        }
    }

    public boolean isAllocated() {
        return textureId > 0;
    }

    public int getTextureId() {
        return textureId;
    }

    public boolean copyFromReadBuffer(short width, short height) {
        return copyFromReadBuffer(width, height, true);
    }

    /** Vortek's snapshot and every compositor read run on the renderer's GL
     * context. Its command order already protects this destination texture;
     * the separate GPUImage fence still protects the cross-API source AHB. */
    public boolean copyFromReadBufferOnRendererContext(short width, short height) {
        return copyFromReadBuffer(width, height, false);
    }

    private boolean copyFromReadBuffer(short width, short height, boolean crossContext) {
        if (width <= 0 || height <= 0) return false;
        if ((!copiedFromFramebuffer || (crossContext && !sharedCopy)) && isAllocated()) {
            // A previously software-rendered window may still be sampled by the
            // compositor. A switch from renderer-only storage to another
            // producer context needs a fresh name for the same reason.
            deleteTextureName();
        }
        if (!isAllocated()) allocateTexture(width, height, null);
        copiedFromFramebuffer = true;
        beginSharedAccess();
        sharedCopy = crossContext;
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
        boolean storageReady = true;
        if (copiedWidth != width || copiedHeight != height) {
            // An incomplete first framebuffer leaves level 0 undefined. Retrying
            // with a subimage would then fail forever, even after the source recovers.
            GLES20.glCopyTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, 0, 0, width, height, 0);
            storageReady = GLES20.glGetError() == GLES20.GL_NO_ERROR;
            copiedWidth = storageReady ? width : 0;
            copiedHeight = storageReady ? height : 0;
        } else {
            GLES20.glCopyTexSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, 0, 0, width, height);
            storageReady = GLES20.glGetError() == GLES20.GL_NO_ERROR;
        }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
        endSharedAccess();
        return storageReady;
    }

    /** Called before sampling, while holding the drawable's render lock. */
    public void beginSharedAccess() {
        if (sharedFence != 0) {
            // Server-side wait: no per-frame CPU stall. The creator flushed
            // before publishing the fence, so this cannot wait on unissued work.
            GLES30.glWaitSync(sharedFence, 0, GLES30.GL_TIMEOUT_IGNORED);
            GLES30.glDeleteSync(sharedFence);
            sharedFence = 0;
        }
    }

    /** Called after sampling/copying; the next reader OR writer waits for it. */
    public void endSharedAccess() {
        if (!sharedCopy) return;
        sharedFence = GLES30.glFenceSync(GLES30.GL_SYNC_GPU_COMMANDS_COMPLETE, 0);
        if (sharedFence == 0) {
            // Allocation failure must not publish unsynchronized content.
            GLES20.glFinish();
        } else GLES20.glFlush();
    }

    public void destroy() {
        beginSharedAccess();
        sharedCopy = false;
        copiedFromFramebuffer = false;
        copiedWidth = copiedHeight = 0;
        deleteTextureName();
    }

    private void deleteTextureName() {
        if (textureId > 0) {
            int[] textureIds = new int[]{textureId};
            GLES20.glDeleteTextures(textureIds.length, textureIds, 0);
            textureId = 0;
        }
    }
}
