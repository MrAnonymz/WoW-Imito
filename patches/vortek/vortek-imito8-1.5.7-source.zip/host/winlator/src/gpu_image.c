#include <android/log.h>
#include <android/hardware_buffer.h>
#include <android/native_window.h>

#define EGL_EGLEXT_PROTOTYPES
#define GL_GLEXT_PROTOTYPES

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <jni.h>
#include <string.h>
#include <stdbool.h>
#include <sys/mman.h>
#include <poll.h>
#include <sys/socket.h>
#include <errno.h>

#include "native_handle.h"
#include "winlator.h"

#define HAL_PIXEL_FORMAT_BGRA_8888 5

extern const native_handle_t* _Nullable AHardwareBuffer_getNativeHandle(const AHardwareBuffer* _Nonnull buffer);

int AHardwareBuffer_getFd(AHardwareBuffer* hardwareBuffer) {
    const native_handle_t* nativeHandle = AHardwareBuffer_getNativeHandle(hardwareBuffer);
    return nativeHandle->numFds > 0 ? nativeHandle->data[0] : -1;
}

EGLImageKHR createImageKHR(AHardwareBuffer* hardwareBuffer, int textureId) {
    const EGLint attribList[] = {EGL_IMAGE_PRESERVED_KHR, EGL_TRUE, EGL_NONE};
    if (!hardwareBuffer || textureId == 0) return EGL_NO_IMAGE_KHR;

    /* GPUImage owns the buffer until after eglDestroyImageKHR. An extra
       acquire here leaked one gralloc allocation on every image lifetime,
       including both error exits below. EGL retains its own image reference. */

    EGLClientBuffer clientBuffer = eglGetNativeClientBufferANDROID(hardwareBuffer);
    if (!clientBuffer) return NULL;

    EGLDisplay eglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    EGLImageKHR imageKHR = eglCreateImageKHR(eglDisplay, EGL_NO_CONTEXT, EGL_NATIVE_BUFFER_ANDROID, clientBuffer, attribList);
    if (!imageKHR) return NULL;

    glBindTexture(GL_TEXTURE_2D, textureId);
    glEGLImageTargetTexture2DOES(GL_TEXTURE_2D, imageKHR);
    glBindTexture(GL_TEXTURE_2D, 0);

    return imageKHR;
}

AHardwareBuffer* createHardwareBuffer(int width, int height, bool cpuAccess, bool useHALPixelFormatBGRA8888) {
    if (width <= 0 || height <= 0 || width > 16384 || height > 16384) return NULL;
    AHardwareBuffer_Desc buffDesc = {0};
    buffDesc.width = width;
    buffDesc.height = height;
    buffDesc.layers = 1;
    buffDesc.usage = AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE |
                    (cpuAccess ? AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN : AHARDWAREBUFFER_USAGE_GPU_COLOR_OUTPUT);
    buffDesc.format = useHALPixelFormatBGRA8888 ? HAL_PIXEL_FORMAT_BGRA_8888 : AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM;

    AHardwareBuffer* hardwareBuffer = NULL;
    if (AHardwareBuffer_allocate(&buffDesc, &hardwareBuffer) != 0) return NULL;

    return hardwareBuffer;
}

JNIEXPORT jlong JNICALL
Java_com_winlator_renderer_GPUImage_createHardwareBuffer(JNIEnv *env, jclass obj, jshort width,
                                                         jshort height, jboolean cpuAccess, jboolean useHALPixelFormatBGRA8888) {
    AHardwareBuffer* hardwareBuffer = createHardwareBuffer(width, height, cpuAccess, useHALPixelFormatBGRA8888);
    if (hardwareBuffer) {
        jclass cls = (*env)->GetObjectClass(env, obj);

        AHardwareBuffer_Desc buffDesc = {0};
        AHardwareBuffer_describe(hardwareBuffer, &buffDesc);

        jmethodID setStride = (*env)->GetMethodID(env, cls, "setStride", "(S)V");
        (*env)->CallVoidMethod(env, obj, setStride, (jshort)buffDesc.stride);
        jmethodID setFormat = (*env)->GetMethodID(env, cls, "setHardwareBufferFormat", "(I)V");
        (*env)->CallVoidMethod(env, obj, setFormat, (jint)buffDesc.format);

        int fd = AHardwareBuffer_getFd(hardwareBuffer);
        if (fd != -1) {
            jmethodID setNativeHandle = (*env)->GetMethodID(env, cls, "setNativeHandle", "(I)V");
            (*env)->CallVoidMethod(env, obj, setNativeHandle, fd);
        }
    }
    return (jlong)hardwareBuffer;
}

JNIEXPORT jlong JNICALL
Java_com_winlator_renderer_GPUImage_createImageKHR(JNIEnv *env, jclass obj,
                                                   jlong hardwareBufferPtr, jint textureId) {
    return (jlong)createImageKHR((AHardwareBuffer*)hardwareBufferPtr, textureId);
}

JNIEXPORT jlong JNICALL
Java_com_winlator_renderer_GPUImage_retainHardwareBuffer(JNIEnv* env,jobject obj,
        jlong pointer,jshort width,jshort height) {
    AHardwareBuffer* buffer=(AHardwareBuffer*)(uintptr_t)pointer;
    if(!buffer || width<=0 || height<=0)return 0;
    AHardwareBuffer_Desc desc={0};AHardwareBuffer_describe(buffer,&desc);
    if(desc.width!=(uint32_t)width || desc.height!=(uint32_t)height || desc.layers!=1 ||
            desc.stride>32767 || (desc.format!=1 && desc.format!=5))return 0;
    jclass cls=(*env)->GetObjectClass(env,obj);
    jmethodID setStride=(*env)->GetMethodID(env,cls,"setStride","(S)V");
    jmethodID setFormat=(*env)->GetMethodID(env,cls,"setHardwareBufferFormat","(I)V");
    if(!setStride || !setFormat){(*env)->DeleteLocalRef(env,cls);return 0;}
    (*env)->CallVoidMethod(env,obj,setStride,(jshort)desc.stride);
    (*env)->CallVoidMethod(env,obj,setFormat,(jint)desc.format);
    (*env)->DeleteLocalRef(env,cls);
    if((*env)->ExceptionCheck(env))return 0;
    AHardwareBuffer_acquire(buffer);return pointer;
}

/* WrapperV2 sends an AHardwareBuffer handle over a socket carried in SCM_RIGHTS,
   not a mmap-able pixel fd. Never interpret that socket as a legacy SHM buffer. */
JNIEXPORT jlong JNICALL
Java_com_winlator_renderer_GPUImage_receiveHardwareBuffer(JNIEnv *env, jobject obj,
        jint socketFd, jshort width, jshort height) {
    if (socketFd < 0 || width <= 0 || height <= 0) return 0;
    /* Receipt acknowledgement required by Mesa's Android/X11 WSI. Send it
       before validation too: allocation failures are reported through DRI3,
       and the producer must be able to read that error instead of waiting. */
    const uint8_t acknowledged = 1;
    ssize_t sent;
    do { sent = send(socketFd, &acknowledged, 1, MSG_NOSIGNAL | MSG_DONTWAIT); }
    while (sent < 0 && errno == EINTR);
    if (sent != 1) return 0;
    struct pollfd ready = {.fd = socketFd, .events = POLLIN};
    if (poll(&ready, 1, 1000) <= 0 || !(ready.revents & POLLIN)) return 0;
    struct timeval timeout = {.tv_sec = 1};
    setsockopt(socketFd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    AHardwareBuffer *buffer = NULL;
    if (AHardwareBuffer_recvHandleFromUnixSocket(socketFd, &buffer) != 0 || !buffer) return 0;
    AHardwareBuffer_Desc desc = {0};
    AHardwareBuffer_describe(buffer, &desc);
    if (desc.width != (uint32_t)width || desc.height != (uint32_t)height || desc.layers != 1 ||
        desc.stride > 32767 || !(desc.usage & AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE) ||
        (desc.format != AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM &&
         desc.format != AHARDWAREBUFFER_FORMAT_R8G8B8X8_UNORM && desc.format != HAL_PIXEL_FORMAT_BGRA_8888)) {
        AHardwareBuffer_release(buffer);
        return 0;
    }
    jclass cls = (*env)->GetObjectClass(env, obj);
    jmethodID setStride = (*env)->GetMethodID(env, cls, "setStride", "(S)V");
    (*env)->CallVoidMethod(env, obj, setStride, (jshort)desc.stride);
    jmethodID setFormat = (*env)->GetMethodID(env, cls, "setHardwareBufferFormat", "(I)V");
    (*env)->CallVoidMethod(env, obj, setFormat, (jint)desc.format);
    return (jlong)buffer;
}

JNIEXPORT void JNICALL
Java_com_winlator_renderer_GPUImage_destroyHardwareBuffer(JNIEnv *env, jclass obj,
                                                          jlong hardwareBufferPtr, jboolean locked) {
    AHardwareBuffer* hardwareBuffer = (AHardwareBuffer*)hardwareBufferPtr;
    if (hardwareBuffer) {
        if (locked) {
            AHardwareBuffer_unlock(hardwareBuffer, NULL);
            locked = false;
        }
        AHardwareBuffer_release(hardwareBuffer);
    }
}

JNIEXPORT jobject JNICALL
Java_com_winlator_renderer_GPUImage_lockHardwareBuffer(JNIEnv *env, jclass obj,
                                                       jlong hardwareBufferPtr) {
    AHardwareBuffer* hardwareBuffer = (AHardwareBuffer*)hardwareBufferPtr;
    if (!hardwareBuffer) return NULL;
    void *virtualAddr = NULL;
    if (AHardwareBuffer_lock(hardwareBuffer, AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN, -1, NULL, &virtualAddr) != 0)
        return NULL;
    if (!virtualAddr) {
        AHardwareBuffer_unlock(hardwareBuffer, NULL);
        return NULL;
    }

    AHardwareBuffer_Desc buffDesc = {0};
    AHardwareBuffer_describe(hardwareBuffer, &buffDesc);

    jlong size = (jlong)buffDesc.stride * buffDesc.height * 4;
    return (*env)->NewDirectByteBuffer(env, virtualAddr, size);
}

JNIEXPORT void JNICALL
Java_com_winlator_renderer_GPUImage_destroyImageKHR(JNIEnv *env, jclass obj, jlong imageKHRPtr) {
    EGLImageKHR imageKHR = (EGLImageKHR)imageKHRPtr;
    if (imageKHR) {
        EGLDisplay eglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
        eglDestroyImageKHR(eglDisplay, imageKHR);
    }
}
