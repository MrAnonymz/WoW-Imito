#ifndef WINLATOR_SOCKET_IO_H
#define WINLATOR_SOCKET_IO_H

#include <errno.h>
#include <android/log.h>
#include <sys/socket.h>
#include <sys/types.h>

/* No protocol bytes, socket paths, or exception messages enter this log.
 * Bound diagnostics per translation unit, including repeated interruptions. */
static inline void socket_io_diagnostic(const char* operation, int fd, int result, int error) {
#if WRATHRT_DIAGNOSTICS
    static unsigned int emitted = 0;
    int previousError = errno;
    unsigned int index = __atomic_fetch_add(&emitted, 1, __ATOMIC_RELAXED);
    if (index < 64) {
        struct { pid_t pid; uid_t uid; gid_t gid; } peer = {-1, (uid_t)-1, (gid_t)-1};
        socklen_t peerLength = sizeof(peer);
        if (getsockopt(fd, SOL_SOCKET, SO_PEERCRED, &peer, &peerLength) != 0)
            peer.pid = -1;
        __android_log_print(ANDROID_LOG_INFO, "WrathRTSocket",
                "operation=%s fd=%d result=%d errno=%d peer_pid=%d peer_uid=%u",
                operation, fd, result, error, peer.pid, peer.uid);
    }
    else if (index == 64) {
        __android_log_print(ANDROID_LOG_INFO, "WrathRTSocket", "further diagnostics suppressed");
    }
    errno = previousError;
#endif
}

/* A negative EINTR means no bytes were transferred. Never retry a positive
 * short transfer, EOF, EAGAIN, or any permanent error here. */
#define SOCKET_RETRY_EINTR(result, expression, operation, fd) do { \
    int socketSavedError; \
    int socketReportedInterrupt = 0; \
    do { \
        (result) = (expression); \
        socketSavedError = (result) < 0 ? errno : 0; \
        if ((result) < 0 && socketSavedError == EINTR && !socketReportedInterrupt) { \
            socket_io_diagnostic(operation "-interrupted", (fd), (result), socketSavedError); \
            socketReportedInterrupt = 1; \
        } \
    } while ((result) < 0 && socketSavedError == EINTR); \
    if ((result) < 0) { \
        socket_io_diagnostic(operation "-error", (fd), (result), socketSavedError); \
        errno = socketSavedError; \
    } \
} while (0)

#endif
