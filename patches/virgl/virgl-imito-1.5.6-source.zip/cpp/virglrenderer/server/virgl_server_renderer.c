/**************************************************************************
 *
 * Copyright (C) 2015 Red Hat Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 **************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <limits.h>

#include "virgl_hw.h"

#include <sys/uio.h>
#include <sys/socket.h>
#include <sys/mman.h>

#include <vrend_renderer.h>

#include "virgl_server.h"
#include "virgl_server_shm.h"
#include "virgl_server_protocol.h"

#include "util/u_debug.h"
#include "util/u_math.h"
#include "util/u_memory.h"
#include "util/u_hash_table.h"

#include <jni.h>
#include <EGL/eglext.h>

extern EGLContext globalEGLContext;

static void virgl_server_write_fence(struct virgl_client *client, uint32_t fence_id)
{
   client->renderer->last_fence_id = fence_id;
}

static virgl_gl_context virgl_server_egl_create_context(struct virgl_client *client)
{
   struct virgl_server_renderer *renderer = client->renderer;
   EGLContext egl_ctx;
   EGLint ctx_att[] = {
      EGL_CONTEXT_CLIENT_VERSION, 3,
      EGL_NONE
   };

   egl_ctx = eglCreateContext(renderer->egl_display, renderer->egl_conf, renderer->egl_ctx, ctx_att);

   return (virgl_gl_context)egl_ctx;
}

static void virgl_server_egl_destroy_context(struct virgl_client *client, virgl_gl_context ctx)
{
   eglDestroyContext(client->renderer->egl_display, (EGLContext)ctx);
}

static int virgl_server_egl_make_current(struct virgl_client *client, virgl_gl_context ctx)
{
   if (ctx && eglGetCurrentContext() == (EGLContext)ctx)
      return EGL_TRUE;
   return eglMakeCurrent(client->renderer->egl_display, EGL_NO_SURFACE, EGL_NO_SURFACE, (EGLContext)ctx);
}

struct vrend_if_cbs virgl_server_cbs = {
   .write_fence = virgl_server_write_fence,
   .create_gl_context = virgl_server_egl_create_context,
   .destroy_gl_context = virgl_server_egl_destroy_context,
   .make_current = virgl_server_egl_make_current,
};

static bool virgl_server_egl_init(struct virgl_server_renderer *renderer)
{
    static EGLint conf_att[] = {
       EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
       EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT_KHR,
       EGL_RED_SIZE, 8,
       EGL_GREEN_SIZE, 8,
       EGL_BLUE_SIZE, 8,
       EGL_ALPHA_SIZE, 0,
       EGL_NONE,
    };
    static const EGLint ctx_att[] = {
       EGL_CONTEXT_CLIENT_VERSION, 3,
       EGL_NONE
    };

    EGLBoolean success;
    EGLint major, minor, num_configs;

    renderer->egl_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);

    if (!renderer->egl_display)
        return false;

    success = eglInitialize(renderer->egl_display, &major, &minor);
    if (!success)
        return false;

    success = eglBindAPI(EGL_OPENGL_ES_API);
    if (!success)
        return false;

    success = eglChooseConfig(renderer->egl_display, conf_att, &renderer->egl_conf,
                              1, &num_configs);

    if (!success || num_configs != 1)
        return false;

    renderer->egl_ctx = eglCreateContext(renderer->egl_display, renderer->egl_conf, globalEGLContext, ctx_att);

    if (renderer->egl_ctx == EGL_NO_CONTEXT)
        return false;
    if (!eglMakeCurrent(renderer->egl_display, EGL_NO_SURFACE, EGL_NO_SURFACE, renderer->egl_ctx))
        return false;

    return true;
}

static unsigned
hash_func(void *key)
{
   intptr_t ip = pointer_to_intptr(key);
   return (unsigned)(ip & 0xffffffff);
}

static int
compare_iovecs(void *key1, void *key2)
{
   if (key1 < key2) {
      return -1;
   } else if (key1 > key2) {
      return 1;
   } else {
      return 0;
   }
}

static void free_iovec(void *value)
{
   struct iovec *iovec = value;
   if (iovec->iov_base)
      munmap(iovec->iov_base, iovec->iov_len);
   free(iovec);
}

static int virgl_block_write(int fd, void *buf, int size)
{
   char *ptr = buf;
   int left;
   int ret;
   left = size;

   do {
      ret = write(fd, ptr, left);
      if (ret < 0)
         return -errno;

      left -= ret;
      ptr += ret;
   } while (left);

   return size;
}

int virgl_block_read(int fd, void *buf, int size)
{
   char *ptr = buf;
   int left;
   int ret;

   left = size;
   do {
      ret = read(fd, ptr, left);
      if (ret <= 0)
         return ret == -1 ? -errno : 0;

      left -= ret;
      ptr += ret;
   } while (left);

   return size;
}

static int virgl_server_send_fd(int sock_fd, int fd)
{
    struct iovec iovec;
    char buf[CMSG_SPACE(sizeof(int))], c;
    struct msghdr msgh = { 0 };
    memset(buf, 0, sizeof(buf));

    iovec.iov_base = &c;
    iovec.iov_len = sizeof(char);

    msgh.msg_name = NULL;
    msgh.msg_namelen = 0;
    msgh.msg_iov = &iovec;
    msgh.msg_iovlen = 1;
    msgh.msg_control = buf;
    msgh.msg_controllen = sizeof(buf);
    msgh.msg_flags = 0;

    struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msgh);
    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type = SCM_RIGHTS;
    cmsg->cmsg_len = CMSG_LEN(sizeof(int));

    *((int *)CMSG_DATA(cmsg)) = fd;

    int size = sendmsg(sock_fd, &msgh, 0);
    if (size < 0)
      return -EINVAL;

    return 0;
}

int virgl_server_create_renderer(struct virgl_client *client, uint32_t length)
{
   int ret;

   struct virgl_server_renderer *renderer = calloc(1, sizeof(struct virgl_server_renderer));
   if (!renderer)
      return -ENOMEM;
   renderer->iovec_hash = util_hash_table_create(hash_func, compare_iovecs, free_iovec);
   if (!renderer->iovec_hash) {
      free(renderer);
      return -ENOMEM;
   }
   renderer->ctx_id = 1;

   client->renderer = renderer;

   // Never enter vrend with no current GLES context. Drivers differ in which
   // EGL configurations support ES3, and an ES1-only config is not sufficient.
   if (!virgl_server_egl_init(renderer)) {
      ret = EIO;
      goto failed_root;
   }

   ret = vrend_renderer_init(client, &virgl_server_cbs);
   if (ret)
      goto failed_root;

   ret = vrend_renderer_context_create(client, renderer->ctx_id);
   if (!ret)
      return 0;
   vrend_renderer_fini(client);
failed_root:
   if (renderer->egl_ctx != EGL_NO_CONTEXT) {
      if (eglGetCurrentContext() == renderer->egl_ctx)
         eglMakeCurrent(renderer->egl_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
      eglDestroyContext(renderer->egl_display, renderer->egl_ctx);
   }
   util_hash_table_destroy(renderer->iovec_hash);
   free(renderer);
   client->renderer = NULL;
   return -ret;
}

void virgl_server_destroy_renderer(struct virgl_client *client)
{
   if (!client->initialized)
      return;

   /* The presentation FBO belongs to scratch ctx0, not the guest context
    * left current by the last submitted command. FBO names are not shared. */
   if (vrend_renderer_force_ctx_0(client) && client->renderer->framebuffer)
      glDeleteFramebuffers(1, &client->renderer->framebuffer);

   vrend_renderer_context_destroy(client, client->renderer->ctx_id);
   vrend_renderer_fini(client);
   util_hash_table_destroy(client->renderer->iovec_hash);
   client->renderer->iovec_hash = NULL;

   /* Drop the root share-context too. Retaining it kept all shared driver
    * objects alive after disconnect/reconnect, even after the guest exited. */
   eglMakeCurrent(client->renderer->egl_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
   eglDestroyContext(client->renderer->egl_display, client->renderer->egl_ctx);

   free(client->renderer);
   client->renderer = NULL;
   client->initialized = false;
}

int virgl_server_send_caps(struct virgl_client *client, UNUSED uint32_t length)
{
   uint32_t send_buf[2];
   void *caps_buf;
   int ret;
   uint32_t max_ver, max_size;

   vrend_renderer_get_cap_set(2, &max_ver, &max_size);

   if (max_size == 0)
      return -1;

   caps_buf = malloc(max_size);
   if (!caps_buf)
      return -1;

   vrend_renderer_fill_caps(client, 2, 1, caps_buf);

   send_buf[0] = max_size + 1;
   send_buf[1] = 2;
   ret = virgl_block_write(client->fd, send_buf, 8);
   if (ret < 0)
      goto end;

   virgl_block_write(client->fd, caps_buf, max_size);

end:
   free(caps_buf);
   return 0;
}

int virgl_server_resource_create(struct virgl_client *client, UNUSED uint32_t length)
{
   uint32_t recv_buf[11];
   struct vrend_renderer_resource_create_args args;
   struct iovec *iovec;
   int ret, fd;

   ret = virgl_block_read(client->fd, &recv_buf, sizeof(recv_buf));
   if (ret != sizeof(recv_buf))
      return -1;

   args.handle = recv_buf[0];
   args.target = recv_buf[1];
   args.format = recv_buf[2];
   args.bind = recv_buf[3];
   args.width = recv_buf[4];
   args.height = recv_buf[5];
   args.depth = recv_buf[6];
   args.array_size = recv_buf[7];
   args.last_level = recv_buf[8];
   args.nr_samples = recv_buf[9];
   args.flags = 0;

   if (util_hash_table_get(client->renderer->iovec_hash, intptr_to_pointer(args.handle)))
      return -EEXIST;

   ret = vrend_renderer_resource_create(client, &args, NULL, 0);
   if (ret)
      return ret;

   vrend_renderer_attach_res_ctx(client, client->renderer->ctx_id, args.handle);

   iovec = CALLOC_STRUCT(iovec);
   if (!iovec)
      return -ENOMEM;

   iovec->iov_len = recv_buf[10];

   if (iovec->iov_len == 0) {
      iovec->iov_base = NULL;
      goto out;
   }

   fd = virgl_server_new_shm(args.handle, iovec->iov_len);
   if (fd < 0) {
      FREE(iovec);
      return fd;
   }

   iovec->iov_base = mmap(NULL, iovec->iov_len, PROT_WRITE | PROT_READ,
                          MAP_SHARED, fd, 0);

   if (iovec->iov_base == MAP_FAILED) {
      close(fd);
      FREE(iovec);
      return -ENOMEM;
   }

   ret = virgl_server_send_fd(client->fd, fd);
   if (ret < 0) {
      close(fd);
      munmap(iovec->iov_base, iovec->iov_len);
      return ret;
   }

   close(fd);

out:
   vrend_renderer_resource_attach_iov(client, args.handle, iovec, 1);
   util_hash_table_set(client->renderer->iovec_hash, intptr_to_pointer(args.handle), iovec);
   return 0;
}

int virgl_server_resource_destroy(struct virgl_client *client, UNUSED uint32_t length)
{
   uint32_t recv_buf[1];
   int ret;
   uint32_t handle;

   ret = virgl_block_read(client->fd, &recv_buf, sizeof(recv_buf));
   if (ret != sizeof(recv_buf))
      return -1;

   handle = recv_buf[0];
   vrend_renderer_attach_res_ctx(client, client->renderer->ctx_id, handle);

   vrend_renderer_resource_detach_iov(client, handle, NULL, NULL);
   util_hash_table_remove(client->renderer->iovec_hash, intptr_to_pointer(handle));

   /* Guest handles can be reused after resource destruction. The presentation
    * FBO still references the old GL texture, even if that texture's name is
    * later recycled. Mark its cache key invalid without touching context-local
    * GL objects here; the next flush rebuilds it in its owning scratch ctx0. */
   if ((uint32_t)client->renderer->handle == handle)
      client->renderer->handle = 0;

   vrend_renderer_resource_unref(client, handle);
   return 0;
}

int virgl_server_transfer_get(struct virgl_client *client, UNUSED uint32_t length)
{
   uint32_t recv_buf[10];
   int ret;
   struct pipe_box box;
   struct iovec *iovec;
   struct vrend_transfer_info transfer_info;

   ret = virgl_block_read(client->fd, &recv_buf, sizeof(recv_buf));
   if (ret != sizeof(recv_buf))
      return ret;

   box.x = recv_buf[2];
   box.y = recv_buf[3];
   box.z = recv_buf[4];
   box.width = recv_buf[5];
   box.height = recv_buf[6];
   box.depth = recv_buf[7];

   transfer_info.handle = recv_buf[0];
   transfer_info.ctx_id = client->renderer->ctx_id;
   transfer_info.level = recv_buf[1];
   transfer_info.stride = 0;
   transfer_info.layer_stride = 0;
   transfer_info.box = &box;
   transfer_info.offset = recv_buf[9];
   transfer_info.iovec = NULL;
   transfer_info.iovec_cnt = 0;
   transfer_info.context0 = true;
   transfer_info.synchronized = false;

   iovec = util_hash_table_get(client->renderer->iovec_hash, intptr_to_pointer(transfer_info.handle));
   if (!iovec)
      return -ESRCH;

   if (transfer_info.offset >= iovec->iov_len)
      return -EFAULT;

    ret = vrend_renderer_transfer_iov(client, &transfer_info, VIRGL_TRANSFER_FROM_HOST);

   if (ret)
      return ret;

   return 0;
}

int virgl_server_transfer_put(struct virgl_client *client, UNUSED uint32_t length)
{
   uint32_t recv_buf[10];
   int ret;
   struct pipe_box box;
   struct iovec *iovec;
   struct vrend_transfer_info transfer_info;

   ret = virgl_block_read(client->fd, &recv_buf, sizeof(recv_buf));
   if (ret != sizeof(recv_buf))
      return ret;

   box.x = recv_buf[2];
   box.y = recv_buf[3];
   box.z = recv_buf[4];
   box.width = recv_buf[5];
   box.height = recv_buf[6];
   box.depth = recv_buf[7];

   transfer_info.handle = recv_buf[0];
   transfer_info.ctx_id = client->renderer->ctx_id;
   transfer_info.level = recv_buf[1];
   transfer_info.stride = 0;
   transfer_info.layer_stride = 0;
   transfer_info.box = &box;
   transfer_info.offset = recv_buf[9];
   transfer_info.iovec = NULL;
   transfer_info.iovec_cnt = 0;
   transfer_info.context0 = true;
   transfer_info.synchronized = false;

   iovec = util_hash_table_get(client->renderer->iovec_hash, intptr_to_pointer(transfer_info.handle));
   if (!iovec)
      return -ESRCH;

   vrend_renderer_transfer_iov(client, &transfer_info, VIRGL_TRANSFER_TO_HOST);

   if (ret)
      return ret;

   return 0;
}

int virgl_server_submit_cmd(struct virgl_client *client, uint32_t length)
{
   uint32_t *cbuf;
   int cbuf_len, ret;

   /* The protocol counts dwords, while socket I/O takes signed byte counts.
    * Reject overflow before allocation or reading a truncated command stream. */
   if (length > INT_MAX / sizeof(uint32_t))
      return -EINVAL;
   cbuf_len = (int)(length * sizeof(uint32_t));

   /* Normal Mesa batches reuse a small client-owned scratch buffer. Decode is
    * synchronous and consumes the packet before the next request. Retain at
    * most 256 KiB; exceptional larger packets keep their old temporary lifetime.
    * No fence, flush, guest resource or GPU synchronization is skipped. */
   bool temporary = cbuf_len > 256 * 1024;
   if (temporary) {
      cbuf = malloc(cbuf_len);
      if (!cbuf)
         return -ENOMEM;
   } else {
      if ((size_t)cbuf_len > client->command_capacity) {
         size_t capacity = 4096;
         while (capacity < (size_t)cbuf_len)
            capacity *= 2;
         uint32_t *grown = realloc(client->command_buffer, capacity);
         if (!grown)
            return -ENOMEM;
         client->command_buffer = grown;
         client->command_capacity = capacity;
      }
      cbuf = client->command_buffer;
   }

   ret = cbuf_len ? virgl_block_read(client->fd, cbuf, cbuf_len) : 0;
   if (ret != cbuf_len) {
      if (temporary) free(cbuf);
      return -1;
   }

   ret = vrend_decode_block(client, client->renderer->ctx_id, cbuf, length);

   if (temporary) free(cbuf);
   if (ret)
      return ret < 0 ? ret : -ret;
   return virgl_server_renderer_create_fence(client);
}

int virgl_server_resource_busy_wait(struct virgl_client *client, UNUSED uint32_t length)
{
   uint32_t recv_buf[2];
   uint32_t send_buf[3];
   int ret;
   int flags;
   bool busy = false;

   ret = virgl_block_read(client->fd, &recv_buf, sizeof(recv_buf));
   if (ret != sizeof(recv_buf))
      return -1;

   flags = recv_buf[1];

   do {
      busy = client->renderer->last_fence_id != client->renderer->fence_id;
      if (!busy || !(flags & VCMD_BUSY_WAIT_FLAG_WAIT))
         break;

      ret = vrend_renderer_wait_fences(client);
      if (ret < 0)
         return ret;

      /* Do not consume the next request, but stop waiting if the guest closed
       * its socket while the GPU was busy. */
      char pending;
      ret = recv(client->fd, &pending, 1, MSG_PEEK | MSG_DONTWAIT);
      if (ret == 0)
         return -EPIPE;
      if (ret < 0 && errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
         return -errno;
   } while (1);

   send_buf[0] = 1;
   send_buf[1] = VCMD_RESOURCE_BUSY_WAIT;
   send_buf[2] = busy ? 1 : 0;

   ret = virgl_block_write(client->fd, send_buf, sizeof(send_buf));
   if (ret < 0)
      return ret;

   return 0;
}

int virgl_server_flush_frontbuffer(struct virgl_client *client, UNUSED uint32_t length)
{
   uint32_t recv_buf[2];
   uint32_t handle, drawable;
   int ret;

   ret = virgl_block_read(client->fd, &recv_buf, sizeof(recv_buf));
   if (ret != sizeof(recv_buf))
      return -1;

   handle = recv_buf[0];
   drawable = recv_buf[1];

   struct vrend_context *ctx = vrend_lookup_renderer_ctx(client, client->renderer->ctx_id);
   struct vrend_resource *res = ctx ? vrend_renderer_ctx_res_lookup(ctx, handle) : NULL;
   if (!res)
      return -ESRCH;

   // Query polling can leave a guest context current. FBOs are not shared,
   // so create, reuse and copy the presentation FBO only in the scratch ctx0.
   EGLContext expected_context = (EGLContext)vrend_renderer_get_ctx_0_gl_context(client);
   if (expected_context == EGL_NO_CONTEXT)
      return -EIO;
   vrend_renderer_force_ctx_0(client);
   if (eglGetCurrentContext() != expected_context)
      return -EIO;

   if (handle != client->renderer->handle || !client->renderer->framebuffer) {
      if (client->renderer->framebuffer)
         glDeleteFramebuffers(1, &client->renderer->framebuffer);
      client->renderer->framebuffer = 0;

      GLuint framebuffer = 0;
      glGenFramebuffers(1, &framebuffer);
      if (!framebuffer)
         return -ENOMEM;
      glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);

      vrend_fb_bind_texture(res, 0, 0, 0);

      glBindFramebuffer(GL_FRAMEBUFFER, 0);

      client->renderer->framebuffer = framebuffer;
      client->renderer->handle = handle;
   }

   (*jni_info.env)->CallVoidMethod(jni_info.env, jni_info.obj, jni_info.flush_frontbuffer, drawable, client->renderer->framebuffer);
   return 0;
}

int virgl_server_renderer_create_fence(struct virgl_client *client)
{
   uint32_t next_id = client->renderer->fence_id + 1u;
   int ret = vrend_renderer_create_fence(client, next_id, 0);
   if (ret)
      return ret < 0 ? ret : -ret;
   client->renderer->fence_id = next_id;
   return 0;
}

JNIEXPORT jlong JNICALL
Java_com_winlator_xenvironment_components_VirGLRendererComponent_getCurrentEGLContextPtr(JNIEnv *env, jobject obj) {
   EGLContext egl_ctx = eglGetCurrentContext();
   return egl_ctx != EGL_NO_CONTEXT ? (jlong)egl_ctx : 0;
}
