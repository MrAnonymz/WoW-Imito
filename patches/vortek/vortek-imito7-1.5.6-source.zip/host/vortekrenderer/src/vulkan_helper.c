#include <string.h>

#include "vulkan_helper.h"
#include "dma_utils.h"

#define VK_MAKE_VERSION_STR(s, v) sprintf(s, "%d.%d.%d", VK_VERSION_MAJOR(v), VK_VERSION_MINOR(v), VK_VERSION_PATCH(v))

DeviceMemoryInfo deviceMemoryInfo = {0};

#if ENABLE_VALIDATION_LAYER
static VkBool32 debugReportCallback(VkDebugReportFlagsEXT flags, VkDebugReportObjectTypeEXT type, uint64_t object, size_t location, int32_t messageCode, const char *pLayerPrefix, const char *pMessage, void *pUserData) {
    println("Vulkan (%s): %s", pLayerPrefix, pMessage);
    return VK_FALSE;
}
#endif

VkBufferUsageFlags getSharedBufferUsage(void) {
    return VK_BUFFER_USAGE_TRANSFER_SRC_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT |
           VK_BUFFER_USAGE_UNIFORM_TEXEL_BUFFER_BIT | VK_BUFFER_USAGE_STORAGE_TEXEL_BUFFER_BIT |
           VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT | VK_BUFFER_USAGE_STORAGE_BUFFER_BIT |
           VK_BUFFER_USAGE_INDEX_BUFFER_BIT | VK_BUFFER_USAGE_VERTEX_BUFFER_BIT |
           VK_BUFFER_USAGE_INDIRECT_BUFFER_BIT;
}

static bool isExternalMemoryHandleTypeSupported(VkPhysicalDevice physicalDevice, VkExternalMemoryHandleTypeFlagBits handleType) {
    VkPhysicalDeviceExternalBufferInfo bufferInfo = {0};
    bufferInfo.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_EXTERNAL_BUFFER_INFO;
    // Query the actual usage used by ResourceMemory, not an invalid zero mask.
    bufferInfo.usage = getSharedBufferUsage();
    bufferInfo.handleType = handleType;

    VkExternalBufferProperties bufferProperties = {0};
    bufferProperties.sType = VK_STRUCTURE_TYPE_EXTERNAL_BUFFER_PROPERTIES;
    vulkanWrapper.vkGetPhysicalDeviceExternalBufferProperties(physicalDevice, &bufferInfo, &bufferProperties);
    VkExternalMemoryProperties* memoryProperties = &bufferProperties.externalMemoryProperties;

    // Opaque FDs are exported from Vulkan; DMA-BUFs are allocated externally
    // and imported into Vulkan. One capability does not imply the other.
    VkExternalMemoryFeatureFlags required = handleType == VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT
            ? VK_EXTERNAL_MEMORY_FEATURE_EXPORTABLE_BIT : VK_EXTERNAL_MEMORY_FEATURE_IMPORTABLE_BIT;
    return (memoryProperties->externalMemoryFeatures & required) == required &&
           (memoryProperties->compatibleHandleTypes & handleType) != 0;
}

static void setupExposedDeviceExtensions(VkContext* context) {
    if (!context->engineName) return;

    ArrayList_free(context->disabledDeviceExtensions, true);
    context->disabledDeviceExtensions = NULL;

    if (strcmp(context->engineName, "DXVK") == 0) {
        if (context->driverID == VK_DRIVER_ID_ARM_PROPRIETARY) {
            const char* disabledDeviceExtensions[] = {"VK_EXT_extended_dynamic_state", "VK_EXT_extended_dynamic_state2", "VK_EXT_extended_dynamic_state3", "VK_EXT_hdr_metadata", "VK_EXT_swapchain_maintenance1"};
            context->disabledDeviceExtensions = ArrayList_fromStrings(disabledDeviceExtensions, ARRAY_SIZE(disabledDeviceExtensions));
        }
        else {
            const char* disabledDeviceExtensions[] = {"VK_KHR_shader_float_controls", "VK_EXT_hdr_metadata", "VK_EXT_swapchain_maintenance1"};
            context->disabledDeviceExtensions = ArrayList_fromStrings(disabledDeviceExtensions, ARRAY_SIZE(disabledDeviceExtensions));
        }
    }
    else if (strcmp(context->engineName, "mesa zink") == 0) {
        const char* disabledDeviceExtensions[] = {"VK_EXT_extended_dynamic_state", "VK_EXT_extended_dynamic_state2", "VK_EXT_extended_dynamic_state3", "VK_EXT_color_write_enable", "VK_KHR_push_descriptor"};
        context->disabledDeviceExtensions = ArrayList_fromStrings(disabledDeviceExtensions, ARRAY_SIZE(disabledDeviceExtensions));
        ArrayList_free(context->exposedDeviceExtensions, true);
        context->exposedDeviceExtensions = ArrayList_fromStrings(globalExposedDeviceExtensions, ARRAY_SIZE(globalExposedDeviceExtensions));
    }
}

void initVulkanInstance(VkContext* context, VkInstance instance, const VkApplicationInfo* applicationInfo) {
    VkResult result;

    loadVulkanInstanceFuncs(&vulkanWrapper, instance);

    uint32_t physicalDeviceCount = 1;
    result = vulkanWrapper.vkEnumeratePhysicalDevices(instance, &physicalDeviceCount, NULL);
    if (result != VK_SUCCESS) return;

    VkPhysicalDevice physicalDevices[physicalDeviceCount];
    result = vulkanWrapper.vkEnumeratePhysicalDevices(instance, &physicalDeviceCount, physicalDevices);
    if (result != VK_SUCCESS || physicalDeviceCount == 0) return;

    if (deviceMemoryInfo.memoryTypeCount == 0) {
        VkPhysicalDeviceMemoryProperties memoryProperties;
        vulkanWrapper.vkGetPhysicalDeviceMemoryProperties(physicalDevices[0], &memoryProperties);

        deviceMemoryInfo.memoryTypes = malloc(memoryProperties.memoryTypeCount * sizeof(VkMemoryType));
        memcpy(deviceMemoryInfo.memoryTypes, memoryProperties.memoryTypes, memoryProperties.memoryTypeCount * sizeof(VkMemoryType));
        deviceMemoryInfo.memoryTypeCount = memoryProperties.memoryTypeCount;

        VkDeviceSize maxHeapSize = 0;
        for (int i = 0; i < memoryProperties.memoryHeapCount; i++) maxHeapSize = MAX(maxHeapSize, memoryProperties.memoryHeaps[i].size);
        deviceMemoryInfo.maxAllocationSize = maxHeapSize * 2 / 3;
    }

    VkPhysicalDeviceDriverProperties driverProperties = {0};
    driverProperties.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRIVER_PROPERTIES;
    VkPhysicalDeviceProperties2 properties2 = {0};
    properties2.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2;
    properties2.pNext = &driverProperties;
    vulkanWrapper.vkGetPhysicalDeviceProperties2(physicalDevices[0], &properties2);
    context->driverID = driverProperties.driverID;

    context->hasExternalMemoryFd = isExternalMemoryHandleTypeSupported(physicalDevices[0], VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT);
    context->hasExternalMemoryDMABuf = isExternalMemoryHandleTypeSupported(physicalDevices[0], VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT);

    MEMFREE(context->engineName);
    context->engineVersion = 0;

    if (applicationInfo) {
        context->engineName = applicationInfo->pEngineName ? strdup(applicationInfo->pEngineName) : NULL;
        context->engineVersion = applicationInfo->engineVersion;
    }

    setupExposedDeviceExtensions(context);

#if ENABLE_VALIDATION_LAYER
    VkDebugReportCallbackCreateInfoEXT debugCreateInfo = {0};
    debugCreateInfo.sType = VK_STRUCTURE_TYPE_DEBUG_REPORT_CREATE_INFO_EXT;
    debugCreateInfo.flags = VK_DEBUG_REPORT_ERROR_BIT_EXT | VK_DEBUG_REPORT_WARNING_BIT_EXT | VK_DEBUG_REPORT_PERFORMANCE_WARNING_BIT_EXT;
    debugCreateInfo.pfnCallback = debugReportCallback;

    vulkanWrapper.vkCreateDebugReportCallback(instance, &debugCreateInfo, NULL, &context->debugReportCallback);
#endif
}

void initVulkanDevice(VkContext* context, VkPhysicalDevice physicalDevice, VkDevice device) {
    loadVulkanDeviceFuncs(&vulkanWrapper, device);

    uint32_t queueFamilyCount = 0;
    vulkanWrapper.vkGetPhysicalDeviceQueueFamilyProperties(physicalDevice, &queueFamilyCount, NULL);

    VkQueueFamilyProperties queueFamilies[queueFamilyCount];
    vulkanWrapper.vkGetPhysicalDeviceQueueFamilyProperties(physicalDevice, &queueFamilyCount, queueFamilies);

    context->graphicsQueueIndex = 0;
    for (uint32_t i = 0; i < queueFamilyCount; i++) {
        if (queueFamilies[i].queueCount > 0 && (queueFamilies[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)) {
            context->graphicsQueueIndex = i;
            break;
        }
    }

    VkPhysicalDeviceFeatures supportedFeatures = {0};
    vulkanWrapper.vkGetPhysicalDeviceFeatures(physicalDevice, &supportedFeatures);

    if (!context->textureDecoder) context->textureDecoder = TextureDecoder_create(context, physicalDevice, &supportedFeatures);
    if (!context->shaderInspector) context->shaderInspector = ShaderInspector_create(context, physicalDevice, &supportedFeatures);
    if (context->textureDecoder) context->textureDecoder->threadPool = context->threadPool;
}

uint32_t getMemoryTypeIndex(uint32_t typeBits, VkFlags properties) {
    for (uint32_t i = 0; i < deviceMemoryInfo.memoryTypeCount && i < 32; i++) {
        if ((typeBits & 1u) &&
                (deviceMemoryInfo.memoryTypes[i].propertyFlags & properties) == properties) return i;
        typeBits >>= 1;
    }
    // Index zero is a real type, not a safe fallback. Callers must handle a
    // device that cannot satisfy both the resource mask and all required flags.
    return UINT32_MAX;
}

uint32_t getMemoryPropertyFlags(uint32_t memoryTypeIndex) {
    if (deviceMemoryInfo.memoryTypeCount == 0 || memoryTypeIndex >= deviceMemoryInfo.memoryTypeCount) return 0;
    return deviceMemoryInfo.memoryTypes[memoryTypeIndex].propertyFlags;
}

bool isHostVisibleMemory(uint32_t memoryTypeIndex) {
    if (deviceMemoryInfo.memoryTypeCount == 0 || memoryTypeIndex >= deviceMemoryInfo.memoryTypeCount) return false;
    VkMemoryType* memoryType = &deviceMemoryInfo.memoryTypes[memoryTypeIndex];
    return (memoryType->propertyFlags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT) != 0;
}

void injectExtensions(VkContext* context, char*** extensions, uint32_t* extensionCount, const char* const* extraExtensions, uint32_t extraExtensionCount, const char* const* skipExtensions, uint32_t skipExtensionCount) {
    if (skipExtensions) {
        uint32_t oldExtensionCount = *extensionCount;
        char** oldExtensions = *extensions;

        bool skipped[oldExtensionCount];
        uint32_t newExtensionCount = 0;
        for (int i = 0; i < oldExtensionCount; i++) {
            skipped[i] = false;
            for (int j = 0; j < skipExtensionCount; j++) {
                if (strcmp(skipExtensions[j], oldExtensions[i]) == 0) {
                    skipped[i] = true;
                    break;
                }
            }

            if (!skipped[i]) newExtensionCount++;
        }

        char** newExtensions = vt_alloc(&context->memoryPool, newExtensionCount * sizeof(char*));
        for (int i = 0, j = 0; i < oldExtensionCount; i++) if (!skipped[i]) newExtensions[j++] = oldExtensions[i];

        *extensions = newExtensions;
        *extensionCount = newExtensionCount;
    }

    uint32_t newExtensionCount = *extensionCount;
    bool founds[extraExtensionCount];
    for (int i = 0; i < extraExtensionCount; i++) {
        founds[i] = false;
        for (int j = 0; j < *extensionCount; j++) {
            if (strcmp(extraExtensions[i], (*extensions)[j]) == 0) {
                founds[i] = true;
                break;
            }
        }

        if (!founds[i]) newExtensionCount++;
    }

    if (newExtensionCount == *extensionCount) return;

    char** newExtensions = vt_alloc(&context->memoryPool, newExtensionCount * sizeof(char*));
    for (int i = 0, j = 0; i < extraExtensionCount; i++) {
        if (!founds[i]) {
            char* value = vt_alloc(&context->memoryPool, strlen(extraExtensions[i]) + 1);
            strcpy(value, extraExtensions[i]);
            newExtensions[(*extensionCount) + j++] = value;
        }
    }

    for (int i = 0; i < *extensionCount; i++) newExtensions[i] = (*extensions)[i];

    *extensions = newExtensions;
    *extensionCount = newExtensionCount;
}

void injectExtensions2(VkContext* context, VkExtensionProperties** extensions, uint32_t* extensionCount, const char* const* extraExtensions, uint32_t extraExtensionCount, const char* const* skipExtensions, uint32_t skipExtensionCount) {
    if (skipExtensions) {
        uint32_t oldExtensionCount = *extensionCount;
        VkExtensionProperties* oldExtensions = *extensions;

        bool skipped[oldExtensionCount];
        uint32_t newExtensionCount = 0;
        for (int i = 0; i < oldExtensionCount; i++) {
            skipped[i] = false;
            for (int j = 0; j < skipExtensionCount; j++) {
                if (strcmp(skipExtensions[j], oldExtensions[i].extensionName) == 0) {
                    skipped[i] = true;
                    break;
                }
            }

            if (!skipped[i]) newExtensionCount++;
        }

        VkExtensionProperties* newExtensions = vt_alloc(&context->memoryPool, newExtensionCount * sizeof(VkExtensionProperties));
        for (int i = 0, j = 0; i < oldExtensionCount; i++) {
            if (!skipped[i]) memcpy(&newExtensions[j++], &oldExtensions[i], sizeof(VkExtensionProperties));
        }

        *extensions = newExtensions;
        *extensionCount = newExtensionCount;
    }

    uint32_t newExtensionCount = *extensionCount;
    bool founds[extraExtensionCount];
    for (int i = 0; i < extraExtensionCount; i++) {
        founds[i] = false;
        for (int j = 0; j < *extensionCount; j++) {
            if (strcmp(extraExtensions[i], (*extensions)[j].extensionName) == 0) {
                founds[i] = true;
                break;
            }
        }

        if (!founds[i]) newExtensionCount++;
    }

    if (newExtensionCount == *extensionCount) return;

    VkExtensionProperties* newExtensions = vt_alloc(&context->memoryPool, newExtensionCount * sizeof(VkExtensionProperties));
    for (int i = 0, j = 0; i < extraExtensionCount; i++) {
        if (!founds[i]) {
            VkExtensionProperties* properties = &newExtensions[(*extensionCount) + j++];
            strcpy(properties->extensionName, extraExtensions[i]);
            properties->specVersion = 1;
        }
    }

    for (int i = 0; i < *extensionCount; i++) memcpy(&newExtensions[i], &(*extensions)[i], sizeof(VkExtensionProperties));

    *extensions = newExtensions;
    *extensionCount = newExtensionCount;
}

void checkDeviceMemoryProperties(VkContext* context, VkPhysicalDeviceMemoryProperties* memoryProperties, void* pNext) {
    VkDeviceSize maxHeapSize = (VkDeviceSize)context->maxDeviceMemory << 20;
    if (maxHeapSize == 0) maxHeapSize = deviceMemoryInfo.maxAllocationSize;

    for (int i = 0; i < memoryProperties->memoryHeapCount; i++) {
        memoryProperties->memoryHeaps[i].size = MIN(memoryProperties->memoryHeaps[i].size, maxHeapSize);
    }

    VkPhysicalDeviceMemoryBudgetPropertiesEXT* memoryBudgetProperties = findNextVkStructure(pNext, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_MEMORY_BUDGET_PROPERTIES_EXT);
    if (memoryBudgetProperties) {
        memoryBudgetProperties->heapUsage[0] = context->totalAllocationSize;
        memoryBudgetProperties->heapBudget[0] = maxHeapSize > 0 ? maxHeapSize : deviceMemoryInfo.maxAllocationSize;
    }
}

void disableUnsupportedDeviceFeatures(VkPhysicalDevice physicalDevice, VkDeviceCreateInfo* createInfo) {
    VkPhysicalDeviceTransformFeedbackFeaturesEXT* transformFeedbackFeatures = findNextVkStructure(createInfo->pNext, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TRANSFORM_FEEDBACK_FEATURES_EXT);
    if (transformFeedbackFeatures) {
        VkPhysicalDeviceFeatures2 features = {0};
        features.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2;
        features.pNext = transformFeedbackFeatures;
        vulkanWrapper.vkGetPhysicalDeviceFeatures2(physicalDevice, &features);
    }

    VkPhysicalDeviceFeatures* enabledFeatures = (VkPhysicalDeviceFeatures*)createInfo->pEnabledFeatures;
    VkPhysicalDeviceFeatures2* features2 = NULL;
    if (!enabledFeatures) {
        features2 = findNextVkStructure((void*)createInfo->pNext, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2);
        if (features2) enabledFeatures = &features2->features;
    }

    if (enabledFeatures) {
        VkPhysicalDeviceFeatures supportedFeatures = {0};
        vulkanWrapper.vkGetPhysicalDeviceFeatures(physicalDevice, &supportedFeatures);

        for (int offset = 0; offset < sizeof(VkPhysicalDeviceFeatures); offset += sizeof(VkBool32)) {
            VkBool32 srcValue = *(VkBool32*)(((char*)&supportedFeatures) + offset);
            VkBool32 dstValue = *(VkBool32*)(((char*)enabledFeatures) + offset);
            if (dstValue && !srcValue) *(VkBool32*)(((char*)enabledFeatures) + offset) = VK_FALSE;
        }
    }
}

static bool isNativeSwapchainExtension(const char* name) {
    // Vortek owns the guest swapchain and strips VK_KHR_swapchain before
    // creating the native device. Native present IDs, waits and maintenance
    // cannot operate on XWindowSwapchain handles; none are implemented by
    // this bridge. DXVK enables advertised optional extension names even
    // when their feature structs are absent from the wire protocol.
    static const char* unsupported[] = {
        "VK_KHR_present_id", "VK_KHR_present_wait",
        "VK_KHR_present_id2", "VK_KHR_present_wait2",
        "VK_EXT_swapchain_maintenance1", "VK_KHR_swapchain_maintenance1",
        "VK_GOOGLE_display_timing"
    };
    for (uint32_t i = 0; i < ARRAY_SIZE(unsupported); i++)
        if (strcmp(name, unsupported[i]) == 0) return true;
    return false;
}

VkExtensionProperties* getExposedDeviceExtensionProperties(VkContext* context, VkPhysicalDevice physicalDevice, uint32_t* propertyCount, VkResult* result) {
    uint32_t srcPropertyCount = 0;
    VkExtensionProperties* srcProperties = NULL;
    *propertyCount = 0;
    for (unsigned attempt = 0; attempt < 4; ++attempt) {
        *result = vulkanWrapper.vkEnumerateDeviceExtensionProperties(physicalDevice, NULL, &srcPropertyCount, NULL);
        if (*result != VK_SUCCESS || !srcPropertyCount) break;
        srcProperties = vt_alloc(&context->memoryPool, srcPropertyCount * sizeof(VkExtensionProperties));
        *result = vulkanWrapper.vkEnumerateDeviceExtensionProperties(physicalDevice, NULL, &srcPropertyCount, srcProperties);
        if (*result != VK_INCOMPLETE) break;
    }
    if (*result != VK_SUCCESS) return NULL;

    int dstPropertyCount = context->exposedDeviceExtensions ? context->exposedDeviceExtensions->size : srcPropertyCount;
    VkExtensionProperties* dstProperties = vt_alloc(&context->memoryPool, dstPropertyCount * sizeof(VkExtensionProperties));
    *propertyCount = 0;

    for (int i = 0, j; i < dstPropertyCount; i++) {
        bool expose = true;
        VkExtensionProperties* srcProperty = NULL;
        if (context->exposedDeviceExtensions) {
            expose = false;
            char* extensionName = context->exposedDeviceExtensions->elements[i];

            for (j = 0; j < srcPropertyCount; j++) {
                if (strcmp(extensionName, srcProperties[j].extensionName) == 0) {
                    expose = true;
                    srcProperty = &srcProperties[j];
                    break;
                }
            }
        }
        else srcProperty = &srcProperties[i];
        if (!expose) continue;
        if (isNativeSwapchainExtension(srcProperty->extensionName)) continue;
        // A caller's module identifier cannot identify our pipeline-specific
        // SPIR-V variants. Module-less pipeline creation would bypass their
        // required vertex/fragment adaptation. Keep normal pipeline caches.
        if (strcmp(srcProperty->extensionName, VK_EXT_SHADER_MODULE_IDENTIFIER_EXTENSION_NAME) == 0) continue;

        if (context->disabledDeviceExtensions) {
            for (j = 0; j < context->disabledDeviceExtensions->size; j++) {
                char* extensionName = context->disabledDeviceExtensions->elements[j];
                if (strcmp(srcProperty->extensionName, extensionName) == 0) {
                    expose = false;
                    break;
                }
            }
        }

        if (expose) {
            int index = (*propertyCount)++;
            strcpy(dstProperties[index].extensionName, srcProperty->extensionName);
            dstProperties[index].specVersion = srcProperty->specVersion;
        }
    }

    injectExtensions2(context, &dstProperties, propertyCount,
                      globalImplementedDeviceExtensions, ARRAY_SIZE(globalImplementedDeviceExtensions), NULL, 0);
    return dstProperties;
}

void checkFormatProperties(VkPhysicalDevice physicalDevice, VkFormat format, VkFormatProperties* formatProperties) {
    if (TextureDecoder_canDecode(format) && formatProperties->optimalTilingFeatures == 0) {
        VkFormatProperties decoded = {0};
        vulkanWrapper.vkGetPhysicalDeviceFormatProperties(physicalDevice, TextureDecoder_decodedFormat(format), &decoded);
        // The decoder implements sampled BC1-5 images uploaded through buffers.
        // RGBA attachment/storage/buffer/linear-map capabilities are not BC capabilities.
        formatProperties->optimalTilingFeatures = decoded.optimalTilingFeatures &
                (VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT | VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT |
                 VK_FORMAT_FEATURE_TRANSFER_SRC_BIT | VK_FORMAT_FEATURE_TRANSFER_DST_BIT);
    }
    else if (isFormatScaled(format)) {
        formatProperties->bufferFeatures |= VK_FORMAT_FEATURE_VERTEX_BUFFER_BIT;
    }
}

void checkFormatProperties2(VkPhysicalDevice physicalDevice, VkFormat format, VkFormatProperties2* formatProperties) {
    VkFormatProperties native = formatProperties->formatProperties;
    checkFormatProperties(physicalDevice, format, &formatProperties->formatProperties);
    // DXVK 2 reads the 64-bit properties from this chain, not the legacy fields.
    // Add only the capabilities emulated above; retain all native high bits.
    for (VkBaseOutStructure* next = formatProperties->pNext; next; next = next->pNext) {
        if (next->sType != VK_STRUCTURE_TYPE_FORMAT_PROPERTIES_3) continue;
        VkFormatProperties3* properties = (VkFormatProperties3*)next;
        properties->linearTilingFeatures |= formatProperties->formatProperties.linearTilingFeatures & ~native.linearTilingFeatures;
        properties->optimalTilingFeatures |= formatProperties->formatProperties.optimalTilingFeatures & ~native.optimalTilingFeatures;
        properties->bufferFeatures |= formatProperties->formatProperties.bufferFeatures & ~native.bufferFeatures;
    }
}

void checkImageFormatProperties(VkPhysicalDevice physicalDevice, VkFormat format, VkImageType type, VkImageTiling tiling, VkImageUsageFlags usage, VkImageCreateFlags flags, VkImageFormatProperties* imageFormatProperties, VkResult* result) {
    // Preserve the driver's result for uncompressed images, including failures.
    // Linear images cannot expose multisampling; never fabricate success/8x MSAA.
    if (*result == VK_ERROR_FORMAT_NOT_SUPPORTED && TextureDecoder_canDecode(format)) {
        *result = getCompressedImageFormatProperties(physicalDevice, format, type, tiling, usage, flags, imageFormatProperties);
    }
}

void checkDeviceProperties(VkContext* context, VkPhysicalDeviceProperties* properties, void* pNext) {
    char deviceName[VK_MAX_PHYSICAL_DEVICE_NAME_SIZE] = {0};
    sprintf(deviceName, DEVICE_NAME, properties->deviceName);
    strcpy(properties->deviceName, deviceName);
    properties->apiVersion = MIN(properties->apiVersion, context->vkMaxVersion);

    VkPhysicalDeviceVulkan12Properties* vulkan12Properties = findNextVkStructure(pNext, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_PROPERTIES);
    if (vulkan12Properties) {
        VK_MAKE_VERSION_STR(vulkan12Properties->driverInfo, properties->driverVersion);

        if (context->disabledDeviceExtensions) {
            bool floatControlsEnabled = true;
            for (int i = 0; i < context->disabledDeviceExtensions->size && floatControlsEnabled; i++) {
                if (strcmp((const char*)context->disabledDeviceExtensions->elements[i], "VK_KHR_shader_float_controls") == 0) floatControlsEnabled = false;
            }

            if (!floatControlsEnabled) {
                vulkan12Properties->shaderSignedZeroInfNanPreserveFloat32 = VK_FALSE;
                vulkan12Properties->shaderSignedZeroInfNanPreserveFloat64 = VK_FALSE;
                vulkan12Properties->shaderDenormFlushToZeroFloat32 = VK_FALSE;
                vulkan12Properties->shaderDenormFlushToZeroFloat64 = VK_FALSE;
                vulkan12Properties->shaderDenormPreserveFloat32 = VK_FALSE;
                vulkan12Properties->shaderDenormPreserveFloat64 = VK_FALSE;
            }
        }
    }

    VkPhysicalDeviceDriverProperties* driverProperties = findNextVkStructure(pNext, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRIVER_PROPERTIES);
    if (driverProperties) VK_MAKE_VERSION_STR(driverProperties->driverInfo, properties->driverVersion);

    VkPhysicalDeviceMapMemoryPlacedPropertiesEXT* mapPlacedProperties = findNextVkStructure(pNext, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_MAP_MEMORY_PLACED_PROPERTIES_EXT);
    if (mapPlacedProperties) mapPlacedProperties->minPlacedMemoryMapAlignment = getpagesize();
}

void checkDeviceFeatures(VkPhysicalDeviceFeatures* features, void* pNext) {
    features->textureCompressionBC = VK_TRUE;
    features->depthClamp = VK_TRUE;
    features->depthBiasClamp = VK_TRUE;
    features->fillModeNonSolid = VK_TRUE;
    features->sampleRateShading = VK_TRUE;
    features->samplerAnisotropy = VK_TRUE;
    features->shaderClipDistance = VK_TRUE;
    features->shaderCullDistance = VK_TRUE;
    features->occlusionQueryPrecise = VK_TRUE;
    features->independentBlend = VK_TRUE;
    features->multiViewport = VK_TRUE;
    features->fullDrawIndexUint32 = VK_TRUE;
    features->logicOp = VK_TRUE;
    features->shaderImageGatherExtended = VK_TRUE;
    features->variableMultisampleRate = VK_TRUE;
    features->dualSrcBlend = VK_TRUE;
    features->imageCubeArray = VK_TRUE;
    features->drawIndirectFirstInstance = VK_TRUE;
    features->fragmentStoresAndAtomics = VK_TRUE;
    features->multiDrawIndirect = VK_TRUE;
    features->tessellationShader = VK_TRUE;

    VkPhysicalDeviceMapMemoryPlacedFeaturesEXT* mapMemoryPlacedFeatures = findNextVkStructure(pNext, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_MAP_MEMORY_PLACED_FEATURES_EXT);
    if (mapMemoryPlacedFeatures) {
        mapMemoryPlacedFeatures->memoryMapPlaced = VK_TRUE;
        mapMemoryPlacedFeatures->memoryMapRangePlaced = VK_FALSE;
        mapMemoryPlacedFeatures->memoryUnmapReserve = VK_TRUE;
    }
}

void destroyVkObject(VkObjectType type, VkDevice device, void* handle) {
    if (!handle) return;
    switch (type) {
        case VK_OBJECT_TYPE_INSTANCE:
            vulkanWrapper.vkDestroyInstance(handle, NULL);
            break;
        case VK_OBJECT_TYPE_DEVICE:
            vulkanWrapper.vkDestroyDevice(handle, NULL);
            break;
        case VK_OBJECT_TYPE_SEMAPHORE:
            vulkanWrapper.vkDestroySemaphore(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_FENCE:
            vulkanWrapper.vkDestroyFence(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_BUFFER:
            vulkanWrapper.vkDestroyBuffer(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_IMAGE:
            vulkanWrapper.vkDestroyImage(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_EVENT:
            vulkanWrapper.vkDestroyEvent(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_QUERY_POOL:
            vulkanWrapper.vkDestroyQueryPool(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_BUFFER_VIEW:
            vulkanWrapper.vkDestroyBufferView(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_IMAGE_VIEW:
            vulkanWrapper.vkDestroyImageView(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_SHADER_MODULE: {
            ShaderInspector_destroyModule(device, handle);
            break;
        }
        case VK_OBJECT_TYPE_PIPELINE_CACHE:
            vulkanWrapper.vkDestroyPipelineCache(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_PIPELINE_LAYOUT:
            vulkanWrapper.vkDestroyPipelineLayout(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_RENDER_PASS:
            vulkanWrapper.vkDestroyRenderPass(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_PIPELINE: {
            vulkanWrapper.vkDestroyPipeline(device, handle, NULL);
            break;
        }
        case VK_OBJECT_TYPE_DESCRIPTOR_SET_LAYOUT:
            vulkanWrapper.vkDestroyDescriptorSetLayout(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_SAMPLER:
            vulkanWrapper.vkDestroySampler(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_DESCRIPTOR_POOL:
            vulkanWrapper.vkDestroyDescriptorPool(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_FRAMEBUFFER:
            vulkanWrapper.vkDestroyFramebuffer(device, handle, NULL);
            break;
        case VK_OBJECT_TYPE_COMMAND_POOL:
            vulkanWrapper.vkDestroyCommandPool(device, handle, NULL);
            break;
    }
}
