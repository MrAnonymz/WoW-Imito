/* Diagnostic prototype, not enabled in the app.
 * Prove linear layout of ONLY a new buffer allocated here. Writes go through
 * Android's CPU mapping, never into an unknown raw/compressed DMA layout.
 * Both complete pixel patterns must be observed at the asserted DMA offsets.
 */
#ifndef IMITO_FRESH_LINEAR_AHB_PROOF_H
#define IMITO_FRESH_LINEAR_AHB_PROOF_H
#include <android/hardware_buffer.h>
#include <android/log.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/dma-buf.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>
#include "native_handle.h"

/* Same platform ABI used by the existing GPUImage and pinned Mesa driver.
 * Optional at runtime: do not make it a new mandatory dependency. */
typedef const native_handle_t* (*GetAhbHandle)(const AHardwareBuffer*);
typedef struct FreshLinearBuffer {
    AHardwareBuffer* buffer;
    int fd;                         /* owned duplicate, never a borrowed fd */
    uint64_t bytes;
    uint32_t width,height,pitch,format;
} FreshLinearBuffer;

static void freshLinearBufferDestroy(FreshLinearBuffer* b) {
    if(b->fd>=0)close(b->fd);
    if(b->buffer)AHardwareBuffer_release(b->buffer);
    memset(b,0,sizeof(*b));b->fd=-1;
}

static uint32_t freshLinearCookie(uint32_t x,uint32_t y,uint32_t width,unsigned round) {
    /* Odd multiplication is bijective in uint32; two complementary patterns. */
    uint32_t value=(y*width+x)*2654435761u+0x4179b3d5u;
    return round?~value:value;
}

static int freshLinearDmaSync(int fd,uint64_t flags) {
    struct dma_buf_sync sync={.flags=flags};int result;
    do {result=ioctl(fd,DMA_BUF_IOCTL_SYNC,&sync);} while(result<0 && errno==EINTR);
    return result;
}

static bool freshLinearBufferCreate(uint32_t width,uint32_t height,uint32_t format,
        GetAhbHandle getHandle,FreshLinearBuffer* out) {
    FreshLinearBuffer b={.fd=-1};
    const char* failure="descriptor";
    if(!out || !getHandle || !width || !height || width>2048 || height>2048 ||
            (format!=AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM && format!=5))return false;
    memset(out,0,sizeof(*out));out->fd=-1;
    AHardwareBuffer_Desc wanted={.width=width,.height=height,.layers=1,.format=format,
        .usage=AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN|AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN|
               AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE|AHARDWAREBUFFER_USAGE_GPU_COLOR_OUTPUT};
    if(AHardwareBuffer_allocate(&wanted,&b.buffer)!=0){failure="allocation";goto fail;}
    AHardwareBuffer_Desc desc={0};AHardwareBuffer_describe(b.buffer,&desc);
    if(desc.width!=width || desc.height!=height || desc.layers!=1 || desc.format!=format ||
            desc.stride<width || desc.stride>8192)goto fail;
    uint64_t pitch=(uint64_t)desc.stride*4,span=pitch*height;
    if(span>64u*1024*1024)goto fail;
    const native_handle_t* handle=getHandle(b.buffer);
    if(!handle || handle->numFds<1 || handle->numFds>16){failure="handle";goto fail;}
    bool matching[16]={0};uint64_t sizes[16]={0};
    for(int i=0;i<handle->numFds;i++) {
        int fd=handle->data[i];if(fd<0)continue;
        off_t original=lseek(fd,0,SEEK_CUR),size=lseek(fd,0,SEEK_END);
        if(original>=0)lseek(fd,original,SEEK_SET);
        if(size<=0 || (uint64_t)size<span || size>256u*1024*1024)continue;
        matching[i]=true;sizes[i]=(uint64_t)size;
    }
    for(unsigned round=0;round<2;round++) {
        void* cpu=NULL;int32_t bpp=-1,rowBytes=-1;
        int lock=AHardwareBuffer_lockAndGetInfo(b.buffer,AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN,
            -1,NULL,&cpu,&bpp,&rowBytes);
        if(lock!=0){failure="CPU lock";goto fail;}
        bool valid=cpu && bpp==4 && rowBytes==(int32_t)pitch;
        if(valid)for(uint32_t y=0;y<height;y++)for(uint32_t x=0;x<width;x++) {
            uint32_t cookie=freshLinearCookie(x,y,width,round);
            memcpy((uint8_t*)cpu+y*pitch+x*4,&cookie,4);
        }
        /* NULL fence means Android blocks until CPU cache work is complete. */
        int unlock=AHardwareBuffer_unlock(b.buffer,NULL);
        if(!valid || unlock!=0){failure="CPU layout or unlock";goto fail;}
        int matches=0;
        for(int i=0;i<handle->numFds;i++)if(matching[i]) {
            int fd=handle->data[i];
            void* raw=mmap(NULL,(size_t)span,PROT_READ,MAP_SHARED,fd,0);
            if(raw==MAP_FAILED){matching[i]=false;continue;}
            if(freshLinearDmaSync(fd,DMA_BUF_SYNC_START|DMA_BUF_SYNC_READ)!=0) {
                munmap(raw,(size_t)span);matching[i]=false;continue;
            }
            bool equal=true;
            for(uint32_t y=0;y<height && equal;y++)for(uint32_t x=0;x<width;x++) {
                uint32_t got;memcpy(&got,(uint8_t*)raw+y*pitch+x*4,4);
                if(got!=freshLinearCookie(x,y,width,round)){equal=false;break;}
            }
            if(freshLinearDmaSync(fd,DMA_BUF_SYNC_END|DMA_BUF_SYNC_READ)!=0)equal=false;
            munmap(raw,(size_t)span);
            matching[i]=equal;if(equal)matches++;
        }
        if(matches!=1){failure="no unique proven linear DMA payload";goto fail;}
    }
    for(int i=0;i<handle->numFds;i++)if(matching[i]) {
        b.fd=fcntl(handle->data[i],F_DUPFD_CLOEXEC,0);b.bytes=sizes[i];break;
    }
    if(b.fd<0){failure="duplicate fd";goto fail;}
    b.width=width;b.height=height;b.pitch=(uint32_t)pitch;b.format=format;*out=b;
    __android_log_print(ANDROID_LOG_INFO,"Imito156DMA",
        "LINEAR_PROOF PASS width=%u height=%u pitch=%u format=%u bytes=%llu pixelsChecked=%llu",
        width,height,b.pitch,format,(unsigned long long)b.bytes,(unsigned long long)width*height*2);
    return true;
fail:
    __android_log_print(ANDROID_LOG_INFO,"Imito156DMA","LINEAR_PROOF FAIL %s errno=%d",failure,errno);
    freshLinearBufferDestroy(&b);return false;
}
#endif
