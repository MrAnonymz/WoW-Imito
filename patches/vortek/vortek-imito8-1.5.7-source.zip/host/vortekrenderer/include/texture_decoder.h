#ifndef VORTEK_TEXTURE_DECODER_H
#define VORTEK_TEXTURE_DECODER_H

#include "vortek.h"
#include "texture_copy_layout.h"

typedef struct TextureDecoder_Image {
    VkImage image;
    VkFormat format;
    uint32_t width;
    uint32_t height;
    TextureCopyImageLayout layout;
    VkDevice device;
    bool coherent;
    VkBuffer buffer;
    VkDeviceMemory memory;
    void* decompressedData;
    VkDeviceSize usedSize;
} TextureDecoder_Image;

typedef struct TextureDecoder_BoundBuffer {
    VkBuffer buffer;
    VkDeviceSize memoryOffset;
    ResourceMemory* memory;
} TextureDecoder_BoundBuffer;

typedef struct TextureDecoder_BufferImageCopy {
    VkCommandBuffer commandBuffer;
    TextureDecoder_BoundBuffer* srcBuffer;
    TextureDecoder_Image* dstImage;
    TextureDecoder_Image* staging;
    VkDeviceSize stagingOffset;
    VkBufferImageCopy region;
} TextureDecoder_BufferImageCopy;

typedef struct TextureDecoder_Command {
    VkCommandBuffer handle;
    VkCommandPool pool;
    ArrayList secondary;
    ArrayList staging;
    VkResult result;
    bool decoding;
} TextureDecoder_Command;

typedef struct TextureDecoder {
    ArrayList images;
    ArrayList boundBuffers;
    ArrayDeque bufferImageCopies;
    ArrayList commands;
    short imageCacheSize;
    ThreadPool* threadPool;
    uint32_t nativeBCFormats;
} TextureDecoder;

extern TextureDecoder* TextureDecoder_create(VkContext* context, VkPhysicalDevice physicalDevice, VkPhysicalDeviceFeatures* supportedFeatures);
extern bool TextureDecoder_needsDecode(TextureDecoder* textureDecoder, VkFormat format);
extern void TextureDecoder_destroy(TextureDecoder* textureDecoder);
extern VkResult TextureDecoder_decodeCommands(TextureDecoder* decoder, uint32_t count, const VkCommandBuffer* commands);
extern void TextureDecoder_registerCommands(TextureDecoder* decoder, VkCommandPool pool, uint32_t count, const VkCommandBuffer* commands);
extern void TextureDecoder_resetCommand(TextureDecoder* decoder, VkCommandBuffer command, bool remove);
extern void TextureDecoder_resetPool(TextureDecoder* decoder, VkCommandPool pool, bool remove);
extern void TextureDecoder_executeCommands(TextureDecoder* decoder, VkCommandBuffer command, uint32_t count, const VkCommandBuffer* secondary);
extern void TextureDecoder_copyBufferToImage(TextureDecoder* textureDecoder, VkCommandBuffer commandBuffer, VkBuffer srcBuffer, VkImage dstImage, VkImageLayout dstImageLayout, uint32_t regionCount, const VkBufferImageCopy* regions);
extern VkFormat TextureDecoder_decodedFormat(VkFormat format);
extern bool TextureDecoder_containsImage(TextureDecoder* textureDecoder, VkImage image);
extern VkResult TextureDecoder_createImage(TextureDecoder* textureDecoder, VkDevice device, VkImageCreateInfo* imageInfo, VkImage* pImage);
extern void TextureDecoder_destroyImage(TextureDecoder* textureDecoder, VkDevice device, VkImage image);
extern void TextureDecoder_addBoundBuffer(TextureDecoder* textureDecoder, ResourceMemory* resourceMemory, VkBuffer buffer, VkDeviceSize memoryOffset);
extern void TextureDecoder_removeBoundBuffer(TextureDecoder* textureDecoder, VkBuffer buffer);
extern void TextureDecoder_removeBoundMemory(TextureDecoder* textureDecoder, ResourceMemory* memory);
extern bool isCompressedFormat(VkFormat format);
extern bool TextureDecoder_canDecode(VkFormat format);
extern VkResult getCompressedImageFormatProperties(VkPhysicalDevice physicalDevice, VkFormat format,
        VkImageType type, VkImageTiling tiling, VkImageUsageFlags usage, VkImageCreateFlags flags,
        VkImageFormatProperties* properties);

#endif

#define DECOMPRESSED_FORMAT VK_FORMAT_B8G8R8A8_UNORM
