package com.winlator.wowmobile;

import java.util.LinkedHashSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.regex.*;
import org.json.*;

/** Bounded tokens from existing runtime pipes, never raw logs or command lines. */
public final class GameRuntimeEvidence {
    private static final LinkedHashSet<String> failures = new LinkedHashSet<>(), libraries = new LinkedHashSet<>();
    private static final LinkedHashSet<String> moduleFailures = new LinkedHashSet<>();
    private static long generation;
    private static long[] vortekStartup, vortekFailure;
    private static boolean lostPresentWait;
    private static final ArrayList<long[]> viewportStates = new ArrayList<>();
    private static int swapchainRequests, swapchainsReady, swapchainsPresented;
    // Wine 10.10 ntdll/loader.c: only fixed import/initialisation errors, never
    // loaddll traces. Parent paths are inspected transiently and not retained.
    private static final Pattern PE_MISSING = Pattern.compile(
        "(?:^|:)err:module:import_dll Library ([A-Za-z0-9_.+\\-]{1,64}\\.dll) \\(which is needed by L?\"[^\"\\r\\n]{1,400}\"\\) not found\\s*$", Pattern.CASE_INSENSITIVE);
    private static final Pattern PE_IMPORT = Pattern.compile(
        "(?:^|:)err:module:import_dll Loading library ([A-Za-z0-9_.+\\-]{1,64}\\.dll) \\(which is needed by L?\"[^\"\\r\\n]{1,400}\"\\) failed \\(error ([0-9a-f]{8})\\)\\.\\s*$", Pattern.CASE_INSENSITIVE);
    private static final Pattern PE_FATAL = Pattern.compile(
        "(?:^|:)err:module:loader_init (?:Importing dlls for|Initializing dlls for|Initializing system dll for|TLS init  failed when loading) L?\"([^\"\\r\\n]{1,400})\"(?: failed)?, status ([0-9a-f]{8})\\s*$", Pattern.CASE_INSENSITIVE);
    private static final Pattern PE_KERNEL = Pattern.compile(
        "^wine: could not load (kernel32\\.dll), status ([0-9a-f]{8})\\s*$", Pattern.CASE_INSENSITIVE);
    private static final Pattern MISSING = Pattern.compile(
        "(?:error while loading shared libraries: |library \\\")([A-Za-z0-9_.+\\-]{1,100}\\.so(?:\\.[0-9]{1,3}){0,3})(?::|\\\" not found)");
    // DXVK 1.10.3 dxvk_queue.cpp prints VkResult as a number rather than
    // its symbolic name. Match only these exact native error messages.
    private static final Pattern QUEUE_ERROR = Pattern.compile(
        "DxvkSubmissionQueue: (?:Command submission failed|Failed to sync fence): (-[124])\\s*$");
    private static final String[][] TOKENS = {{"vk_error_device_lost","vulkan_device_lost"},
            {"vk_error_out_of_device_memory","vulkan_device_memory"},
            {"vk_error_out_of_host_memory","vulkan_host_memory"},
            {"vk_error_incompatible_driver","vulkan_incompatible_driver"},
            {"vk_error_feature_not_present","vulkan_feature_missing"},
            {"vk_error_extension_not_present","vulkan_extension_missing"},
            {"error while loading shared libraries","native_library_missing"},
            {"failed to load ntdll.so","ntdll_load_failed"},
            {"failed to load l_intl.nls","nls_load_failed"},
            {"unhandled page fault","guest_page_fault"},
            {"unhandled exception: page fault","guest_page_fault"},
            {"unhandled exception: illegal instruction","guest_illegal_instruction"},
            {"permission denied","runtime_permission"},
            {"operation not permitted","runtime_permission"},
            {"egl_bad_alloc","egl_allocation_failed"},
            {"egl_context_lost","egl_context_lost"}};
    private GameRuntimeEvidence() {}
    public static synchronized void reset() {
        failures.clear(); libraries.clear(); moduleFailures.clear(); generation++;
        viewportStates.clear();
        vortekStartup=vortekFailure=null; swapchainRequests=swapchainsReady=swapchainsPresented=0;
        lostPresentWait=false;
    }
    public static synchronized long generation() { return generation; }
    /** Layout-event evidence only: last eight distinct numeric states, never pixels,
     * paths, titles or a frame-time logger. Old renderer callbacks cannot cross sessions. */
    public static synchronized void viewport(long sourceGeneration,long[] state) {
        if(sourceGeneration!=generation || !validViewport(state))return;
        for(int i=0;i<viewportStates.size();i++) {
            if(Arrays.equals(viewportStates.get(i),state)) {
                if(i==viewportStates.size()-1)return;
                viewportStates.remove(i);break;
            }
        }
        if(viewportStates.size()==8)viewportStates.remove(0);
        viewportStates.add(state.clone());
    }
    private static boolean validViewport(long[] v) {
        if(v==null || v.length!=27 || v[0]!=1 || v[1]<1 || v[1]>3 ||
                v[2]<0 || v[2]>0xffffffffL || v[11]<0 || v[11]>2 || v[20]<0 || v[20]>1)return false;
        for(int i=3;i<v.length;i++) {
            if(i==11 || i==20)continue;
            boolean coordinate=i==3 || i==4 || i==12 || i==13 || i==16 || i==17 || i==21 || i==22;
            if(v[i]<(coordinate?-65535:0) || v[i]>(coordinate?65535:32768))return false;
        }
        return v[5]>0 && v[6]>0 && v[14]>0 && v[15]>0 && v[18]>0 && v[19]>0;
    }
    /** At most one callback per create/first-present milestone, not per frame.
     * This evidence never changes the selected GPU or requests a restart. */
    public static synchronized void vortekStartup(long sourceGeneration,int stage,int result,
            int format,int width,int height,long windowId) {
        if(sourceGeneration!=generation)return;
        long[] event={1,stage,result,format,width,height,windowId,0,0,0};
        if(!validVortek(event))return;
        if(stage==1)swapchainRequests=Math.min(65535,swapchainRequests+1);
        if(stage==8)swapchainsReady=Math.min(65535,swapchainsReady+1);
        if(stage==9)swapchainsPresented=Math.min(65535,swapchainsPresented+1);
        event[7]=swapchainRequests;event[8]=swapchainsReady;event[9]=swapchainsPresented;
        vortekStartup=event;
        if(result<0)vortekFailure=event.clone();
        if (stage == 14 && result == -4 && format == 37 && swapchainsPresented > 0) lostPresentWait=true;
    }
    public static synchronized boolean lostRgbaPresentWait() { return lostPresentWait; }
    /** Forever's pipe avoids serializing unchanged evidence for every output line. */
    public static synchronized boolean acceptChanged(String line) {
        if (line == null) return false;
        int before = failures.size() + libraries.size() + moduleFailures.size();
        accept(line);
        return before != failures.size() + libraries.size() + moduleFailures.size();
    }
    public static synchronized void accept(String line) {
        if (line == null) return;
        if (moduleFailures.size()<4) {
            String token=moduleFailure(line,false);
            if (!token.isEmpty()) moduleFailures.add(token);
        }
        String s = line.toLowerCase(Locale.ROOT);
        for (String[] pair : TOKENS) if (s.contains(pair[0]) && failures.size()<16) failures.add(pair[1]);
        Matcher queue=QUEUE_ERROR.matcher(line);
        if(queue.find()) {
            String code=queue.group(1);
            failures.add(code.equals("-4")?"vulkan_device_lost":code.equals("-2")?"vulkan_device_memory":"vulkan_host_memory");
        }
        Matcher m=MISSING.matcher(line);
        while(m.find() && libraries.size()<8) {
            String name=m.group(1);
            if (!name.contains("..")) {libraries.add(name);failures.add("native_library_missing");}
        }
    }
    public static synchronized JSONObject snapshot() {
        JSONObject out=new JSONObject();
        try {out.put("runtimeFailures",new JSONArray(failures));out.put("missingLibraries",new JSONArray(libraries));
            out.put("wineModuleFailures",new JSONArray(moduleFailures));
            if(!viewportStates.isEmpty()) {
                JSONArray views=new JSONArray();for(long[] state:viewportStates)views.put(new JSONArray(state));
                out.put("viewportStates",views);
            }
            if(vortekStartup!=null)out.put("vortekStartup",new JSONArray(vortekStartup));
            if(vortekFailure!=null)out.put("vortekFailure",new JSONArray(vortekFailure));}
        catch(JSONException ignored) {}
        return out;
    }
    public static boolean fatalModuleLoad(String line) { return !moduleFailure(line,true).isEmpty(); }
    /** An executable's loader_init failure is terminal for that executable.
     * Optional import errors and Wine helper/system DLL failures are not enough. */
    static String fatalExecutableLoad(String line) {
        if (line == null) return "";
        Matcher match=PE_FATAL.matcher(line);
        if (!match.find()) return "";
        String token=moduleToken(match.group(1),match.group(2));
        int separator=token.indexOf('|');
        return separator>0 && token.substring(0,separator).endsWith(".exe")
                ? token.substring(0,separator) : "";
    }
    private static String moduleFailure(String line,boolean fatalOnly) {
        if(line==null)return "";
        Matcher match=PE_FATAL.matcher(line);
        if(!match.find()) {match=PE_KERNEL.matcher(line);if(!match.find())match=null;}
        if(match!=null)return moduleToken(match.group(1),match.group(2));
        if(fatalOnly)return "";
        match=PE_MISSING.matcher(line);
        if(match.find())return moduleToken(match.group(1),"c0000135"); // STATUS_DLL_NOT_FOUND
        match=PE_IMPORT.matcher(line);
        return match.find()?moduleToken(match.group(1),match.group(2)):"";
    }
    private static String moduleToken(String path,String status) {
        int cut=Math.max(path.lastIndexOf('/'),path.lastIndexOf('\\'));
        String token=path.substring(cut+1).toLowerCase(Locale.ROOT)+"|"+status.toLowerCase(Locale.ROOT);
        return validModuleToken(token)?token:"";
    }
    private static boolean validModuleToken(String token) {
        return token.matches("[a-z0-9_.+\\-]{1,64}\\.(?:dll|exe)\\|[89abcdef][0-9a-f]{7}")&&!token.contains("..");
    }
    /** Deployed schema 6 is a strict allowlist. Local counters may evolve
     * independently; adding them to filter() must never break report delivery. */
    public static JSONObject forReport(JSONObject raw) throws JSONException {
        JSONObject local=filter(raw), out=new JSONObject();
        for(String key:new String[]{"sampleAtMs","bridgeFlags","viewportWidth","viewportHeight",
                "bridgeValid","controlsReady","movementReady","tutorialActive","layoutEditing",
                "windowFocused","cursorVisible","runtimeFailures","missingLibraries"})
            if(local.has(key))out.put(key,local.get(key));
        return out;
    }
    /** Fixed numeric milestones fit the existing report note without changing
     * the deployed strict JSON schema or disclosing window titles/arguments. */
    public static String startupSummary(JSONObject raw) throws JSONException {
        JSONObject clean=filter(raw);
        JSONArray stage=clean.optJSONArray("startupProgress");
        String summary=stage==null?"":"Startup: stage="+stage.getLong(1)+"/4, elapsedMs="+stage.getLong(2)
                +", stageAgeMs="+stage.getLong(3)+", noticeShown="+stage.getLong(4)+".\n\n";
        JSONArray vk=clean.optJSONArray("vortekStartup"), failure=clean.optJSONArray("vortekFailure");
        if(vk!=null)summary+=vortekSummary("Vortek startup",vk);
        if(failure!=null && (vk==null || !failure.toString().equals(vk.toString())))summary+=vortekSummary("Vortek failure",failure);
        JSONArray modules=clean.optJSONArray("wineModuleFailures");
        if(modules!=null && modules.length()>0) {
            summary+="Wine module errors: ";
            for(int i=0;i<modules.length();i++)summary+=(i==0?"":"; ")+modules.getString(i).replace("|"," status=0x");
            summary+=".\n\n";
        }
        // Critical startup/native errors above retain priority in the existing
        // bounded report note. Only the last state is summarized for transport.
        JSONArray views=clean.optJSONArray("viewportStates");
        if(views!=null && views.length()>0) {
            JSONArray v=views.getJSONArray(views.length()-1);
            String line="Viewport v1: event="+v.getLong(1)+", window="+v.getLong(2)
                    +", windowRect="+rect(v,3)+", drawable="+size(v,7)+", textureOwner="+size(v,9)
                    +", textureKind="+v.getLong(11)+", full="+rect(v,12)+", shown="+rect(v,16)
                    +", crop="+v.getLong(20)+", transform="+rect(v,21)+", desktop="+size(v,25)+".\n\n";
            if(summary.length()+line.length()<=700)summary+=line;
        }
        return summary;
    }
    private static String size(JSONArray v,int start) throws JSONException {
        return v.getLong(start)+"x"+v.getLong(start+1);
    }
    private static String rect(JSONArray v,int start) throws JSONException {
        return v.getLong(start)+","+v.getLong(start+1)+","+size(v,start+2);
    }
    private static boolean validVortek(long[] v) {
        return v.length==10 && v[0]==1 && v[1]>=1 && v[1]<=20
                &&v[2]>=Integer.MIN_VALUE&&v[2]<=0 &&v[3]>=0&&v[3]<=Integer.MAX_VALUE
                &&v[4]>=0&&v[4]<=16384 &&v[5]>=0&&v[5]<=16384 &&v[6]>=0&&v[6]<=0xffffffffL
                &&v[7]>=0&&v[7]<=65535 &&v[8]>=0&&v[8]<=65535 &&v[9]>=0&&v[9]<=65535
                // Device creation precedes a swapchain/window. Keep its exact
                // failure code without inventing a format or viewport identity.
                &&(v[1]!=18 || (v[2]<0 && v[3]==0 && v[4]==0 && v[5]==0 && v[6]==0));
    }
    /** This diagnostic uses the already deployed note field. It never consumes
     * space reserved for the player's description and never uploads a PID. */
    public static String appendGameCpuComment(String comment,JSONObject raw) throws JSONException {
        JSONArray cpu=filter(raw).optJSONArray("gameProcessCpu");
        String line="Game process CPU: unavailable (no valid world interval).";
        if(cpu!=null)line=String.format(Locale.ROOT,
                "Game process CPU: mean %.1f%%, peak %.1f%%, covered %d ms, sample age %d ms, %d world intervals (100%% = one core).",
                cpu.getLong(1)/10.0,cpu.getLong(2)/10.0,cpu.getLong(3),cpu.getLong(4),cpu.getLong(5));
        String suffix=(comment.isEmpty()?"":"\n\n")+line;
        return comment.length()+suffix.length()<=1000?comment+suffix:comment;
    }
    private static String vortekSummary(String label,JSONArray v) throws JSONException {
        String[] stages={"","request","ahb","image","ahb_properties","memory_type","memory_allocate",
                "memory_bind","ready","first_present_callback","extent","java_ahb","acquire_submit",
                "present_submit","present_wait","present_index","present_fence","present_timeout","device_create","present_copy","present_gles"};
        long result=v.getLong(2);
        return label+": stage="+stages[v.getInt(1)]+", vkResult="+(result==Integer.MIN_VALUE?"unavailable":result)
                +", format="+v.getLong(3)+", extent="+v.getLong(4)+"x"+v.getLong(5)+", window="+v.getLong(6)
                +", create/ready/present="+v.getLong(7)+"/"+v.getLong(8)+"/"+v.getLong(9)+".\n\n";
    }
    public static JSONObject filter(JSONObject raw) throws JSONException {
        JSONObject out=new JSONObject(); if(raw==null)return out;
        JSONArray views=raw.optJSONArray("viewportStates"),safeViews=new JSONArray();
        if(views!=null)for(int row=Math.max(0,views.length()-8);row<views.length();row++) {
            JSONArray input=views.optJSONArray(row);
            if(input==null || input.length()!=27)continue;
            long[] v=new long[27];boolean valid=true;
            for(int i=0;i<v.length;i++) {
                Object value=input.opt(i);
                if(!(value instanceof Integer || value instanceof Long)){valid=false;break;}
                v[i]=((Number)value).longValue();
            }
            if(valid && validViewport(v))safeViews.put(new JSONArray(v));
        }
        if(safeViews.length()>0)out.put("viewportStates",safeViews);
        JSONArray cpu=raw.optJSONArray("gameProcessCpu");
        if(cpu!=null && cpu.length()==7) {
            long[] maximum={1,64000,64000,240000,86400000,24,64};
            boolean valid=true;
            for(int i=0;i<maximum.length;i++) {
                Object value=cpu.opt(i);
                long minimum=(i==0 || i==3 || i==5 || i==6)?1:0;
                if(!(value instanceof Integer||value instanceof Long)
                        ||((Number)value).longValue()<minimum||((Number)value).longValue()>maximum[i])valid=false;
            }
            if(valid && cpu.getLong(1)<=cpu.getLong(2) && cpu.getLong(2)<=cpu.getLong(6)*1000
                    && cpu.getLong(3)>=cpu.getLong(5) && cpu.getLong(3)<=cpu.getLong(5)*10000)
                out.put("gameProcessCpu",cpu);
        }
        for(String key:new String[]{"vortekStartup","vortekFailure"}) {
            JSONArray input=raw.optJSONArray(key);
            if(input==null||input.length()!=10)continue;
            long[] v=new long[10];boolean valid=true;
            for(int i=0;i<v.length;i++) {
                Object value=input.opt(i);
                if(!(value instanceof Integer||value instanceof Long)){valid=false;break;}
                v[i]=((Number)value).longValue();
            }
            if(valid&&validVortek(v)&&(!key.equals("vortekFailure")||v[2]<0))out.put(key,new JSONArray(v));
        }
        JSONArray startup=raw.optJSONArray("startupProgress");
        if(startup!=null && startup.length()==5) {
            long[] bounds={1,4,86400000,86400000,1};
            boolean valid=true;
            for(int i=0;i<bounds.length;i++) {
                Object value=startup.opt(i);
                if(!(value instanceof Integer||value instanceof Long)
                        ||((Number)value).longValue()<(i<2?1:0)
                        ||((Number)value).longValue()>bounds[i])valid=false;
            }
            if(valid && startup.optLong(3)<=startup.optLong(2))out.put("startupProgress",startup);
        }
        JSONArray metrics=raw.optJSONArray("bridgeMetrics");
        if(metrics!=null && metrics.length()==27 && metrics.optInt(0)==1) {
            boolean valid=true;
            for(int i=0;i<metrics.length();i++) {
                Object v=metrics.opt(i);
                if(!(v instanceof Integer||v instanceof Long)||((Number)v).longValue()<0||((Number)v).longValue()>1000000000000L)valid=false;
            }
            if(valid)out.put("bridgeMetrics",metrics);
        }
        for(String k:new String[]{"sampleAtMs","bridgeFlags","viewportWidth","viewportHeight"}) {
            Object n=raw.opt(k);
            if((n instanceof Integer||n instanceof Long)&&((Number)n).longValue()>=0&&((Number)n).longValue()<=1000000000000L)out.put(k,n);
        }
        for(String k:new String[]{"bridgeValid","controlsReady","movementReady","tutorialActive","layoutEditing","windowFocused","cursorVisible"})
            if(raw.opt(k) instanceof Boolean)out.put(k,raw.get(k));
        JSONArray modules=raw.optJSONArray("wineModuleFailures"), safeModules=new JSONArray();
        LinkedHashSet<String> seenModules=new LinkedHashSet<>();
        if(modules!=null)for(int i=0;i<Math.min(modules.length(),16)&&safeModules.length()<4;i++) {
            Object token=modules.opt(i);
            if(token instanceof String && validModuleToken((String)token) && seenModules.add((String)token))safeModules.put(token);
        }
        if(safeModules.length()>0)out.put("wineModuleFailures",safeModules);
        for(String k:new String[]{"runtimeFailures","missingLibraries"}) {
            JSONArray src=raw.optJSONArray(k),dest=new JSONArray(); LinkedHashSet<String> unique=new LinkedHashSet<>();
            if(src!=null)for(int i=0;i<Math.min(src.length(),64)&&dest.length()<(k.equals("runtimeFailures")?16:8);i++) {
                Object item=src.opt(i); if(!(item instanceof String))continue; String s=(String)item;
                boolean valid=k.equals("runtimeFailures")
                    ?s.matches("vulkan_device_lost|vulkan_device_memory|vulkan_host_memory|vulkan_incompatible_driver|vulkan_feature_missing|vulkan_extension_missing|native_library_missing|ntdll_load_failed|nls_load_failed|guest_page_fault|guest_illegal_instruction|runtime_permission|egl_allocation_failed|egl_context_lost")
                    :s.matches("[A-Za-z0-9_.+\\-]{1,100}\\.so(?:\\.[0-9]{1,3}){0,3}")&&!s.contains("..");
                if(valid&&unique.add(s))dest.put(s);
            }
            out.put(k,dest);
        }
        return out;
    }
}
