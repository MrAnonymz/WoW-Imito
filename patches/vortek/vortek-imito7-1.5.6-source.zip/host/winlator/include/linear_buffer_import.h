/* Import ONLY a fresh buffer whose complete byte layout has been verified by
 * fresh_linear_buffer.h. This does not discover layouts of arbitrary AHBs.
 * The caller retains the AHB and layout fd while the imported image is in use.
 * Device extensions must be enabled; missing functions fail closed.
 */
#ifndef IMITO_LINEAR_BUFFER_IMPORT_H
#define IMITO_LINEAR_BUFFER_IMPORT_H
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <vulkan/vulkan.h>
#ifndef LINEAR_BUFFER_DUP_FD
#include <fcntl.h>
#include <unistd.h>
#define LINEAR_BUFFER_DUP_FD(fd) fcntl((fd),F_DUPFD_CLOEXEC,0)
#define LINEAR_BUFFER_CLOSE_FD(fd) close(fd)
#endif

typedef struct LinearBufferLayout {
    int fd; /* borrowed; importer duplicates it */
    uint64_t bytes;
    uint32_t width,height,rowPitch,androidFormat;
} LinearBufferLayout;

typedef struct LinearBufferDispatch {
    PFN_vkGetPhysicalDeviceImageFormatProperties2 getImageProperties;
    PFN_vkCreateImage createImage;
    PFN_vkDestroyImage destroyImage;
    PFN_vkGetImageMemoryRequirements getImageRequirements;
    PFN_vkGetMemoryFdPropertiesKHR getFdProperties;
    PFN_vkAllocateMemory allocateMemory;
    PFN_vkFreeMemory freeMemory;
    PFN_vkBindImageMemory bindImageMemory;
} LinearBufferDispatch;

/* On error both outputs are NULL; the caller's fd is never closed/transferred.
 * On success the VkDeviceMemory owns a separate fd, as required by Vulkan.
 * No queue submission, waiting or Android/GLES lifecycle belongs in this helper.
 */
static VkResult importLinearBufferImage(const LinearBufferDispatch* d,
        VkPhysicalDevice physical,VkDevice device,const LinearBufferLayout* b,
        VkFormat format,VkImageUsageFlags usage,VkImageCreateFlags flags,
        VkImage* outputImage,VkDeviceMemory* outputMemory) {
    if(!outputImage || !outputMemory)return VK_ERROR_INITIALIZATION_FAILED;
    *outputImage=VK_NULL_HANDLE;*outputMemory=VK_NULL_HANDLE;
    if(!d || !d->getImageProperties || !d->createImage || !d->destroyImage ||
            !d->getImageRequirements || !d->getFdProperties || !d->allocateMemory ||
            !d->freeMemory || !d->bindImageMemory)return VK_ERROR_EXTENSION_NOT_PRESENT;
    if(!b || b->fd<0 || !b->width || !b->height || b->width>2048 || b->height>2048 ||
            b->rowPitch<(uint64_t)b->width*4 || b->rowPitch%4 ||
            b->bytes<(uint64_t)b->rowPitch*b->height)return VK_ERROR_INVALID_EXTERNAL_HANDLE;
    if(!((b->androidFormat==1 && (format==VK_FORMAT_R8G8B8A8_UNORM || format==VK_FORMAT_R8G8B8A8_SRGB)) ||
         (b->androidFormat==5 && (format==VK_FORMAT_B8G8R8A8_UNORM || format==VK_FORMAT_B8G8R8A8_SRGB))))
        return VK_ERROR_FORMAT_NOT_SUPPORTED;
    VkPhysicalDeviceExternalImageFormatInfo externalQuery={
        .sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_EXTERNAL_IMAGE_FORMAT_INFO,
        .handleType=VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT};
    VkPhysicalDeviceImageDrmFormatModifierInfoEXT modifierQuery={
        .sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_IMAGE_DRM_FORMAT_MODIFIER_INFO_EXT,
        .pNext=&externalQuery,.drmFormatModifier=0,.sharingMode=VK_SHARING_MODE_EXCLUSIVE};
    VkPhysicalDeviceImageFormatInfo2 query={.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_IMAGE_FORMAT_INFO_2,
        .pNext=&modifierQuery,.format=format,.type=VK_IMAGE_TYPE_2D,
        .tiling=VK_IMAGE_TILING_DRM_FORMAT_MODIFIER_EXT,.usage=usage,.flags=flags};
    VkExternalImageFormatProperties externalProperties={.sType=VK_STRUCTURE_TYPE_EXTERNAL_IMAGE_FORMAT_PROPERTIES};
    VkImageFormatProperties2 properties={.sType=VK_STRUCTURE_TYPE_IMAGE_FORMAT_PROPERTIES_2,.pNext=&externalProperties};
    VkResult result=d->getImageProperties(physical,&query,&properties);
    if(result!=VK_SUCCESS)return result;
    if(!(externalProperties.externalMemoryProperties.externalMemoryFeatures&VK_EXTERNAL_MEMORY_FEATURE_IMPORTABLE_BIT) ||
            !(externalProperties.externalMemoryProperties.compatibleHandleTypes&VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT) ||
            properties.imageFormatProperties.maxExtent.width<b->width ||
            properties.imageFormatProperties.maxExtent.height<b->height ||
            !(properties.imageFormatProperties.sampleCounts&VK_SAMPLE_COUNT_1_BIT))return VK_ERROR_FORMAT_NOT_SUPPORTED;
    VkSubresourceLayout layout={.offset=0,.rowPitch=b->rowPitch};
    VkImageDrmFormatModifierExplicitCreateInfoEXT modifier={
        .sType=VK_STRUCTURE_TYPE_IMAGE_DRM_FORMAT_MODIFIER_EXPLICIT_CREATE_INFO_EXT,
        .drmFormatModifier=0,.drmFormatModifierPlaneCount=1,.pPlaneLayouts=&layout};
    VkExternalMemoryImageCreateInfo external={.sType=VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_IMAGE_CREATE_INFO,
        .pNext=&modifier,.handleTypes=VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT};
    VkImageCreateInfo create={.sType=VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,.pNext=&external,
        .flags=flags,.imageType=VK_IMAGE_TYPE_2D,.format=format,.extent={b->width,b->height,1},.mipLevels=1,.arrayLayers=1,
        .samples=VK_SAMPLE_COUNT_1_BIT,.tiling=VK_IMAGE_TILING_DRM_FORMAT_MODIFIER_EXT,.usage=usage,
        .sharingMode=VK_SHARING_MODE_EXCLUSIVE,.initialLayout=VK_IMAGE_LAYOUT_UNDEFINED};
    VkImage image=VK_NULL_HANDLE;VkDeviceMemory memory=VK_NULL_HANDLE;
    int importingFd=-1;bool allocated=false;
    result=d->createImage(device,&create,NULL,&image);
    if(result!=VK_SUCCESS)return result;
    VkMemoryRequirements requirements={0};d->getImageRequirements(device,image,&requirements);
    if(!requirements.size || requirements.size>b->bytes){result=VK_ERROR_INVALID_EXTERNAL_HANDLE;goto fail;}
    VkMemoryFdPropertiesKHR fdProperties={.sType=VK_STRUCTURE_TYPE_MEMORY_FD_PROPERTIES_KHR};
    result=d->getFdProperties(device,VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT,b->fd,&fdProperties);
    if(result!=VK_SUCCESS)goto fail;
    uint32_t bits=requirements.memoryTypeBits&fdProperties.memoryTypeBits;
    if(!bits){result=VK_ERROR_INVALID_EXTERNAL_HANDLE;goto fail;}
    importingFd=LINEAR_BUFFER_DUP_FD(b->fd);
    if(importingFd<0){result=VK_ERROR_OUT_OF_HOST_MEMORY;goto fail;}
    VkMemoryDedicatedAllocateInfo dedicated={.sType=VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO,.image=image};
    VkImportMemoryFdInfoKHR import={.sType=VK_STRUCTURE_TYPE_IMPORT_MEMORY_FD_INFO_KHR,
        .pNext=&dedicated,.handleType=VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT,.fd=importingFd};
    VkMemoryAllocateInfo allocation={.sType=VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,.pNext=&import,
        .allocationSize=requirements.size,.memoryTypeIndex=(uint32_t)__builtin_ctz(bits)};
    result=d->allocateMemory(device,&allocation,NULL,&memory);
    if(result!=VK_SUCCESS)goto fail;
    allocated=true;importingFd=-1;
    result=d->bindImageMemory(device,image,memory,0);
    if(result!=VK_SUCCESS)goto fail;
    *outputImage=image;*outputMemory=memory;return VK_SUCCESS;
fail:
    d->destroyImage(device,image,NULL);
    if(allocated)d->freeMemory(device,memory,NULL);
    if(importingFd>=0)LINEAR_BUFFER_CLOSE_FD(importingFd);
    return result;
}
#endif
