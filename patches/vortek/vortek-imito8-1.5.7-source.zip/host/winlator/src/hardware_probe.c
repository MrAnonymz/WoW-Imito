#include <jni.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>
#include <errno.h>
#include <poll.h>
#include <sys/eventfd.h>
#include <sys/resource.h>
#include "vulkan_loader.h"
#define VK_NO_PROTOTYPES 1
#include <vulkan/vulkan.h>
#include "vulkan_dxvk_requirements.h"
extern bool probeVulkanInterop(VkDevice device, uint32_t queueFamily, PFN_vkGetDeviceProcAddr getProc);
extern bool probeLinearVulkanInterop(VkPhysicalDevice,VkDevice,uint32_t,PFN_vkGetInstanceProcAddr,VkInstance,PFN_vkGetDeviceProcAddr);

/* Run once before this app starts Wine. No background work, GPU calls, or
 * manufacturer assumptions. Raising our own soft FD limit reserves no memory;
 * the kernel hard limit is never changed. Wine clients and wineserver inherit
 * the same result and capacity. Keep the established non-esync path if denied. */
JNIEXPORT jboolean JNICALL
Java_com_winlator_wowmobile_WrathRTSyncPolicy_prepareEventSync(JNIEnv *env, jclass cls) {
    // Our 3.3.5 workloads use approximately 3-4K descriptors per process,
    // including the modified client. Require at least 32K for headroom; the
    // much larger desktop-wide recommendation is not a Wine API requirement.
    const rlim_t required = 32768;
    struct rlimit limit;
    if (getrlimit(RLIMIT_NOFILE, &limit) != 0 || limit.rlim_max < required) return JNI_FALSE;
    int fd = eventfd(0, EFD_CLOEXEC | EFD_NONBLOCK | EFD_SEMAPHORE);
    if (fd < 0) return JNI_FALSE;
    uint64_t sent = 2, received = 0;
    struct pollfd ready = {.fd = fd, .events = POLLIN};
    bool ok = write(fd, &sent, sizeof(sent)) == sizeof(sent) &&
        poll(&ready, 1, 0) == 1 && (ready.revents & POLLIN) &&
        read(fd, &received, sizeof(received)) == sizeof(received) && received == 1 &&
        read(fd, &received, sizeof(received)) == sizeof(received) && received == 1;
    if (ok) {
        errno = 0;
        ok = read(fd, &received, sizeof(received)) == -1 && errno == EAGAIN;
    }
    close(fd);
    if (!ok) return JNI_FALSE;
    if (limit.rlim_cur < required) {
        limit.rlim_cur = required;
        if (setrlimit(RLIMIT_NOFILE, &limit) != 0) return JNI_FALSE;
        if (getrlimit(RLIMIT_NOFILE, &limit) != 0 || limit.rlim_cur < required) return JNI_FALSE;
    }
    return JNI_TRUE;
}

/* Flags: device+queue/readback smoke test, baseline D3D9 features/formats, native BC,
 * Vulkan 1.3 synchronization features. DXVK still validates its full requirements
 * through the runtime bridge. This probe must enable what it claims to test. */
static jlongArray measureVulkan(JNIEnv *env, jstring nativeLibraryDir, jstring customPath,
        bool testAlternatePresentation) {
    jlong values[5] = {0};
    VkInstance instance = VK_NULL_HANDLE;
    VkDevice device = VK_NULL_HANDLE;
    VkDeviceMemory memory = VK_NULL_HANDLE;
    VkBuffer buffer = VK_NULL_HANDLE;
    VkCommandPool pool = VK_NULL_HANDLE;
    VkFence fence = VK_NULL_HANDLE;
    int submitted = 0;
    void *mapped = NULL;
    VkExtensionProperties *extensions = NULL;
    VkQueueFamilyProperties *queues = NULL;
    void *library = openAndroidVulkan(env, nativeLibraryDir, customPath);
    PFN_vkDestroyInstance destroyInstance = NULL;
    PFN_vkDestroyDevice destroyDevice = NULL;
    PFN_vkFreeMemory freeMemory = NULL;
    PFN_vkUnmapMemory unmapMemory = NULL;
    PFN_vkDestroyBuffer destroyBuffer = NULL;
    PFN_vkDestroyCommandPool destroyPool = NULL;
    PFN_vkDestroyFence destroyFence = NULL;
    PFN_vkDeviceWaitIdle waitIdle = NULL;
    if (!library) goto done;
#define LOAD(name) PFN_##name name = (PFN_##name)dlsym(library, #name); if (!name) goto done
    LOAD(vkCreateInstance);
    LOAD(vkEnumeratePhysicalDevices);
    LOAD(vkGetPhysicalDeviceProperties);
    LOAD(vkGetPhysicalDeviceFeatures);
    LOAD(vkGetPhysicalDeviceFormatProperties);
    LOAD(vkGetPhysicalDeviceMemoryProperties);
    LOAD(vkGetPhysicalDeviceQueueFamilyProperties);
    LOAD(vkEnumerateDeviceExtensionProperties);
    LOAD(vkCreateDevice);
    LOAD(vkAllocateMemory);
    LOAD(vkMapMemory);
    LOAD(vkCreateBuffer);
    LOAD(vkGetBufferMemoryRequirements);
    LOAD(vkBindBufferMemory);
    LOAD(vkCreateCommandPool);
    LOAD(vkAllocateCommandBuffers);
    LOAD(vkBeginCommandBuffer);
    LOAD(vkEndCommandBuffer);
    LOAD(vkCmdFillBuffer);
    LOAD(vkCmdPipelineBarrier);
    LOAD(vkGetDeviceQueue);
    LOAD(vkCreateFence);
    LOAD(vkQueueSubmit);
    LOAD(vkWaitForFences);
    LOAD(vkInvalidateMappedMemoryRanges);
    destroyInstance = dlsym(library, "vkDestroyInstance");
    destroyDevice = dlsym(library, "vkDestroyDevice");
    freeMemory = dlsym(library, "vkFreeMemory");
    unmapMemory = dlsym(library, "vkUnmapMemory");
    destroyBuffer = dlsym(library, "vkDestroyBuffer");
    destroyPool = dlsym(library, "vkDestroyCommandPool");
    destroyFence = dlsym(library, "vkDestroyFence");
    waitIdle = dlsym(library, "vkDeviceWaitIdle");
    if (!destroyInstance || !destroyDevice || !freeMemory || !unmapMemory ||
        !destroyBuffer || !destroyPool || !destroyFence || !waitIdle) goto done;
    uint32_t loaderVersion = VK_API_VERSION_1_0;
    PFN_vkEnumerateInstanceVersion enumerateVersion = dlsym(library, "vkEnumerateInstanceVersion");
    if (enumerateVersion && enumerateVersion(&loaderVersion) != VK_SUCCESS) goto done;
    VkApplicationInfo app = {.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO,
            .pApplicationName = "Imito hardware check",
            .apiVersion = loaderVersion < VK_API_VERSION_1_3 ? loaderVersion : VK_API_VERSION_1_3};
    VkInstanceCreateInfo info = {.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO, .pApplicationInfo = &app};
    if (vkCreateInstance(&info, NULL, &instance) != VK_SUCCESS) goto done;
    uint32_t count = 1;
    VkPhysicalDevice physical = VK_NULL_HANDLE;
    VkResult result = vkEnumeratePhysicalDevices(instance, &count, &physical);
    if ((result != VK_SUCCESS && result != VK_INCOMPLETE) || count == 0 || !physical) goto done;
    VkPhysicalDeviceProperties properties;
    vkGetPhysicalDeviceProperties(physical, &properties);
    values[0] = properties.apiVersion < loaderVersion ? properties.apiVersion : loaderVersion;
    values[1] = properties.driverVersion; values[2] = properties.vendorID; values[3] = properties.deviceID;
    VkPhysicalDeviceFeatures features;
    vkGetPhysicalDeviceFeatures(physical, &features);
    VkFormatProperties colour, depth;
    vkGetPhysicalDeviceFormatProperties(physical, VK_FORMAT_R8G8B8A8_UNORM, &colour);
    vkGetPhysicalDeviceFormatProperties(physical, VK_FORMAT_D24_UNORM_S8_UINT, &depth);
    if (!(depth.optimalTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT))
        vkGetPhysicalDeviceFormatProperties(physical, VK_FORMAT_D32_SFLOAT_S8_UINT, &depth);
    VkFormatFeatureFlags requiredColour = VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT | VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT;
    count = 0;
    if (vkEnumerateDeviceExtensionProperties(physical, NULL, &count, NULL) != VK_SUCCESS || count > 4096) goto done;
    extensions = calloc(count, sizeof(*extensions));
    if (count && !extensions) goto done;
    if (vkEnumerateDeviceExtensionProperties(physical, NULL, &count, extensions) != VK_SUCCESS) goto done;
    int swapchain = 0, ahb = 0, foreignQueue = 0, robustness2 = 0, hostQueryExtension = 0, dma=0, fd=0, modifier=0;
    for (uint32_t i = 0; i < count; ++i) {
        if (!strcmp(extensions[i].extensionName, "VK_KHR_swapchain")) swapchain = 1;
        if(!strcmp(extensions[i].extensionName,"VK_KHR_external_memory_fd"))fd=1;
        if(!strcmp(extensions[i].extensionName,"VK_EXT_external_memory_dma_buf"))dma=1;
        if(!strcmp(extensions[i].extensionName,"VK_EXT_image_drm_format_modifier"))modifier=1;
        if (!strcmp(extensions[i].extensionName, "VK_ANDROID_external_memory_android_hardware_buffer")) ahb = 1;
        if (!strcmp(extensions[i].extensionName, "VK_EXT_queue_family_foreign")) foreignQueue = 1;
        if (!strcmp(extensions[i].extensionName, VK_EXT_ROBUSTNESS_2_EXTENSION_NAME)) robustness2 = 1;
        if (!strcmp(extensions[i].extensionName, VK_EXT_HOST_QUERY_RESET_EXTENSION_NAME)) hostQueryExtension = 1;
    }
    PFN_vkGetPhysicalDeviceFeatures2 features2 = dlsym(library, "vkGetPhysicalDeviceFeatures2");
    VkPhysicalDeviceHostQueryResetFeatures hostQuery = {
            .sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_HOST_QUERY_RESET_FEATURES};
    if (features2 && (values[0] >= VK_API_VERSION_1_2 || hostQueryExtension)) {
        VkPhysicalDeviceFeatures2 extended = {.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2, .pNext=&hostQuery};
        features2(physical, &extended);
    }
    // Host query reset is required even by DXVK 1.10.3. Vortek forwards it;
    // its BC-texture fallback does not emulate missing query/geometry features.
    // Preserve the reason in the existing report flags. Low capability bits
    // remain unchanged; reporting only "8" previously lost which baseline
    // requirement rejected an otherwise modern Vulkan device. Bit 11 records
    // optional anisotropy availability; it is not a rejection reason.
    if (!features.geometryShader) values[4] |= 1LL << 8;
    if (!features.robustBufferAccess) values[4] |= 1LL << 9;
    if (!features.shaderClipDistance) values[4] |= 1LL << 10;
    if (!features.samplerAnisotropy) values[4] |= 1LL << 11;
    if (!features.independentBlend) values[4] |= 1LL << 12;
    if (!features.fillModeNonSolid) values[4] |= 1LL << 13;
    if (!hostQuery.hostQueryReset) values[4] |= 1LL << 14;
    if (!swapchain) values[4] |= 1LL << 15;
    if ((colour.optimalTilingFeatures & requiredColour) != requiredColour ||
        !(depth.optimalTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT)) values[4] |= 1LL << 16;
    if (supportsDxvkBaselineFeatures(&features, hostQuery.hostQueryReset) &&
        swapchain && (colour.optimalTilingFeatures & requiredColour) == requiredColour &&
        (depth.optimalTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT)) values[4] |= 2;
    if (features.textureCompressionBC) values[4] |= 4;
    if (values[0] >= VK_MAKE_VERSION(1,3,0)) {
        if (features2) {
            VkPhysicalDeviceRobustness2FeaturesEXT robust = {
                    .sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ROBUSTNESS_2_FEATURES_EXT};
            VkPhysicalDeviceVulkan13Features f13 = {.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES,
                    .pNext=robustness2 ? &robust : NULL};
            VkPhysicalDeviceVulkan12Features f12 = {.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES, .pNext=&f13};
            VkPhysicalDeviceFeatures2 f2 = {.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2, .pNext=&f12};
            features2(physical, &f2);
            if (features.robustBufferAccess && supportsModernDxvk(&f12, &f13, &robust, robustness2)) values[4] |= 8;
        }
    }
    count = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(physical, &count, NULL);
    if (!count || count > 256) goto done;
    queues = calloc(count, sizeof(*queues));
    if (!queues) goto done;
    vkGetPhysicalDeviceQueueFamilyProperties(physical, &count, queues);
    uint32_t queue = count;
    const VkQueueFlags requiredQueue = VK_QUEUE_GRAPHICS_BIT | VK_QUEUE_COMPUTE_BIT;
    for (uint32_t i = 0; i < count; ++i)
        if (queues[i].queueCount && (queues[i].queueFlags & requiredQueue) == requiredQueue) { queue = i; break; }
    if (queue == count) goto done;
    if (!(values[4] & 2)) goto done;
    float priority = 1.0f;
    VkDeviceQueueCreateInfo queueInfo = {.sType=VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
            .queueFamilyIndex=queue, .queueCount=1, .pQueuePriorities=&priority};
    VkPhysicalDeviceFeatures enabled = {.shaderClipDistance=VK_TRUE, .samplerAnisotropy=features.samplerAnisotropy,
            .independentBlend=VK_TRUE, .fillModeNonSolid=VK_TRUE, .robustBufferAccess=VK_TRUE,
            .geometryShader=VK_TRUE};
    int interopEligible = ahb && foreignQueue && values[0] >= VK_API_VERSION_1_1;
    int dmaEligible=foreignQueue && dma && fd && modifier && values[0]>=VK_API_VERSION_1_2;
    const char *enabledExtensions[8] = {VK_KHR_SWAPCHAIN_EXTENSION_NAME};
    uint32_t legacyExtensionCount = 1;
    if (interopEligible) {
        enabledExtensions[legacyExtensionCount++] = "VK_ANDROID_external_memory_android_hardware_buffer";

    }
    if(interopEligible || dmaEligible)enabledExtensions[legacyExtensionCount++]="VK_EXT_queue_family_foreign";
    if(dmaEligible) {
        enabledExtensions[legacyExtensionCount++]="VK_KHR_external_memory_fd";
        enabledExtensions[legacyExtensionCount++]="VK_EXT_external_memory_dma_buf";
        enabledExtensions[legacyExtensionCount++]="VK_EXT_image_drm_format_modifier";
    }
    if (values[0] < VK_API_VERSION_1_2)
        enabledExtensions[legacyExtensionCount++] = VK_EXT_HOST_QUERY_RESET_EXTENSION_NAME;
    if (values[4] & 8) enabledExtensions[legacyExtensionCount] = VK_EXT_ROBUSTNESS_2_EXTENSION_NAME;
    VkDeviceCreateInfo deviceInfo = {.sType=VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO,
            .pNext=&hostQuery,
            .queueCreateInfoCount=1, .pQueueCreateInfos=&queueInfo, .pEnabledFeatures=&enabled,
            .enabledExtensionCount=legacyExtensionCount + !!(values[4] & 8), .ppEnabledExtensionNames=enabledExtensions};
    // Querying bits is insufficient: actually enable the modern requirements.
    VkPhysicalDeviceRobustness2FeaturesEXT enabledRobust = {
            .sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ROBUSTNESS_2_FEATURES_EXT,
            .robustBufferAccess2=VK_TRUE, .nullDescriptor=VK_TRUE};
    VkPhysicalDeviceVulkan13Features enabled13 = {.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES,
            .pNext=&enabledRobust, .synchronization2=VK_TRUE, .dynamicRendering=VK_TRUE,
            .maintenance4=VK_TRUE, .shaderDemoteToHelperInvocation=VK_TRUE};
    VkPhysicalDeviceVulkan12Features enabled12 = {.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES,
            .pNext=&enabled13, .timelineSemaphore=VK_TRUE, .hostQueryReset=VK_TRUE,
            .vulkanMemoryModel=VK_TRUE, .samplerMirrorClampToEdge=VK_TRUE};
    if (values[4] & 8) deviceInfo.pNext = &enabled12;
    if (vkCreateDevice(physical, &deviceInfo, NULL, &device) != VK_SUCCESS) {
        values[4] &= ~8LL;
        deviceInfo.pNext = &hostQuery;
        deviceInfo.enabledExtensionCount = legacyExtensionCount;
        device = VK_NULL_HANDLE;
        if (vkCreateDevice(physical, &deviceInfo, NULL, &device) != VK_SUCCESS) goto done;
    }
    VkBufferCreateInfo bufferInfo = {.sType=VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
            .size=4096, .usage=VK_BUFFER_USAGE_TRANSFER_DST_BIT, .sharingMode=VK_SHARING_MODE_EXCLUSIVE};
    if (vkCreateBuffer(device, &bufferInfo, NULL, &buffer) != VK_SUCCESS) goto done;
    VkMemoryRequirements requirements;
    vkGetBufferMemoryRequirements(device, buffer, &requirements);
    VkPhysicalDeviceMemoryProperties mem;
    vkGetPhysicalDeviceMemoryProperties(physical, &mem);
    uint32_t type = mem.memoryTypeCount;
    if (type > VK_MAX_MEMORY_TYPES) goto done;
    for (uint32_t i = 0; i < mem.memoryTypeCount; ++i)
        if ((requirements.memoryTypeBits & (1u << i)) &&
            (mem.memoryTypes[i].propertyFlags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) { type = i; break; }
    if (type == mem.memoryTypeCount) goto done;
    VkMemoryAllocateInfo allocation = {.sType=VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
            .allocationSize=requirements.size, .memoryTypeIndex=type};
    if (vkAllocateMemory(device, &allocation, NULL, &memory) != VK_SUCCESS) goto done;
    if (vkBindBufferMemory(device, buffer, memory, 0) != VK_SUCCESS) goto done;
    if (vkMapMemory(device, memory, 0, VK_WHOLE_SIZE, 0, &mapped) != VK_SUCCESS || !mapped) goto done;
    VkCommandPoolCreateInfo poolInfo = {.sType=VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO, .queueFamilyIndex=queue};
    if (vkCreateCommandPool(device, &poolInfo, NULL, &pool) != VK_SUCCESS) goto done;
    VkCommandBuffer command;
    VkCommandBufferAllocateInfo commandInfo = {.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
            .commandPool=pool, .level=VK_COMMAND_BUFFER_LEVEL_PRIMARY, .commandBufferCount=1};
    if (vkAllocateCommandBuffers(device, &commandInfo, &command) != VK_SUCCESS) goto done;
    VkCommandBufferBeginInfo begin = {.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
            .flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT};
    if (vkBeginCommandBuffer(command, &begin) != VK_SUCCESS) goto done;
    vkCmdFillBuffer(command, buffer, 0, 4096, 0x35353535);
    VkBufferMemoryBarrier barrier = {.sType=VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER,
            .srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT, .dstAccessMask=VK_ACCESS_HOST_READ_BIT,
            .srcQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED, .dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED,
            .buffer=buffer, .offset=0, .size=VK_WHOLE_SIZE};
    vkCmdPipelineBarrier(command, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_HOST_BIT,
            0, 0, NULL, 1, &barrier, 0, NULL);
    if (vkEndCommandBuffer(command) != VK_SUCCESS) goto done;
    VkFenceCreateInfo fenceInfo = {.sType=VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    if (vkCreateFence(device, &fenceInfo, NULL, &fence) != VK_SUCCESS) goto done;
    VkQueue deviceQueue;
    vkGetDeviceQueue(device, queue, 0, &deviceQueue);
    VkSubmitInfo submit = {.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO, .commandBufferCount=1, .pCommandBuffers=&command};
    if (vkQueueSubmit(deviceQueue, 1, &submit, fence) != VK_SUCCESS) goto done;
    submitted = 1;
    if (vkWaitForFences(device, 1, &fence, VK_TRUE, 2000000000ULL) != VK_SUCCESS) goto done;
    submitted = 0;
    VkMappedMemoryRange range = {.sType=VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE, .memory=memory,
            .offset=0, .size=VK_WHOLE_SIZE};
    if (vkInvalidateMappedMemoryRanges(device, 1, &range) != VK_SUCCESS) goto done;
    for (unsigned int i=0; i<4096; ++i) if (((const unsigned char *)mapped)[i] != 0x35) goto done;
    values[4] |= 1;
    PFN_vkGetDeviceProcAddr getDeviceProc = dlsym(library, "vkGetDeviceProcAddr");
    if (interopEligible && getDeviceProc && probeVulkanInterop(device, queue, getDeviceProc)) values[4] |= 16;
    // Separate capability: native Wine/FEX/Forever cannot consume this fallback.
    PFN_vkGetInstanceProcAddr getInstanceProc=dlsym(library,"vkGetInstanceProcAddr");
    if((!(values[4]&16) || testAlternatePresentation) && dmaEligible && getDeviceProc && getInstanceProc &&
            probeLinearVulkanInterop(physical,device,queue,getInstanceProc,instance,getDeviceProc))values[4]|=32;
done:
    // The Java parent terminates this isolated process if a driver wedges here.
    if (submitted && waitIdle) waitIdle(device);
    if (fence && destroyFence) destroyFence(device, fence, NULL);
    if (pool && destroyPool) destroyPool(device, pool, NULL);
    if (mapped && unmapMemory) unmapMemory(device, memory);
    if (buffer && destroyBuffer) destroyBuffer(device, buffer, NULL);
    if (memory && freeMemory) freeMemory(device, memory, NULL);
    if (device && destroyDevice) destroyDevice(device, NULL);
    if (instance && destroyInstance) destroyInstance(instance, NULL);
    free(extensions); free(queues);
    if (library) dlclose(library);
    jlongArray output = (*env)->NewLongArray(env, 5);
    if (output) (*env)->SetLongArrayRegion(env, output, 0, 5, values);
    return output;
}

JNIEXPORT jlongArray JNICALL
Java_com_winlator_wowmobile_WrathRTHardwareProbeService_probeVulkan(JNIEnv *env, jclass cls,
        jstring nativeLibraryDir, jstring customPath) {
    return measureVulkan(env, nativeLibraryDir, customPath, false);
}

JNIEXPORT jlongArray JNICALL
Java_com_winlator_wowmobile_WrathRTHardwareProbeService_probePanvkPresentationRetry(JNIEnv *env, jclass cls,
        jstring nativeLibraryDir, jstring customPath) {
    return measureVulkan(env, nativeLibraryDir, customPath, true);
}
