#include <malloc.h>
#include <string.h>
#include <jni.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdbool.h>

#include "winlator.h"
#include "socket_utils.h"

/* A single 4K RGBA GetImage reply fits. A stalled peer cannot retain an
 * unbounded number of replies, input events, or duplicated ancillary fds. */
#define XOUTPUT_MAX_PENDING_BYTES (32u * 1024u * 1024u)
#define XOUTPUT_MAX_PENDING_PACKETS 4096u

typedef struct XOutputPacket {
    struct XOutputPacket* next;
    size_t length;
    size_t offset;
    int ancillaryFd;
    unsigned char data[];
} XOutputPacket;

typedef struct XOutputStream {
    /* Own a duplicate: connector teardown may close and reuse the original fd
     * before this writer finishes. Never send to a recycled descriptor. */
    int fd;
    int ancillaryFd;
    pthread_mutex_t mutex;
    pthread_cond_t available;
    pthread_t worker;
    bool workerStarted;
    bool stopping;
    bool failed;
    /* Builder methods run under Java's output lock; the worker never touches
     * this flag or buffer. Only terminal errors take the queue mutex. */
    bool bufferFailed;
    XOutputPacket* first;
    XOutputPacket* last;
    size_t pendingBytes;
    unsigned int pendingPackets;
    struct {
        void* data;
        int capacity;
        int position;
        int limit;
    } buffer;
} XOutputStream;

static ssize_t XOutputStream_sendBytes(int fd, const void* data, size_t size, int ancillaryFd) {
    if (ancillaryFd < 0)
        return send(fd, data, size, MSG_DONTWAIT | MSG_NOSIGNAL);

    struct iovec iov = {.iov_base = (void*)data, .iov_len = size};
    union {
        struct cmsghdr alignment;
        char bytes[CMSG_SPACE(sizeof(int))];
    } control = {0};
    struct msghdr message = {.msg_iov = &iov, .msg_iovlen = 1,
        .msg_control = control.bytes, .msg_controllen = sizeof(control.bytes)};
    struct cmsghdr* cmsg = CMSG_FIRSTHDR(&message);
    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type = SCM_RIGHTS;
    cmsg->cmsg_len = CMSG_LEN(sizeof(int));
    memcpy(CMSG_DATA(cmsg), &ancillaryFd, sizeof(int));
    return sendmsg(fd, &message, MSG_DONTWAIT | MSG_NOSIGNAL);
}

/* Caller holds mutex. A terminal error is a closed connection, never a
 * successful truncated packet. shutdown also wakes the connector's reader
 * and any writer poll without waiting for the guest. */
static void XOutputStream_fail(XOutputStream* outputStream) {
    if (!outputStream->failed) {
        outputStream->failed = true;
        shutdown(outputStream->fd, SHUT_RDWR);
        pthread_cond_broadcast(&outputStream->available);
    }
}

static void XOutputStream_freePackets(XOutputStream* outputStream) {
    while (outputStream->first) {
        XOutputPacket* packet = outputStream->first;
        outputStream->first = packet->next;
        if (packet->ancillaryFd >= 0) close(packet->ancillaryFd);
        free(packet);
    }
    outputStream->last = NULL;
    outputStream->pendingBytes = 0;
    outputStream->pendingPackets = 0;
}

static void* XOutputStream_writer(void* value) {
    XOutputStream* outputStream = value;
    for (;;) {
        pthread_mutex_lock(&outputStream->mutex);
        while (!outputStream->first && !outputStream->stopping && !outputStream->failed)
            pthread_cond_wait(&outputStream->available, &outputStream->mutex);
        if (outputStream->stopping || outputStream->failed) {
            XOutputStream_freePackets(outputStream);
            pthread_mutex_unlock(&outputStream->mutex);
            return NULL;
        }
        XOutputPacket* packet = outputStream->first;
        pthread_mutex_unlock(&outputStream->mutex);

        ssize_t sent = XOutputStream_sendBytes(outputStream->fd,
            packet->data + packet->offset, packet->length - packet->offset, packet->ancillaryFd);
        if (sent > 0) {
            pthread_mutex_lock(&outputStream->mutex);
            packet->offset += (size_t)sent;
            /* SCM_RIGHTS is delivered with the first positive send only. */
            if (packet->ancillaryFd >= 0) {
                close(packet->ancillaryFd);
                packet->ancillaryFd = -1;
            }
            if (packet->offset == packet->length) {
                outputStream->first = packet->next;
                if (!outputStream->first) outputStream->last = NULL;
                outputStream->pendingBytes -= packet->length;
                outputStream->pendingPackets--;
                free(packet);
            }
            pthread_mutex_unlock(&outputStream->mutex);
            continue;
        }
        if (sent < 0 && errno == EINTR) continue;
        if (sent < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            /* Only this private worker waits for the peer. Java output/Xserver
             * locks are released as soon as a complete packet is queued. */
            struct pollfd waiting = {.fd = outputStream->fd, .events = POLLOUT};
            int ready = poll(&waiting, 1, -1);
            if (ready > 0 || (ready < 0 && errno == EINTR)) continue;
        }
        pthread_mutex_lock(&outputStream->mutex);
        XOutputStream_fail(outputStream);
        pthread_mutex_unlock(&outputStream->mutex);
    }
}

static bool XOutputStream_bufferFailure(XOutputStream* outputStream) {
    outputStream->bufferFailed = true;
    pthread_mutex_lock(&outputStream->mutex);
    XOutputStream_fail(outputStream);
    pthread_mutex_unlock(&outputStream->mutex);
    return false;
}

static bool ensureSpaceIsAvailable(XOutputStream* outputStream, int length) {
    if (outputStream->bufferFailed) return false;
    if (length < 0 || outputStream->buffer.position < 0 ||
            (unsigned int)outputStream->buffer.position > XOUTPUT_MAX_PENDING_BYTES ||
            (unsigned int)length > XOUTPUT_MAX_PENDING_BYTES -
            (unsigned int)outputStream->buffer.position)
        return XOutputStream_bufferFailure(outputStream);
    if ((outputStream->buffer.capacity - outputStream->buffer.position) >= length) return true;

    int required = outputStream->buffer.position + length;
    int newCapacity = outputStream->buffer.capacity ? outputStream->buffer.capacity : 64;
    while (newCapacity < required)
        newCapacity = (unsigned int)newCapacity > XOUTPUT_MAX_PENDING_BYTES / 2 ?
                XOUTPUT_MAX_PENDING_BYTES : newCapacity * 2;
    void* newData = realloc(outputStream->buffer.data, newCapacity);
    if (!newData) return XOutputStream_bufferFailure(outputStream);
    outputStream->buffer.capacity = newCapacity;
    outputStream->buffer.limit = newCapacity;
    outputStream->buffer.data = newData;
    return true;
}

static XOutputStream* XOutputStream_allocate(int fd, int initialCapacity) {
    if (initialCapacity < 0 || (unsigned int)initialCapacity > XOUTPUT_MAX_PENDING_BYTES) return NULL;
    XOutputStream* outputStream = calloc(1, sizeof(XOutputStream));
    if (!outputStream) return NULL;
    outputStream->fd = fcntl(fd, F_DUPFD_CLOEXEC, 0);
    outputStream->ancillaryFd = -1;
    if (outputStream->fd < 0) { free(outputStream); return NULL; }
    if (pthread_mutex_init(&outputStream->mutex, NULL)) {
        close(outputStream->fd); free(outputStream); return NULL;
    }
    if (pthread_cond_init(&outputStream->available, NULL)) {
        pthread_mutex_destroy(&outputStream->mutex);
        close(outputStream->fd); free(outputStream); return NULL;
    }
    outputStream->buffer.data = calloc(initialCapacity ? initialCapacity : 1, 1);
    if (!outputStream->buffer.data) {
        pthread_cond_destroy(&outputStream->available);
        pthread_mutex_destroy(&outputStream->mutex);
        close(outputStream->fd); free(outputStream); return NULL;
    }
    outputStream->buffer.capacity = initialCapacity;
    outputStream->buffer.limit = initialCapacity;
    return outputStream;
}

static void XOutputStream_destroy(XOutputStream* outputStream) {
    if (!outputStream) return;
    pthread_mutex_lock(&outputStream->mutex);
    outputStream->stopping = true;
    shutdown(outputStream->fd, SHUT_RDWR);
    pthread_cond_broadcast(&outputStream->available);
    pthread_mutex_unlock(&outputStream->mutex);
    if (outputStream->workerStarted) pthread_join(outputStream->worker, NULL);
    XOutputStream_freePackets(outputStream);
    close(outputStream->fd);
    pthread_cond_destroy(&outputStream->available);
    pthread_mutex_destroy(&outputStream->mutex);
    MEMFREE(outputStream->buffer.data);
    MEMFREE(outputStream);
}

static jboolean XOutputStream_send(XOutputStream* outputStream) {
    size_t length = (size_t)outputStream->buffer.position;
    int ancillaryFd = outputStream->ancillaryFd;
    outputStream->buffer.position = 0;
    outputStream->ancillaryFd = -1;
    pthread_mutex_lock(&outputStream->mutex);
    if (outputStream->failed || outputStream->stopping) goto failed;
    if (!length) { pthread_mutex_unlock(&outputStream->mutex); return JNI_TRUE; }
    size_t offset = 0;
    if (!outputStream->first) {
        ssize_t sent = XOutputStream_sendBytes(outputStream->fd, outputStream->buffer.data, length, ancillaryFd);
        if (sent > 0) {
            offset = (size_t)sent;
            ancillaryFd = -1;
            if (offset == length) { pthread_mutex_unlock(&outputStream->mutex); return JNI_TRUE; }
        } else if (sent == 0 || (errno != EINTR && errno != EAGAIN && errno != EWOULDBLOCK)) {
            XOutputStream_fail(outputStream);
            goto failed;
        }
    }
    length -= offset;
    if (length > XOUTPUT_MAX_PENDING_BYTES - outputStream->pendingBytes ||
            outputStream->pendingPackets >= XOUTPUT_MAX_PENDING_PACKETS) {
        XOutputStream_fail(outputStream);
        goto failed;
    }
    XOutputPacket* packet = malloc(sizeof(XOutputPacket) + length);
    if (!packet) { XOutputStream_fail(outputStream); goto failed; }
    packet->ancillaryFd = ancillaryFd < 0 ? -1 : fcntl(ancillaryFd, F_DUPFD_CLOEXEC, 0);
    if (ancillaryFd >= 0 && packet->ancillaryFd < 0) {
        free(packet); XOutputStream_fail(outputStream); goto failed;
    }
    packet->next = NULL;
    packet->length = length;
    packet->offset = 0;
    memcpy(packet->data, (unsigned char*)outputStream->buffer.data + offset, length);
    if (outputStream->last) outputStream->last->next = packet;
    else outputStream->first = packet;
    outputStream->last = packet;
    outputStream->pendingBytes += length;
    outputStream->pendingPackets++;
    if (!outputStream->workerStarted) {
        if (pthread_create(&outputStream->worker, NULL, XOutputStream_writer, outputStream)) {
            XOutputStream_fail(outputStream);
            XOutputStream_freePackets(outputStream);
            goto failed;
        }
        outputStream->workerStarted = true;
    }
    pthread_cond_signal(&outputStream->available);
    pthread_mutex_unlock(&outputStream->mutex);
    return JNI_TRUE;
failed:
    pthread_mutex_unlock(&outputStream->mutex);
    return JNI_FALSE;
}

JNIEXPORT jlong JNICALL
Java_com_winlator_xconnector_XOutputStream_nativeAllocate(JNIEnv *env, jobject obj, jint fd,
                                                          jint initialCapacity) {
    XOutputStream* outputStream = XOutputStream_allocate(fd, initialCapacity);
    return (jlong)outputStream;
}

JNIEXPORT void JNICALL
Java_com_winlator_xconnector_XOutputStream_setAncillaryFd(jlong nativePtr, jint ancillaryFd) {
    ((XOutputStream*)nativePtr)->ancillaryFd = ancillaryFd;
}

JNIEXPORT void JNICALL
Java_com_winlator_xconnector_XOutputStream_writeByte(jlong nativePtr, jbyte value) {
    XOutputStream* outputStream = (XOutputStream*)nativePtr;
    if (!ensureSpaceIsAvailable(outputStream, 1)) return;
    *(jbyte*)(outputStream->buffer.data + outputStream->buffer.position++) = value;
}

JNIEXPORT void JNICALL
Java_com_winlator_xconnector_XOutputStream_writeShort(jlong nativePtr, jshort value) {
    XOutputStream* outputStream = (XOutputStream*)nativePtr;
    if (!ensureSpaceIsAvailable(outputStream, 2)) return;
    *(jshort*)(outputStream->buffer.data + outputStream->buffer.position) = value;
    outputStream->buffer.position += 2;
}

JNIEXPORT void JNICALL
Java_com_winlator_xconnector_XOutputStream_writeInt(jlong nativePtr, jint value) {
    XOutputStream* outputStream = (XOutputStream*)nativePtr;
    if (!ensureSpaceIsAvailable(outputStream, 4)) return;
    *(jint*)(outputStream->buffer.data + outputStream->buffer.position) = value;
    outputStream->buffer.position += 4;
}

JNIEXPORT void JNICALL
Java_com_winlator_xconnector_XOutputStream_writeLong(jlong nativePtr, jlong value) {
    XOutputStream* outputStream = (XOutputStream*)nativePtr;
    if (!ensureSpaceIsAvailable(outputStream, 8)) return;
    *(jlong*)(outputStream->buffer.data + outputStream->buffer.position) = value;
    outputStream->buffer.position += 8;
}

JNIEXPORT void JNICALL
Java_com_winlator_xconnector_XOutputStream_writePad(jlong nativePtr, jint length) {
    XOutputStream* outputStream = (XOutputStream*)nativePtr;
    if (!ensureSpaceIsAvailable(outputStream, length)) return;
    memset(outputStream->buffer.data + outputStream->buffer.position, 0, length);
    outputStream->buffer.position += length;
}

JNIEXPORT void JNICALL
Java_com_winlator_xconnector_XOutputStream_writeAt(JNIEnv *env, jclass obj,
                                                   jlong nativePtr, jint position, jbyteArray data) {
    XOutputStream* outputStream = (XOutputStream*)nativePtr;
    if (outputStream->bufferFailed) return;
    if (!data) { XOutputStream_bufferFailure(outputStream); return; }
    jsize length = (*env)->GetArrayLength(env, data);
    /* writeAt patches an already built header; it must not extend the packet. */
    if (position < 0 || position > outputStream->buffer.position ||
            length > outputStream->buffer.position - position) {
        XOutputStream_bufferFailure(outputStream);
        return;
    }
    if (length) (*env)->GetByteArrayRegion(env, data, 0, length,
            (jbyte*)outputStream->buffer.data + position);
    if ((*env)->ExceptionCheck(env)) XOutputStream_bufferFailure(outputStream);
}

JNIEXPORT void JNICALL
Java_com_winlator_xconnector_XOutputStream_writeByteBuffer(JNIEnv *env, jclass obj,
                                                           jlong nativePtr, jobject data,
                                                           jint offset, jint length) {
    XOutputStream* outputStream = (XOutputStream*)nativePtr;
    if (outputStream->bufferFailed) return;
    if (!data || offset < 0 || length < 0) {
        XOutputStream_bufferFailure(outputStream); return;
    }
    jlong capacity = (*env)->GetDirectBufferCapacity(env, data);
    if (capacity < offset || (jlong)length > capacity - offset) {
        XOutputStream_bufferFailure(outputStream); return;
    }
    if (!length) return;
    void* dataAddr = (*env)->GetDirectBufferAddress(env, data);
    if (!dataAddr) { XOutputStream_bufferFailure(outputStream); return; }
    if (!ensureSpaceIsAvailable(outputStream, length)) return;
    memcpy(outputStream->buffer.data + outputStream->buffer.position, dataAddr + offset, length);
    outputStream->buffer.position += length;
}

JNIEXPORT jboolean JNICALL
Java_com_winlator_xconnector_XOutputStream_sendData(JNIEnv *env, jclass obj, jlong nativePtr) {
    return XOutputStream_send((XOutputStream*)nativePtr);
}

JNIEXPORT void JNICALL
Java_com_winlator_xconnector_XOutputStream_destroy(JNIEnv *env, jclass obj, jlong nativePtr) {
    XOutputStream_destroy((XOutputStream*)nativePtr);
}

JNIEXPORT jint JNICALL
Java_com_winlator_xconnector_XOutputStream_length(jlong nativePtr) {
    XOutputStream* outputStream = (XOutputStream*)nativePtr;
    return outputStream->buffer.position;
}
