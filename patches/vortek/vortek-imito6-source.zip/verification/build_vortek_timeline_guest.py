"""Build a staged classic Vortek guest; never update APK/source asset inputs.

Uses the existing pinned b1730c5 tree, glibc sysroot and NDK 24 toolchain.
The selected revision replaces only the guest ELF in the previous archive.
Root may integrate it after reviewing the paired host/guest contract test.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import io
import json
import os
import struct
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
TOOLS = ROOT / 'build-tools'
COMPAT = TOOLS / 'compat-native'
SOURCE = COMPAT / 'vortek-source/brunodev85-vortek-b1730c5'
OUT = ROOT / 'testovanie/issue-123/timeline-guest-build'
INPUT = ROOT / 'apk-source/app/src/main/assets/graphics_driver/vortek-2.1-enorial3.tzst'
sys.path.insert(0, str(COMPAT / 'python'))
import zstandard


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sources():
    result = {}
    for folder in ('src', 'include'):
        for path in sorted((SOURCE / folder).rglob('*')):
            if path.is_file():
                result[path.relative_to(SOURCE).as_posix()] = digest(path.read_bytes())
    result['CMakeLists.txt'] = digest((SOURCE / 'CMakeLists.txt').read_bytes())
    return result


def members(path):
    result = []
    with path.open('rb') as raw, zstandard.ZstdDecompressor().stream_reader(raw) as decoded, \
            tarfile.open(fileobj=decoded, mode='r|') as archive:
        for item in archive:
            body = archive.extractfile(item).read() if item.isfile() else None
            result.append((item, body))
    return result


def identity(item, body):
    return {'name': item.name, 'type': item.type.decode('ascii'), 'mode': item.mode,
            'uid': item.uid, 'gid': item.gid, 'uname': item.uname, 'gname': item.gname,
            'mtime': item.mtime, 'linkname': item.linkname, 'size': item.size,
            'pax_headers': item.pax_headers,
            'sha256': digest(body) if body is not None else None}


def main():
    global OUT, INPUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--revision', type=int, choices=(4, 5, 6), required=True,
                        help='Explicit guest revision; do not overwrite a previous wire contract')
    args = parser.parse_args()
    revision = args.revision
    if revision == 5:
        OUT = ROOT / 'testovanie/issue-123/fence-guest-build'
    if revision == 6:
        OUT = ROOT / 'testovanie/154/vortek-present/guest-build'
    INPUT = ROOT / ('apk-source/app/src/main/assets/graphics_driver/vortek-2.1-enorial' + str(revision-1) + '.tzst')
    OUT.mkdir(parents=True, exist_ok=True)
    temp = OUT / 'tmp'
    temp.mkdir(exist_ok=True)
    env = os.environ.copy()
    env['TEMP'] = env['TMP'] = str(temp)
    before = sources()
    input_hash = digest(INPUT.read_bytes())
    guest = (SOURCE / 'src/vulkan_calls.c').read_text(encoding='utf-8')
    start = guest.index('VkResult vt_call_vkWaitSemaphores(')
    end = guest.index('VkResult vt_call_vkSignalSemaphore(', start)
    if 'VK_TIMEOUT' not in guest[start:end]:
        raise RuntimeError('Paired guest timeout fix is not present; do not build old protocol')
    native_fence = 'REQUEST_CODE_VK_WAIT_FOR_FENCES_NATIVE' in guest
    if native_fence != (revision >= 5):
        raise RuntimeError('Requested archive revision does not match the guest fence wire contract')
    if ('REQUEST_CODE_VK_QUEUE_PRESENT_KHR_NATIVE' in guest) != (revision >= 6):
        raise RuntimeError('Requested archive revision does not match the paired present wire contract')
    cmake = TOOLS / 'sdk/cmake/3.22.1/bin/cmake.exe'
    ninja = TOOLS / 'sdk/cmake/3.22.1/bin/ninja.exe'
    llvm = TOOLS / 'sdk/ndk/24.0.8215888/toolchains/llvm/prebuilt/windows-x86_64/bin'
    build = OUT / 'cmake'
    commands = [[str(cmake), '-S', str(SOURCE), '-B', str(build), '-G', 'Ninja',
                 '-DCMAKE_TOOLCHAIN_FILE=' + str(COMPAT / 'linux-arm64.cmake'),
                 '-DCMAKE_MAKE_PROGRAM=' + str(ninja), '-DCMAKE_BUILD_TYPE=Release',
                 '-DCMAKE_INSTALL_PREFIX=' + str(OUT / 'unused-install')],
                [str(cmake), '--build', str(build), '--parallel', '2']]
    with (OUT / 'build.log').open('w', encoding='utf-8') as log:
        for command in commands:
            subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    library = OUT / 'libvulkan_vortek.so'
    library.write_bytes((build / library.name).read_bytes())
    subprocess.run([str(llvm / 'llvm-strip.exe'), '--strip-unneeded', str(library)],
                   cwd=ROOT, env=env, check=True)
    body = library.read_bytes()
    if body[:6] != b'\x7fELF\x02\x01' or struct.unpack_from('<H', body, 18)[0] != 183:
        raise RuntimeError('Expected little-endian ELF64 ARM64 guest')
    phoff = struct.unpack_from('<Q', body, 32)[0]
    phsize, phnum = struct.unpack_from('<HH', body, 54)
    alignments = []
    for number in range(phnum):
        pos = phoff + number * phsize
        if struct.unpack_from('<I', body, pos)[0] == 1:
            alignments.append(struct.unpack_from('<Q', body, pos + 48)[0])
    if not alignments or min(alignments) < 16384:
        raise RuntimeError('Guest load segments must retain Android 16 KiB compatibility')
    with (OUT / 'elf-details.txt').open('w', encoding='utf-8') as output:
        subprocess.run([str(llvm / 'llvm-readelf.exe'), '-h', '-l', '-d', '-V', str(library)],
                       cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, check=True)
    original = members(INPUT)
    replacements = [i for i, (item, _) in enumerate(original)
                    if item.isfile() and item.name.endswith('/libvulkan_vortek.so')]
    if len(replacements) != 1:
        raise RuntimeError('Expected exactly one guest library in existing archive')
    replaced = replacements[0]
    archive_path = OUT / ('vortek-2.1-enorial' + str(revision) + '.tzst')
    with archive_path.open('wb') as raw, zstandard.ZstdCompressor(level=19).stream_writer(raw) as encoded, \
            tarfile.open(fileobj=encoded, mode='w|', format=tarfile.GNU_FORMAT) as archive:
        for number, (old_item, old_body) in enumerate(original):
            item = copy.copy(old_item)
            data = body if number == replaced else old_body
            if number == replaced:
                item.size = len(data)
            archive.addfile(item, io.BytesIO(data) if data is not None else None)
    staged = members(archive_path)
    if len(staged) != len(original):
        raise RuntimeError('Archive member count changed')
    for number, ((old_item, old_body), (item, data)) in enumerate(zip(original, staged)):
        old = identity(old_item, old_body)
        new = identity(item, data)
        if number == replaced:
            old['size'] = new['size']
            old['sha256'] = digest(body)
        if old != new:
            raise RuntimeError('Unexpected archive change: ' + item.name)
    if sources() != before or digest(INPUT.read_bytes()) != input_hash:
        raise RuntimeError('Build inputs changed during isolated build')
    manifest = {'pinnedSource': 'brunodev85/vortek@b1730c5', 'sources': before,
                'sourceArchive': INPUT.relative_to(ROOT).as_posix(), 'sourceArchiveSha256': input_hash,
                'librarySha256': digest(body), 'archiveSha256': digest(archive_path.read_bytes()),
                'archive': archive_path.name, 'archiveMembers': len(original),
                'replacedMember': original[replaced][0].name,
                'unchangedOtherMembers': True, 'loadSegmentAlignments': alignments,
                'sourceInputsUnchanged': True, 'generatedInputsChanged': False,
                'integrationRequired': ['DefaultVersion.VORTEK = 2.1-enorial' + str(revision),
                                        'Copy staged archive to canonical graphics_driver assets',
                                        'Exclude revision ' + str(revision-1) + ' from runtime packaging',
                                        'Prepare public sources only after active build completes']}
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    print('Staged classic Vortek guest:', archive_path)
    print('Archive SHA256:', manifest['archiveSha256'])
    print('No APK, canonical assets, generated package, or Forever runtime modified.')


if __name__ == '__main__':
    main()
