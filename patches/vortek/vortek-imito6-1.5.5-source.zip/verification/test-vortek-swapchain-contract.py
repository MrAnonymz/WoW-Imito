"""Exercise actual host wire decoding and AHB descriptor checks for issue 183."""
from pathlib import Path
import argparse, hashlib, json, os, re, shutil, subprocess

ROOT = Path(__file__).resolve().parents[1]
CPP = ROOT / 'host/vortekrenderer'

def function(text, name):
    m = re.search(r'^(?:static\s+)?(?:inline\s+)?[\w* \t]+\b' + name + r'\(', text, re.M)
    if not m: raise ValueError(name)
    end = text.index('{', m.start()) + 1
    depth = 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[m.start():end] + '\n'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', action='store_true')
    args = parser.parse_args()
    out = ROOT / 'verification/results' / ('contract-baseline' if args.baseline else 'contract-fixed')
    out.mkdir(parents=True, exist_ok=True)
    source = (CPP / 'include/vortek_serializer.h').read_text()
    if args.baseline:
        source = re.sub(r'vt_nativeImageLayout\((\*\(VkImageLayout\*\)\(inputBuffer \+ bufferOffset\))\)', r'\1', source)
    names = ['VkImageMemoryBarrier', 'VkImageMemoryBarrier2', 'VkAttachmentDescription',
             'VkAttachmentDescription2', 'VkAttachmentReference', 'VkAttachmentReference2',
             'VkDescriptorImageInfo', 'VkRenderingAttachmentInfo']
    extracted, pending = {}, ['vt_'+prefix+'_'+n for n in names for prefix in ['serialize', 'unserialize']]
    def add(name):
        if name in extracted: return
        body = function(source, name)
        extracted[name] = None
        for child in re.findall(r'\b(vt_(?:sizeof|serialize|unserialize)_\w+)\(', body):
            if child != name: add(child)
        extracted[name] = body
    for name in pending: add(name)
    code = r'''
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "vulkan/vulkan_core.h"
#include "swapchain_layout.h"
#define VT_SERVER 1
typedef struct { int unused; } MemoryPool;
static bool vortekSerializerCastVkObject;
#define VkObject_fromId(id) ((void*)(uintptr_t)(id))
static void* vt_alloc(MemoryPool* pool, size_t size) { return calloc(1, size); }
static void* findNextVkStructure(const void* p, VkStructureType type) { return NULL; }
static void* invertVkStructuresChain(void* p) { return p; }
'''
    code += '\n'.join(body[:body.index('{')].rstrip() + ';' for body in extracted.values()) + '\n'
    code += '\n'.join(extracted.values())
    code += r'''
static int checks, failures;
#define CHECK(expr) do { checks++; if (!(expr)) { failures++; fprintf(stderr,"FAIL %d: %s\n", __LINE__, #expr); } } while(0)
int main(void) {
 union { uint64_t aligned; char bytes[4096]; } wire = {0}; MemoryPool pool={0};
 VkImageLayout layouts[] = {VK_IMAGE_LAYOUT_PRESENT_SRC_KHR, VK_IMAGE_LAYOUT_GENERAL,
  VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
  VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
  VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL};
 for (unsigned i=0;i<sizeof(layouts)/sizeof(*layouts);i++) {
  VkImageLayout expected = i==0 ? VK_IMAGE_LAYOUT_GENERAL : layouts[i];
  VkImageMemoryBarrier a={.sType=VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
   .oldLayout=layouts[i],.newLayout=layouts[i],.srcAccessMask=VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,
   .dstAccessMask=VK_ACCESS_MEMORY_READ_BIT,.srcQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED,
   .dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED,.image=(VkImage)(uintptr_t)0x123456};
  VkImageMemoryBarrier b={0}; vt_serialize_VkImageMemoryBarrier(&a,wire.bytes);
  vt_unserialize_VkImageMemoryBarrier(&b,wire.bytes,&pool);
  CHECK(b.oldLayout==expected && b.newLayout==expected);
  CHECK(b.image==a.image && b.srcAccessMask==a.srcAccessMask && b.dstAccessMask==a.dstAccessMask);
  CHECK(b.srcQueueFamilyIndex==a.srcQueueFamilyIndex && b.dstQueueFamilyIndex==a.dstQueueFamilyIndex);
  VkImageMemoryBarrier2 a2={.sType=VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2,
   .oldLayout=layouts[i],.newLayout=layouts[i],.image=a.image,
   .srcStageMask=VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,.dstStageMask=VK_PIPELINE_STAGE_2_ALL_GRAPHICS_BIT};
  VkImageMemoryBarrier2 b2={0}; vt_serialize_VkImageMemoryBarrier2(&a2,wire.bytes);
  vt_unserialize_VkImageMemoryBarrier2(&b2,wire.bytes,&pool);
  CHECK(b2.oldLayout==expected && b2.newLayout==expected && b2.image==a2.image);
  CHECK(b2.srcStageMask==a2.srcStageMask && b2.dstStageMask==a2.dstStageMask);
  VkAttachmentDescription d={.format=VK_FORMAT_R8G8B8A8_UNORM,.initialLayout=layouts[i],.finalLayout=layouts[i]}, e={0};
  vt_serialize_VkAttachmentDescription(&d,wire.bytes);vt_unserialize_VkAttachmentDescription(&e,wire.bytes,&pool);
  CHECK(e.initialLayout==expected && e.finalLayout==expected && e.format==d.format);
  VkAttachmentDescription2 d2={.sType=VK_STRUCTURE_TYPE_ATTACHMENT_DESCRIPTION_2,.format=d.format,
   .initialLayout=layouts[i],.finalLayout=layouts[i]}, e2={0};
  vt_serialize_VkAttachmentDescription2(&d2,wire.bytes);vt_unserialize_VkAttachmentDescription2(&e2,wire.bytes,&pool);
  CHECK(e2.initialLayout==expected && e2.finalLayout==expected && e2.format==d2.format);
  VkAttachmentReference r={.attachment=7,.layout=layouts[i]}, s={0};
  vt_serialize_VkAttachmentReference(&r,wire.bytes);vt_unserialize_VkAttachmentReference(&s,wire.bytes,&pool);
  CHECK(s.layout==expected && s.attachment==7);
  VkAttachmentReference2 r2={.sType=VK_STRUCTURE_TYPE_ATTACHMENT_REFERENCE_2,.attachment=7,.layout=layouts[i]},s2={0};
  vt_serialize_VkAttachmentReference2(&r2,wire.bytes);vt_unserialize_VkAttachmentReference2(&s2,wire.bytes,&pool);
  CHECK(s2.layout==expected && s2.attachment==7);
  VkDescriptorImageInfo di={.imageLayout=layouts[i]},de={0};
  vt_serialize_VkDescriptorImageInfo(&di,wire.bytes);vt_unserialize_VkDescriptorImageInfo(&de,wire.bytes,&pool);
  CHECK(de.imageLayout==expected);
  VkRenderingAttachmentInfo ri={.sType=VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO,
   .imageLayout=layouts[i],.resolveImageLayout=layouts[i]},ro={0};
  vt_serialize_VkRenderingAttachmentInfo(&ri,wire.bytes);vt_unserialize_VkRenderingAttachmentInfo(&ro,wire.bytes,&pool);
  CHECK(ro.imageLayout==expected && ro.resolveImageLayout==expected);
 }
 printf("%s %d actual wire-layout checks; %d failures\n",failures ? "FAIL" : "PASS",checks,failures);
 return failures ? 1 : 0;
}
'''
    c = out/'contract.c'; c.write_text(code)
    compiler = os.environ.get('CC') or next((shutil.which(n) for n in ('cc','clang','gcc','zig') if shutil.which(n)), None)
    if not compiler: raise RuntimeError('Set CC or install a C compiler')
    compiler_command = [compiler] + (['cc'] if Path(compiler).stem.lower() == 'zig' else [])
    env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(out/'zig-global'),ZIG_LOCAL_CACHE_DIR=str(out/'zig-local'))
    cmd=compiler_command+['-std=c11','-O1','-Wno-incompatible-pointer-types','-I'+str(CPP/'include'),str(c),'-o',str(out/'contract.exe')]
    build=subprocess.run(cmd,capture_output=True,env=env,timeout=120)
    (out/'build.log').write_bytes(build.stdout+build.stderr)
    if build.returncode:
        print(build.stderr.decode(errors='replace'));return build.returncode
    run=subprocess.run([str(out/'contract.exe')],capture_output=True,timeout=30)
    (out/'run.log').write_bytes(run.stdout+run.stderr)
    report={'status':'PASS' if run.returncode==0 else 'FAIL','baseline':args.baseline,
      'scope':'Production wire decoder functions; no remote Mali execution',
      'sources':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
       [Path(__file__),CPP/'include/vortek_serializer.h',CPP/'include/swapchain_layout.h']}}
    (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    print((run.stdout+run.stderr).decode(errors='replace'));return run.returncode

if __name__=='__main__':raise SystemExit(main())
