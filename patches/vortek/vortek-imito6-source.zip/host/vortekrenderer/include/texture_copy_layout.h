#ifndef ENORIAL_TEXTURE_COPY_LAYOUT_H
#define ENORIAL_TEXTURE_COPY_LAYOUT_H

#include <stdint.h>
#include <stdbool.h>
#include "vulkan/vulkan_core.h"

/* Byte layout of the decoded image. Vulkan copy coordinates stay in texels;
 * source row/image strides use compressed 4x4 blocks, not RGBA bytes. */
typedef struct TextureCopyImageLayout {
    uint32_t width, height, depth, mipLevels, arrayLayers;
    VkDeviceSize mipOffsets[32], layerSize, size;
} TextureCopyImageLayout;

typedef struct TextureCopyLayout {
    VkDeviceSize sourceOffset, sourceRowPitch, sourceSlicePitch, sourceLayerPitch;
    VkDeviceSize targetOffset, targetRowPitch, targetSlicePitch, targetLayerPitch;
} TextureCopyLayout;

static inline uint32_t TextureCopy_mipSize(uint32_t size, uint32_t mip) {
    uint32_t result = size >> mip;
    return result ? result : 1;
}

static inline bool TextureCopy_imageLayout(TextureCopyImageLayout* out,
        uint32_t width, uint32_t height, uint32_t depth, uint32_t levels, uint32_t layers) {
    if (!width || !height || !depth || !levels || !layers || levels > 32 ||
            width > 16384 || height > 16384 || depth > 16384 || layers > 2048) return false;
    uint32_t maxSize = width > height ? width : height;
    if (depth > maxSize) maxSize = depth;
    uint32_t maxLevels = 1;
    while (maxSize >>= 1) maxLevels++;
    if (levels > maxLevels || (depth > 1 && layers > 1)) return false;
    *out = (TextureCopyImageLayout){.width=width, .height=height, .depth=depth,
                                  .mipLevels=levels, .arrayLayers=layers};
    for (uint32_t mip = 0; mip < levels; mip++) {
        out->mipOffsets[mip] = out->layerSize;
        out->layerSize += (VkDeviceSize)TextureCopy_mipSize(width, mip) *
                TextureCopy_mipSize(height, mip) * TextureCopy_mipSize(depth, mip) * 4;
    }
    out->size = out->layerSize * layers;
    return out->size <= SIZE_MAX;
}

static inline bool TextureCopy_regionLayout(const TextureCopyImageLayout* image,
        const VkBufferImageCopy* region, uint32_t blockBytes, VkDeviceSize available,
        TextureCopyLayout* out) {
    uint32_t mip = region->imageSubresource.mipLevel;
    uint32_t layer = region->imageSubresource.baseArrayLayer;
    uint32_t layers = region->imageSubresource.layerCount;
    uint32_t w = region->imageExtent.width, h = region->imageExtent.height;
    uint32_t d = region->imageExtent.depth;
    if ((blockBytes != 8 && blockBytes != 16) || mip >= image->mipLevels ||
            !layers || layer >= image->arrayLayers || layers > image->arrayLayers - layer ||
            !w || !h || !d || region->imageOffset.x < 0 || region->imageOffset.y < 0 ||
            region->imageOffset.z < 0 || region->imageSubresource.aspectMask != VK_IMAGE_ASPECT_COLOR_BIT)
        return false;
    uint32_t mw = TextureCopy_mipSize(image->width, mip);
    uint32_t mh = TextureCopy_mipSize(image->height, mip);
    uint32_t md = TextureCopy_mipSize(image->depth, mip);
    uint32_t x = region->imageOffset.x, y = region->imageOffset.y, z = region->imageOffset.z;
    if (x >= mw || y >= mh || z >= md || w > mw - x || h > mh - y || d > md - z ||
            x % 4 || y % 4 || (w % 4 && x + w != mw) || (h % 4 && y + h != mh)) return false;
    uint32_t row = region->bufferRowLength ? region->bufferRowLength : w;
    uint32_t rows = region->bufferImageHeight ? region->bufferImageHeight : h;
    if (row < w || rows < h || (region->bufferRowLength && row % 4) ||
            (region->bufferImageHeight && rows % 4)) return false;
    /* Strides larger than any supported image are rejected before arithmetic. */
    if (row > 16384 || rows > 16384) return false;
    out->sourceOffset = region->bufferOffset;
    out->sourceRowPitch = ((VkDeviceSize)row + 3) / 4 * blockBytes;
    out->sourceSlicePitch = out->sourceRowPitch * (((VkDeviceSize)rows + 3) / 4);
    out->sourceLayerPitch = out->sourceSlicePitch * d;
    VkDeviceSize span = (layers - 1) * out->sourceLayerPitch + (d - 1) * out->sourceSlicePitch +
            ((h - 1) / 4) * out->sourceRowPitch + ((VkDeviceSize)w + 3) / 4 * blockBytes;
    if (out->sourceOffset > available || span > available - out->sourceOffset) return false;
    out->targetRowPitch = (VkDeviceSize)mw * 4;
    out->targetSlicePitch = out->targetRowPitch * mh;
    out->targetLayerPitch = image->layerSize;
    out->targetOffset = layer * image->layerSize + image->mipOffsets[mip] +
            z * out->targetSlicePitch + y * out->targetRowPitch + x * 4;
    return true;
}
#endif
