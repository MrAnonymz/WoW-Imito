#ifndef VORTEK_PRESENTATION_REGISTRY_H
#define VORTEK_PRESENTATION_REGISTRY_H
/* Per virtual context, accessed only by its request thread. No global GPU guess. */
typedef struct PresentationDevice {
    VkDevice device;VkPhysicalDevice physical;uint32_t graphicsFamily;
    bool syncFdFenceExport;
    struct PresentationDevice* next;
} PresentationDevice;
typedef struct PresentationQueue {
    VkQueue queue;VkDevice device;uint32_t family;VkDeviceQueueCreateFlags flags;
    struct PresentationQueue* next;
} PresentationQueue;
static PresentationDevice* presentationDevice(PresentationDevice* list,VkDevice device) {
    for(;list;list=list->next)if(list->device==device)return list;return NULL;
}
static bool rememberPresentationDevice(PresentationDevice** list,VkDevice device,VkPhysicalDevice physical,uint32_t family) {
    PresentationDevice* entry=calloc(1,sizeof(*entry));if(!entry)return false;
    entry->device=device;entry->physical=physical;entry->graphicsFamily=family;entry->next=*list;*list=entry;return true;
}
static bool rememberPresentationQueue(PresentationQueue** list,VkQueue queue,VkDevice device,uint32_t family,VkDeviceQueueCreateFlags flags) {
    if(!queue)return false;
    for(PresentationQueue* q=*list;q;q=q->next)if(q->queue==queue)return q->device==device && q->family==family && q->flags==flags;
    PresentationQueue* entry=calloc(1,sizeof(*entry));if(!entry)return false;
    entry->queue=queue;entry->device=device;entry->family=family;entry->flags=flags;entry->next=*list;*list=entry;return true;
}
static void forgetPresentationDevice(PresentationDevice** devices,PresentationQueue** queues,VkDevice device) {
    for(PresentationDevice** p=devices;*p;) {
        PresentationDevice* entry=*p;
        if(!device || entry->device==device){*p=entry->next;free(entry);}else p=&entry->next;
    }
    for(PresentationQueue** p=queues;*p;) {
        PresentationQueue* entry=*p;
        if(!device || entry->device==device){*p=entry->next;free(entry);}else p=&entry->next;
    }
}
#endif
