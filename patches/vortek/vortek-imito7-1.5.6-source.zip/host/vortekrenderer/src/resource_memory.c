#include "resource_memory.h"
#include "sysvshared_memory.h"
#include "vulkan_helper.h"
#include "texture_decoder.h"
#include "dma_utils.h"

extern int AHardwareBuffer_getFd(AHardwareBuffer* hardwareBuffer);
extern DeviceMemoryInfo deviceMemoryInfo;

static ResourceMemory* internalAllocate() {
    ResourceMemory* resourceMemory = calloc(1, sizeof(ResourceMemory));
    if (!resourceMemory) return NULL;
    resourceMemory->buffer = VK_NULL_HANDLE;
    resourceMemory->memory = VK_NULL_HANDLE;
    resourceMemory->fd = -1;
    return resourceMemory;
}

static AHardwareBuffer* allocateHardwareBuffer(VkDeviceSize size) {
    if (size == 0 || size > UINT32_MAX) return NULL;
    AHardwareBuffer_Desc buffDesc = {0};
    buffDesc.width = size;
    buffDesc.height = 1;
    buffDesc.layers = 1;
    buffDesc.usage = AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN | AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN |
            AHARDWAREBUFFER_USAGE_GPU_DATA_BUFFER;
    buffDesc.format = AHARDWAREBUFFER_FORMAT_BLOB;

    AHardwareBuffer* hardwareBuffer = NULL;
    AHardwareBuffer_allocate(&buffDesc, &hardwareBuffer);

    return hardwareBuffer;
}

static bool allocationFits(VkContext* context, uint64_t limit, VkDeviceSize size) {
    return size && context->totalAllocationSize < limit &&
            size <= limit - context->totalAllocationSize;
}

static uint32_t compatibleExternalMemoryType(uint32_t preferred, uint32_t bits) {
    // CPU access uses the shared descriptor, not vkMapMemory. External buffers
    // can therefore expose DEVICE_LOCAL types without HOST_VISIBLE. Preserve
    // a compatible requested type, but never choose protected or lazy memory
    // for this ordinary CPU-shared buffer path.
    uint32_t allowed = 0;
    for (uint32_t i = 0; i < deviceMemoryInfo.memoryTypeCount && i < 32; i++) {
        VkMemoryPropertyFlags flags = getMemoryPropertyFlags(i);
        if ((bits & (1u << i)) && !(flags & (VK_MEMORY_PROPERTY_PROTECTED_BIT |
                VK_MEMORY_PROPERTY_LAZILY_ALLOCATED_BIT))) allowed |= 1u << i;
    }
    if (preferred < 32 && (allowed & (1u << preferred))) return preferred;
    uint32_t host = getMemoryTypeIndex(allowed,
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    return host != UINT32_MAX ? host : getMemoryTypeIndex(allowed, 0);
}

ResourceMemory* ResourceMemory_allocate(VkContext* context, VkDevice device, VkMemoryAllocateInfo* memoryInfo) {
    uint64_t maxAllocationSize = (VkDeviceSize)context->maxDeviceMemory << 20;
    if (maxAllocationSize == 0) maxAllocationSize = deviceMemoryInfo.maxAllocationSize;
    if (!allocationFits(context, maxAllocationSize, memoryInfo->allocationSize) ||
            memoryInfo->memoryTypeIndex >= deviceMemoryInfo.memoryTypeCount) return NULL;

    VkResult result;
    const void* originalNext = memoryInfo->pNext;
    ResourceMemory* resourceMemory = internalAllocate();
    if (!resourceMemory) return NULL;
    if (isHostVisibleMemory(memoryInfo->memoryTypeIndex)) {
        bool hasExternalMemoryFd = context->hasExternalMemoryFd;
        bool hasExternalMemoryDMABuf = context->hasExternalMemoryDMABuf;

        // A measured DMA-only presentation path should keep CPU-written
        // resources on imported DMA memory too. PanVK's opaque export uses
        // cached driver allocations on non-coherent JM GPUs; cleaning all of
        // them at every queue submit consumed milliseconds on the A15. The
        // DMA allocator prefers an uncached heap and retains driver sync.
        // Require the independent buffer-import capability, and leave explicit
        // selections and ordinary AHB-capable devices unchanged.
        if (context->resourceMemoryType == RESOURCE_MEMORY_TYPE_AUTO &&
                context->linearDmaPresentation && hasExternalMemoryDMABuf)
            hasExternalMemoryFd = false;

        switch (context->resourceMemoryType) {
            case RESOURCE_MEMORY_TYPE_OPAQUE_FD:
                hasExternalMemoryFd = true;
                hasExternalMemoryDMABuf = false;
                break;
            case RESOURCE_MEMORY_TYPE_DMA_BUF:
                hasExternalMemoryFd = false;
                hasExternalMemoryDMABuf = true;
                break;
            case RESOURCE_MEMORY_TYPE_AHARDWAREBUFFER:
                hasExternalMemoryFd = false;
                hasExternalMemoryDMABuf = false;
                break;
            default:
                break;
        }

        if (hasExternalMemoryFd) {
            VkExternalMemoryBufferCreateInfo externalMemoryBufferInfo = {0};
            externalMemoryBufferInfo.sType = VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_BUFFER_CREATE_INFO;
            externalMemoryBufferInfo.handleTypes = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT;

            VkBufferCreateInfo bufferInfo = {0};
            bufferInfo.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
            bufferInfo.pNext = &externalMemoryBufferInfo;
            bufferInfo.size = memoryInfo->allocationSize;
            bufferInfo.usage = getSharedBufferUsage();
            bufferInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;

            result = vulkanWrapper.vkCreateBuffer(device, &bufferInfo, NULL, &resourceMemory->buffer);
            if (result != VK_SUCCESS) goto error;

            VkMemoryRequirements memReqs = {0};
            vulkanWrapper.vkGetBufferMemoryRequirements(device, resourceMemory->buffer, &memReqs);
            if (memReqs.size < memoryInfo->allocationSize ||
                    !allocationFits(context, maxAllocationSize, memReqs.size)) goto error;
            memoryInfo->memoryTypeIndex = compatibleExternalMemoryType(memoryInfo->memoryTypeIndex, memReqs.memoryTypeBits);
            if (memoryInfo->memoryTypeIndex == UINT32_MAX) goto error;

            VkExportMemoryAllocateInfo exportMemoryInfo = {0};
            exportMemoryInfo.sType = VK_STRUCTURE_TYPE_EXPORT_MEMORY_ALLOCATE_INFO;
            exportMemoryInfo.handleTypes = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT;

            VkMemoryDedicatedAllocateInfo memoryDedicatedInfo = {0};
            memoryDedicatedInfo.sType = VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO;
            memoryDedicatedInfo.pNext = &exportMemoryInfo;
            memoryDedicatedInfo.image = VK_NULL_HANDLE;
            memoryDedicatedInfo.buffer = resourceMemory->buffer;

            memoryInfo->pNext = &memoryDedicatedInfo;
            memoryInfo->allocationSize = memReqs.size;
            result = vulkanWrapper.vkAllocateMemory(device, memoryInfo, NULL, &resourceMemory->memory);
            if (result != VK_SUCCESS) goto error;

            VkMemoryGetFdInfoKHR getFdInfo = {0};
            getFdInfo.sType = VK_STRUCTURE_TYPE_MEMORY_GET_FD_INFO_KHR;
            getFdInfo.memory = resourceMemory->memory;
            getFdInfo.handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT;

            int fd = -1;
            result = vulkanWrapper.vkGetMemoryFd(device, &getFdInfo, &fd);
            if (result != VK_SUCCESS || fd < 0) goto error;
            resourceMemory->fd = fd;
        }
        else {
            if ((getMemoryPropertyFlags(memoryInfo->memoryTypeIndex) & VK_MEMORY_PROPERTY_HOST_CACHED_BIT)) {
                memoryInfo->memoryTypeIndex = getMemoryTypeIndex(UINT32_MAX, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
                if (memoryInfo->memoryTypeIndex == UINT32_MAX) goto error;
            }

            bool useExternalMemoryAHB = !hasExternalMemoryDMABuf;
            if (hasExternalMemoryDMABuf) {
                useExternalMemoryAHB = true;
                int fd = dmabuf_alloc(memoryInfo->allocationSize);
                if (fd >= 0) {
                    PFN_vkGetMemoryFdPropertiesKHR getProperties = vulkanWrapper.vkGetDeviceProcAddr ?
                            (PFN_vkGetMemoryFdPropertiesKHR)vulkanWrapper.vkGetDeviceProcAddr(device, "vkGetMemoryFdPropertiesKHR") : NULL;
                    VkMemoryFdPropertiesKHR properties = {0};
                    properties.sType = VK_STRUCTURE_TYPE_MEMORY_FD_PROPERTIES_KHR;
                    uint32_t type = UINT32_MAX;
                    if (getProperties && getProperties(device, VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT,
                            fd, &properties) == VK_SUCCESS)
                        type = compatibleExternalMemoryType(memoryInfo->memoryTypeIndex, properties.memoryTypeBits);
                    int dupFd = type != UINT32_MAX ? dup(fd) : -1;
                    if (dupFd >= 0) {
                        VkImportMemoryFdInfoKHR memoryImportInfo = {0};
                        memoryImportInfo.sType = VK_STRUCTURE_TYPE_IMPORT_MEMORY_FD_INFO_KHR;
                        memoryImportInfo.fd = dupFd;
                        memoryImportInfo.handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT;
                        memoryInfo->memoryTypeIndex = type;
                        memoryInfo->pNext = &memoryImportInfo;
                        result = vulkanWrapper.vkAllocateMemory(device, memoryInfo, NULL, &resourceMemory->memory);
                        if (result == VK_SUCCESS) {
                            // Vulkan owns dupFd only after a successful import.
                            resourceMemory->fd = fd;
                            useExternalMemoryAHB = false;
                        } else close(dupFd);
                    }
                    if (useExternalMemoryAHB) close(fd);
                }
            }

            if (useExternalMemoryAHB) {
                if (!vulkanWrapper.vkGetAndroidHardwareBufferPropertiesANDROID) goto error;
                AHardwareBuffer* hardwareBuffer = allocateHardwareBuffer(memoryInfo->allocationSize);
                if (!hardwareBuffer) goto error;
                resourceMemory->hardwareBuffer = hardwareBuffer;


                int fd = AHardwareBuffer_getFd(hardwareBuffer);
                if (fd < 0) goto error;

                VkAndroidHardwareBufferPropertiesANDROID properties = {0};
                properties.sType = VK_STRUCTURE_TYPE_ANDROID_HARDWARE_BUFFER_PROPERTIES_ANDROID;
                result = vulkanWrapper.vkGetAndroidHardwareBufferPropertiesANDROID(device, hardwareBuffer, &properties);
                if (result != VK_SUCCESS || properties.allocationSize < memoryInfo->allocationSize ||
                        !allocationFits(context, maxAllocationSize, properties.allocationSize)) goto error;
                memoryInfo->memoryTypeIndex = compatibleExternalMemoryType(memoryInfo->memoryTypeIndex, properties.memoryTypeBits);
                if (memoryInfo->memoryTypeIndex == UINT32_MAX) goto error;
                memoryInfo->allocationSize = properties.allocationSize;

                VkImportAndroidHardwareBufferInfoANDROID memoryImportInfo = {0};
                memoryImportInfo.sType = VK_STRUCTURE_TYPE_IMPORT_ANDROID_HARDWARE_BUFFER_INFO_ANDROID;
                memoryImportInfo.buffer = hardwareBuffer;

                memoryInfo->pNext = &memoryImportInfo;
                result = vulkanWrapper.vkAllocateMemory(device, memoryInfo, NULL, &resourceMemory->memory);
                if (result != VK_SUCCESS) goto error;
                resourceMemory->fd = fd;
            }
        }
    }
    else {
        result = vulkanWrapper.vkAllocateMemory(device, memoryInfo, NULL, &resourceMemory->memory);
        if (result != VK_SUCCESS) goto error;
    }

    if (result == VK_SUCCESS) context->totalAllocationSize += memoryInfo->allocationSize;
    resourceMemory->allocationSize = memoryInfo->allocationSize;
    memoryInfo->pNext = originalNext;
    return resourceMemory;

error:
    memoryInfo->pNext = originalNext;
    ResourceMemory_free(context, device, resourceMemory);
    return NULL;
}

void ResourceMemory_free(VkContext* context, VkDevice device, ResourceMemory* resourceMemory) {
    if (!resourceMemory) return;
    if (context->textureDecoder)
        TextureDecoder_removeBoundMemory(context->textureDecoder, resourceMemory);

    if (resourceMemory->buffer) {
        vulkanWrapper.vkDestroyBuffer(device, resourceMemory->buffer, NULL);
        resourceMemory->buffer = VK_NULL_HANDLE;
    }

    // AHardwareBuffer_getFd returns a borrowed native-handle descriptor. The
    // AHB releases it below; closing it here can close the same (or reused) fd
    // twice. Opaque-FD exports and DMA-BUF allocations are owned by us.
    if (!resourceMemory->hardwareBuffer && resourceMemory->fd >= 0) close(resourceMemory->fd);
    resourceMemory->fd = -1;
    if (resourceMemory->memory) {
        vulkanWrapper.vkFreeMemory(device, resourceMemory->memory, NULL);
        resourceMemory->memory = VK_NULL_HANDLE;

        uint64_t totalAllocationSize = context->totalAllocationSize;
        totalAllocationSize = totalAllocationSize > resourceMemory->allocationSize ? (totalAllocationSize - resourceMemory->allocationSize) : 0;
        context->totalAllocationSize = totalAllocationSize;
    }

    if (resourceMemory->hardwareBuffer) {
        AHardwareBuffer_release(resourceMemory->hardwareBuffer);
        resourceMemory->hardwareBuffer = NULL;
    }

    resourceMemory->allocationSize = 0;
    MEMFREE(resourceMemory);
}
