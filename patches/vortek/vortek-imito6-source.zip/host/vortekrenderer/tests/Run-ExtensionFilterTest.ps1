$ErrorActionPreference = 'Stop'
$project = 'E:\Code\MD\WoW-Enorial-Android'
$bin = Join-Path $project 'build-tools\sdk\ndk\24.0.8215888\toolchains\llvm\prebuilt\windows-x86_64\bin'
$kernel32 = 'C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0\um\x64\kernel32.lib'
$obj = Join-Path $PSScriptRoot 'extension_filter_test.obj'
$exe = Join-Path $PSScriptRoot 'extension_filter_test.exe'
& (Join-Path $bin 'clang.exe') --target=x86_64-pc-windows-msvc -ffreestanding -fno-builtin -fno-stack-protector -O1 -c `
    -I (Join-Path $PSScriptRoot '..\include') (Join-Path $PSScriptRoot 'extension_filter_test.c') -o $obj
if ($LASTEXITCODE -ne 0) { throw 'Extension filter test compile failed' }
& (Join-Path $bin 'ld.lld.exe') -flavor link /entry:mainCRTStartup /subsystem:console $obj $kernel32 "/out:$exe"
if ($LASTEXITCODE -ne 0) { throw 'Extension filter test link failed' }
& $exe
if ($LASTEXITCODE -ne 0) { throw "Extension filter: $LASTEXITCODE failing checks" }
'PASS: seven extension-filter checks; no emulator required.'
