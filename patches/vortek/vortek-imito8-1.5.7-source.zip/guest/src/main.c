#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>
#include <sys/mman.h>

#include "vortek.h"

int serverFd = -1;
uint16_t maxClientRequestId = 1;
MemoryPool globalMemoryPool = {0};
RingBuffer* serverRing = NULL;
RingBuffer* clientRing = NULL;

static int vortekServerConnect() {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) return -1;

    struct sockaddr_un server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sun_family = AF_LOCAL;

    strncpy(server_addr.sun_path, VORTEK_SERVER_PATH, sizeof(server_addr.sun_path) - 1);

    int res;
    do {
        res = 0;
        if (connect(fd, (struct sockaddr*)&server_addr, sizeof(struct sockaddr_un)) < 0) res = -errno;
    } 
    while (res == -EINTR);    

    if (res < 0) {
        close(fd);
        return -1;
    }

    return fd;
}

static bool createVkContext() {
    char header[HEADER_SIZE];
    *(int*)(header + 0) = REQUEST_CODE_CREATE_CONTEXT;
    *(int*)(header + 4) = 0;
    
    if (sock_write(serverFd, header, HEADER_SIZE) != HEADER_SIZE) return false;

    int shmFds[MAX_FDS], numFds = 0;
    int received = recv_fds(serverFd, shmFds, &numFds, NULL, 0);
    if (received == 1 && numFds == 2) {
        serverRing = RingBuffer_create(shmFds[0], SERVER_RING_BUFFER_SIZE);
        if (serverRing) clientRing = RingBuffer_create(shmFds[1], CLIENT_RING_BUFFER_SIZE);
    }
    for (int i = 0; i < numFds; i++) close(shmFds[i]);

    if (!serverRing || !clientRing) return false;
    globalMemoryPool.data = calloc(1, MEMORY_POOL_MAX_SIZE);
    if (!globalMemoryPool.data) return false;
    return true;
}

static void terminationCallback() {
    if (serverFd >= 0) close(serverFd);
    serverFd = -1;
    RingBuffer_free(serverRing);
    RingBuffer_free(clientRing);
    serverRing = NULL;
    clientRing = NULL;
    
    vt_free(&globalMemoryPool);
    MEMFREE(globalMemoryPool.data);
}

bool vortekInitOnce() {
    static pthread_mutex_t initMutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&initMutex);
    if (serverFd < 0) {
        serverFd = vortekServerConnect();
        if (serverFd >= 0) {
            if (createVkContext()) {
                atexit(terminationCallback);
            } else {
                terminationCallback();
            }
        }
    }
    bool ready = serverFd >= 0;
    pthread_mutex_unlock(&initMutex);
    return ready;
}
