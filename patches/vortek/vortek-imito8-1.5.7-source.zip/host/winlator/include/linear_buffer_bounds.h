#ifndef IMITO_LINEAR_BUFFER_BOUNDS_H
#define IMITO_LINEAR_BUFFER_BOUNDS_H
#include <stdbool.h>
#include <stdint.h>

/* Bound CPU verification and mapping by bytes, including actual row padding. */
static inline bool linearBufferSpanFits(uint64_t rowBytes,uint32_t height) {
    return rowBytes && height && rowBytes <= (64u * 1024u * 1024u) / height;
}
#endif
