"""Run production AHB import validation and Java buffer replacement lifecycle."""
from pathlib import Path
import importlib.util, json, os, shutil, subprocess

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('contract',Path(__file__).with_name('test-vortek-swapchain-contract.py'))
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
CPP=mod.CPP
OUT=ROOT/'verification/results/ahb-contract';OUT.mkdir(parents=True, exist_ok=True)
native=(CPP/'src/xwindow_swapchain.c').read_text()
code=r'''
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "vulkan/vulkan_core.h"
#include "vulkan/vulkan_android.h"
typedef bool jboolean;
typedef struct AHardwareBuffer {int dummy;} AHardwareBuffer;
typedef struct { uint32_t width,height,layers,format; } AHardwareBuffer_Desc;
#define AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM 1
enum { SWAPCHAIN_AHB=2,SWAPCHAIN_IMAGE=3,SWAPCHAIN_AHB_PROPERTIES=4 };
typedef struct {VkImage image; VkDeviceMemory memory;} XWindowSwapchain_Image;
typedef struct {int windowId;void* jmethods; VkFormat imageFormat;VkExtent2D imageExtent;VkImageUsageFlags imageUsage;} XWindowSwapchain;
static struct { PFN_vkCreateImage vkCreateImage;PFN_vkDestroyImage vkDestroyImage;} vulkanWrapper;
static AHardwareBuffer buffer;
static AHardwareBuffer_Desc desc;
static int creates,imports,destroys,lastStage;
static bool absent;
static VkResult createResult,importResult;
static VkImageCreateInfo observed;
static VkResult failedSwapchainStep(XWindowSwapchain* swap,int stage,VkResult result){lastStage=stage;return result;}
static AHardwareBuffer* getWindowHardwareBuffer(void* methods,int window,jboolean bgra){return absent?NULL:&buffer;}
static void AHardwareBuffer_describe(AHardwareBuffer* buffer,AHardwareBuffer_Desc* d){*d=desc;}
static VkResult VKAPI_CALL create(VkDevice device,const VkImageCreateInfo* info,const VkAllocationCallbacks* a,VkImage* image){
 creates++;observed=*info;*image=(VkImage)(uintptr_t)0x555;return createResult;
}
static void VKAPI_CALL destroy(VkDevice d,VkImage i,const VkAllocationCallbacks*a){destroys++;}
static VkResult createImageMemory(VkDevice d,XWindowSwapchain*s,VkImage i,AHardwareBuffer*b,VkDeviceMemory*m){
 imports++;*m=(VkDeviceMemory)(uintptr_t)0x666;return importResult;
}
'''
code+=mod.function(native,'createImage')
code+=r'''
static int checks, failures;
#define CHECK(x) do{checks++;if(!(x)){failures++;fprintf(stderr,"FAIL %d %s\n",__LINE__,#x);}}while(0)
int main(void){
 vulkanWrapper.vkCreateImage=create;vulkanWrapper.vkDestroyImage=destroy;
 VkFormat formats[]={VK_FORMAT_B8G8R8A8_UNORM,VK_FORMAT_B8G8R8A8_SRGB,VK_FORMAT_R8G8B8A8_UNORM,VK_FORMAT_R8G8B8A8_SRGB};
 for(int i=0;i<4;i++){
  XWindowSwapchain s={.windowId=5,.imageFormat=formats[i],.imageExtent={1600,900},.imageUsage=VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT};
  desc=(AHardwareBuffer_Desc){.width=1600,.height=900,.layers=1,.format=i<2?5:1};
  for(int broken=0;broken<5;broken++){
   AHardwareBuffer_Desc saved=desc;XWindowSwapchain_Image image={0};creates=imports=destroys=0;lastStage=0;
   if(broken==1)desc.format=desc.format==5?1:5;
   if(broken==2)desc.width=1599;if(broken==3)desc.height=899;if(broken==4)desc.layers=2;
   VkResult result=createImage((VkDevice)(uintptr_t)1,&s,&image);
   if(broken){CHECK(result==VK_ERROR_INVALID_EXTERNAL_HANDLE);CHECK(creates==0 && imports==0 && destroys==0);CHECK(lastStage==SWAPCHAIN_AHB_PROPERTIES);CHECK(image.image==0 && image.memory==0);}
   else{CHECK(result==VK_SUCCESS);CHECK(creates==1 && imports==1 && destroys==0);CHECK(observed.format==s.imageFormat && observed.extent.width==1600 && observed.extent.height==900);CHECK(image.image!=0 && image.memory!=0);}
   desc=saved;
  }
  XWindowSwapchain_Image image={0};absent=true;creates=imports=0;
  CHECK(createImage((VkDevice)(uintptr_t)1,&s,&image)==VK_ERROR_OUT_OF_HOST_MEMORY && creates==0 && imports==0);
  absent=false;createResult=VK_ERROR_FORMAT_NOT_SUPPORTED;creates=imports=0;
  CHECK(createImage((VkDevice)(uintptr_t)1,&s,&image)==VK_ERROR_FORMAT_NOT_SUPPORTED && creates==1 && imports==0);
  createResult=VK_SUCCESS;importResult=VK_ERROR_INVALID_EXTERNAL_HANDLE;destroys=0;
  CHECK(createImage((VkDevice)(uintptr_t)1,&s,&image)==VK_ERROR_INVALID_EXTERNAL_HANDLE && destroys==1);
  importResult=VK_SUCCESS;
 }
 printf("%s %d actual AHB import checks; %d failures\n",failures?"FAIL":"PASS",checks,failures);return failures?1:0;
}
'''
(OUT/'ahb.c').write_text(code)
compiler = os.environ.get('CC') or next((shutil.which(n) for n in ('cc','clang','gcc','zig') if shutil.which(n)), None)
if not compiler: raise RuntimeError('Set CC or install a C compiler')
compiler_command = [compiler] + (['cc'] if Path(compiler).stem.lower() == 'zig' else [])
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(OUT.parent/'contract-fixed/zig-global'),ZIG_LOCAL_CACHE_DIR=str(OUT/'zig-local'))
cmd=compiler_command+['-std=c11','-O1','-I'+str(CPP/'include'),str(OUT/'ahb.c'),'-o',str(OUT/'ahb.exe')]
r=subprocess.run(cmd,capture_output=True,env=env,timeout=120);(OUT/'build.log').write_bytes(r.stdout+r.stderr)
if r.returncode:print(r.stderr.decode(errors='replace'));raise SystemExit(r.returncode)
r=subprocess.run([str(OUT/'ahb.exe')],capture_output=True,timeout=10);(OUT/'run.log').write_bytes(r.stdout+r.stderr)
print((r.stdout+r.stderr).decode(errors='replace'))
if r.returncode:raise SystemExit(r.returncode)

# Extract the exact production Java methods, using deterministic GL queue and
# allocation stubs. This tests replacement/failure order without loading JNI.
jroot=ROOT/'host/java/com/winlator'
def java_method(path,name):
 s=path.read_text();m=__import__('re').search(r'\b(?:public|private)\s+[\w<>]+\s+'+name+r'\(',s)
 end=s.index('{',m.start())+1;depth=1
 while depth:depth+=(s[end]=='{')-(s[end]=='}');end+=1
 return s[m.start():end]
j=r'''
import java.util.ArrayDeque;
public class BufferFormatTest {
 static int checks;
 static void check(boolean c){checks++;if(!c)throw new AssertionError("check "+checks);}
 static class Texture {boolean destroyed;void destroy(){destroyed=true;}}
 static class GPUImage extends Texture {
  static boolean fail;static long serial=10;long hardwareBufferPtr;int hardwareBufferFormat;
  GPUImage(Drawable owner,boolean cpu,boolean bgra){if(fail)throw new IllegalStateException("allocation");hardwareBufferPtr=++serial;hardwareBufferFormat=bgra?5:1;}
  long getHardwareBufferPtr(){return hardwareBufferPtr;}
'''+java_method(jroot/'renderer/GPUImage.java','matchesHardwareBufferFormat')+r'''
 }
 static class Drawable{Texture texture=new Texture();short width=1600,height=900;Texture getTexture(){return texture;}void setTexture(Texture t){texture=t;}}
 static class Window{Drawable content=new Drawable();Drawable getContent(){return content;}}
 static class View{ArrayDeque<Runnable> queue=new ArrayDeque<>();void queueEvent(Runnable r){queue.add(r);}void drain(){while(!queue.isEmpty())queue.remove().run();}}
 static class Renderer{View xServerView=new View();}
 static class Manager{Window window=new Window();Window getWindow(int id){return id==1?window:null;}}
 static class XServer{Manager windowManager=new Manager();Renderer renderer=new Renderer();Renderer getRenderer(){return renderer;}}
 XServer xServer=new XServer();int errors;
 void recordSwapchainStartup(int stage,int result,int format,int width,int height,int window){errors++;}
'''+java_method(jroot/'xenvironment/components/VortekRendererComponent.java','getWindowHardwareBuffer')+r'''
 public static void main(String[]args){
  BufferFormatTest t=new BufferFormatTest();Drawable d=t.xServer.windowManager.window.content;View q=t.xServer.renderer.xServerView;
  Texture ordinary=d.texture;long bgra=t.getWindowHardwareBuffer(1,true);
  check(bgra!=0 && !ordinary.destroyed && q.queue.size()==1);q.drain();check(ordinary.destroyed);
  check(t.getWindowHardwareBuffer(1,true)==bgra && q.queue.isEmpty());
  Texture old=d.texture;long rgba=t.getWindowHardwareBuffer(1,false);
  check(rgba!=bgra && !old.destroyed && q.queue.size()==1);q.drain();check(old.destroyed);
  check(t.getWindowHardwareBuffer(1,false)==rgba && q.queue.isEmpty());
  old=d.texture;GPUImage.fail=true;
  try{t.getWindowHardwareBuffer(1,true);throw new AssertionError("expected failure");}catch(IllegalStateException expected){}
  check(d.texture==old && !old.destroyed && q.queue.isEmpty() && t.errors==1);
  GPUImage.fail=false;check(t.getWindowHardwareBuffer(1,true)!=rgba);q.drain();check(old.destroyed);
  check(t.getWindowHardwareBuffer(2,false)==0);
  GPUImage image=(GPUImage)d.texture;image.hardwareBufferPtr=0;
  check(!image.matchesHardwareBufferFormat(true));image.hardwareBufferPtr=50;image.hardwareBufferFormat=2;
  check(!image.matchesHardwareBufferFormat(false));
  System.out.println("PASS "+checks+" production Java buffer lifecycle checks");
 }
}
'''
(OUT/'BufferFormatTest.java').write_text(j)
def java_tool(name):
    suffix = '.exe' if os.name == 'nt' else ''
    configured = os.environ.get('JAVA_HOME')
    candidate = Path(configured) / 'bin' / (name + suffix) if configured else None
    result = str(candidate) if candidate and candidate.is_file() else shutil.which(name)
    if not result: raise RuntimeError('Set JAVA_HOME or put JDK17 on PATH')
    return result
for cmd in [[java_tool('javac'),'-d',str(OUT),str(OUT/'BufferFormatTest.java')],[java_tool('java'),'-cp',str(OUT),'BufferFormatTest']]:
 r=subprocess.run(cmd,capture_output=True,timeout=20);print((r.stdout+r.stderr).decode(errors='replace'))
 if r.returncode:raise SystemExit(r.returncode)
(OUT/'java-run.log').write_bytes(r.stdout+r.stderr)
(OUT/'result.json').write_text(json.dumps({'status':'PASS','scope':'92 extracted production AHB native checks + 12 Java lifecycle checks; no physical Mali execution'},indent=2)+'\n')
