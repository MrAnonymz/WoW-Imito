Vortek focused diagnostics, updated 2026-10-30

Run-ExtensionFilterTest.ps1 compiles the actual production extension_filter.h
as a small freestanding Windows x64 program. Seven checks cover supported and
unsupported automatic additions, exact name matching, zero counts, duplicate
advertisements, stable order, and unchanged candidate inputs.

The production request_handler.c change filters only Vortek's automatically
added device extensions using vkEnumerateDeviceExtensionProperties. Errors
from enumeration are propagated. A failed creation/preparation logs VkResult
under EnorialVortek. This is server-only and does not change the IPC protocol.

Run-MemoryPropertiesTest.ps1 extracts the actual VkMemoryHeap/MemoryType/
PhysicalDeviceMemoryProperties serializer functions from the current header.
It checks the actual production host and guest implementations using 1..16
heaps, 17 memory types, non-zero padding, >4GiB sizes, wire bounds, canonical
packed fields and round-trip preservation.
Both source endpoints must have identical field serializers and pass all cases.

The former memory_properties_wire.patch proposal has already been applied to
both production endpoints. VkMemoryHeap has sizeof16 on the 64-bit ABI but
12 bytes of fields; the old count*12 memcpy truncated the native array.
The current implementation serializes each heap's fields explicitly.

Both Vortek endpoints must adopt this corrected packed layout together:
Android libvortekrenderer and bundled glibc libvulkan_vortek.so. The payload
length remains count*12 but field placement changes for heap counts above 1.
Applying it on only one side is not protocol-compatible. Do not reapply the
historical proposal or change only one endpoint. Current builds already carry
the paired implementation; this test checks that it remains consistent.

2026-10-21: APK107 also includes Samsung per-format native BC selection.
Run-NativeBCTest.ps1 compiles the actual create/needsDecode/format functions
extracted from production, with a stub physical-driver query. Its22 checks
cover the captured S26 BC1/2/3 capability table, missing required usage flags,
unsupported/non-BC formats, other GPU vendors and full native BC support.
This correction changes no IPC fields.
