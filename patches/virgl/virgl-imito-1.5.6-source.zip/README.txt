VirGL renderer as used by WoW Imito 1.5.6. The Android server now detects
refused EGL context creation and restoration, and stops command processing before
submitting a frame fence after a failed command. Synchronization orders production
of a shared texture and its use by the compositor. Build the native CMake target
within the matching Winlator integration. Retained source notices cover individual
files. VirGL is distributed under the MIT license. The Winlator Java integration
uses LGPL-2.1; see LICENSE-LGPL-2.1.txt.
