#define _GNU_SOURCE
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

static atomic_int interrupt_send;
static atomic_int fail_realloc;
static void* fixture_realloc(void* pointer, size_t length) {
    if (atomic_exchange(&fail_realloc, 0)) { errno = ENOMEM; return NULL; }
    return realloc(pointer, length);
}
static ssize_t fixture_send(int fd, const void* bytes, size_t size, int flags) {
    if (atomic_exchange(&interrupt_send, 0)) { errno = EINTR; return -1; }
    return syscall(SYS_sendto, fd, bytes, size, flags, NULL, 0);
}
#define send fixture_send
#define realloc fixture_realloc
#include "xoutput_stream.c"
#undef send
#undef realloc

static unsigned char jni_source[16];
static jsize array_length(JNIEnv* env, jarray value) { return 4; }
static void array_region(JNIEnv* env, jbyteArray value, jsize start, jsize length, jbyte* out) {
    memcpy(out, jni_source + start, length);
}
static jboolean no_exception(JNIEnv* env) { return JNI_FALSE; }
static jlong direct_capacity(JNIEnv* env, jobject value) { return sizeof(jni_source); }
static void* direct_address(JNIEnv* env, jobject value) { return jni_source; }
static const struct JNINativeInterface fake_jni = {
    .GetArrayLength = array_length, .GetByteArrayRegion = array_region,
    .ExceptionCheck = no_exception, .GetDirectBufferCapacity = direct_capacity,
    .GetDirectBufferAddress = direct_address,
};

static uint64_t nanos(void) {
    struct timespec now; clock_gettime(CLOCK_MONOTONIC, &now);
    return (uint64_t)now.tv_sec * 1000000000 + now.tv_nsec;
}
static int fd_count(void) {
    DIR* directory = opendir("/proc/self/fd"); assert(directory);
    int count = 0; struct dirent* entry;
    while ((entry = readdir(directory))) if (entry->d_name[0] != '.') count++;
    closedir(directory); return count;
}
static void pair(int sockets[2]) {
    assert(!socketpair(AF_UNIX, SOCK_STREAM, 0, sockets));
    int size = 4096;
    assert(!setsockopt(sockets[0], SOL_SOCKET, SO_SNDBUF, &size, sizeof(size)));
    struct timeval timeout = {.tv_sec = 3};
    assert(!setsockopt(sockets[1], SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)));
}
static size_t fill(int fd) {
    char bytes[4096]; memset(bytes, 0x11, sizeof(bytes)); size_t total = 0;
    for (;;) {
        ssize_t n = send(fd, bytes, sizeof(bytes), MSG_DONTWAIT | MSG_NOSIGNAL);
        if (n < 0) { assert(errno == EAGAIN || errno == EWOULDBLOCK); return total; }
        assert(n > 0); total += (size_t)n;
    }
}
static void read_pattern(int fd, size_t length, unsigned char value) {
    unsigned char bytes[4096];
    while (length) {
        size_t take = length < sizeof(bytes) ? length : sizeof(bytes);
        ssize_t n = read(fd, bytes, take); assert(n > 0);
        for (ssize_t i = 0; i < n; i++) assert(bytes[i] == value);
        length -= (size_t)n;
    }
}
static bool enqueue(XOutputStream* output, size_t length, unsigned char value) {
    if (!ensureSpaceIsAvailable(output, (int)length)) return false;
    memset(output->buffer.data, value, length); output->buffer.position = (int)length;
    uint64_t start = nanos();
    bool okay = XOutputStream_send(output);
    uint64_t elapsed = nanos() - start;
    assert(elapsed < 500000000ULL);
    return okay;
}
int main(void) {
    setbuf(stdout, NULL);
    signal(SIGPIPE, SIG_DFL); /* Closed peers must not kill this process. */
    int initial_fds = fd_count(), sockets[2];
    pair(sockets); XOutputStream* output = XOutputStream_allocate(sockets[0], 64); assert(output);
    assert(enqueue(output, 1048576, 0x51)); /* Real positive partial send. */
    assert(output->workerStarted);
    assert(enqueue(output, 32, 0x52));
    read_pattern(sockets[1], 1048576, 0x51); read_pattern(sockets[1], 32, 0x52);
    XOutputStream_destroy(output); close(sockets[0]); close(sockets[1]);
    puts("PASS: real positive short send retains every byte, followed by an ordered 32-byte event.");

    pair(sockets); output = XOutputStream_allocate(sockets[0], 64); assert(output);
    size_t filler = fill(sockets[0]);
    uint64_t started = nanos(); assert(enqueue(output, 32, 0x53));
    printf("Full socket enqueue: %.3f ms\n", (nanos() - started) / 1000000.0);
    read_pattern(sockets[1], filler, 0x11); read_pattern(sockets[1], 32, 0x53);
    atomic_store(&interrupt_send, 1); assert(enqueue(output, 128, 0x54));
    read_pattern(sockets[1], 128, 0x54);
    XOutputStream_destroy(output); close(sockets[0]); close(sockets[1]);
    puts("PASS: backpressure and EINTR queue the complete message without blocking the caller.");

    pair(sockets); output = XOutputStream_allocate(sockets[0], 64); assert(output);
    filler = fill(sockets[0]); int pipefd[2]; assert(!pipe(pipefd));
    int borrowed = pipefd[0]; output->ancillaryFd = borrowed;
    assert(enqueue(output, 65536, 0x55)); close(borrowed);
    assert(write(pipefd[1], "Q", 1) == 1);
    read_pattern(sockets[1], filler, 0x11);
    unsigned char bytes[1024]; size_t remaining = 65536; int rights = 0;
    while (remaining) {
        struct iovec iov = {.iov_base = bytes, .iov_len = remaining < sizeof(bytes) ? remaining : sizeof(bytes)};
        union { struct cmsghdr alignment; char bytes[CMSG_SPACE(8 * sizeof(int))]; } control;
        struct msghdr message = {.msg_iov = &iov, .msg_iovlen = 1,
            .msg_control = control.bytes, .msg_controllen = sizeof(control.bytes)};
        ssize_t n = recvmsg(sockets[1], &message, 0); assert(n > 0 && !(message.msg_flags & MSG_CTRUNC));
        for (ssize_t i = 0; i < n; i++) assert(bytes[i] == 0x55);
        remaining -= (size_t)n;
        for (struct cmsghdr* c = CMSG_FIRSTHDR(&message); c; c = CMSG_NXTHDR(&message, c)) {
            assert(c->cmsg_level == SOL_SOCKET && c->cmsg_type == SCM_RIGHTS);
            size_t count = (c->cmsg_len - CMSG_LEN(0)) / sizeof(int);
            for (size_t i = 0; i < count; i++) {
                int received; memcpy(&received, (char*)CMSG_DATA(c) + i * sizeof(int), sizeof(int));
                char value; assert(read(received, &value, 1) == 1 && value == 'Q');
                close(received); rights++;
            }
        }
    }
    assert(rights == 1);
    close(pipefd[1]); XOutputStream_destroy(output); close(sockets[0]); close(sockets[1]);
    puts("PASS: deferred SCM_RIGHTS survives borrowed-fd closure and accompanies partial writes exactly once.");

    pair(sockets); output = XOutputStream_allocate(sockets[0], 64); assert(output);
    int old = sockets[0]; close(sockets[0]); int replacement[2]; pair(replacement); assert(replacement[0] == old);
    assert(enqueue(output, 32, 0x56)); read_pattern(sockets[1], 32, 0x56);
    char byte; assert(recv(replacement[1], &byte, 1, MSG_DONTWAIT) < 0 && errno == EAGAIN);
    XOutputStream_destroy(output);
    assert(send(replacement[0], "R", 1, MSG_NOSIGNAL) == 1 && read(replacement[1], &byte, 1) == 1 && byte == 'R');
    close(sockets[1]); close(replacement[0]); close(replacement[1]);
    puts("PASS: connector fd reuse cannot redirect the worker or its shutdown to a different socket.");

    pair(sockets); output = XOutputStream_allocate(sockets[0], 64); assert(output);
    filler = fill(sockets[0]); assert(enqueue(output, 32, 0x57));
    started = nanos(); XOutputStream_destroy(output);
    assert(nanos() - started < 500000000ULL);
    close(sockets[0]); close(sockets[1]);
    pair(sockets); output = XOutputStream_allocate(sockets[0], 64); assert(output); close(sockets[1]);
    assert(!enqueue(output, 32, 0x58)); XOutputStream_destroy(output); close(sockets[0]);
    puts("PASS: teardown wakes a worker with an undrained peer; peer closure produces an error without SIGPIPE.");

    pair(sockets); output = XOutputStream_allocate(sockets[0], 64); assert(output); filler = fill(sockets[0]);
    for (unsigned int i = 0; i < XOUTPUT_MAX_PENDING_PACKETS; i++) assert(enqueue(output, 1, 0x59));
    assert(!enqueue(output, 1, 0x59)); assert(!enqueue(output, 1, 0x5a));
    assert(output->failed); XOutputStream_destroy(output); close(sockets[0]); close(sockets[1]);
    pair(sockets); output = XOutputStream_allocate(sockets[0], 64); assert(output); fill(sockets[0]);
    assert(enqueue(output, XOUTPUT_MAX_PENDING_BYTES, 0x5b));
    assert(!enqueue(output, 1, 0x5c)); assert(output->failed);
    XOutputStream_destroy(output); close(sockets[0]); close(sockets[1]);
    puts("PASS: byte limit and packet limit both terminate the connection explicitly.");

    assert(!XOutputStream_allocate(-1, 64));
    assert(!XOutputStream_allocate(-1, -1));
    assert(!XOutputStream_allocate(-1, INT_MAX));
    pair(sockets); output = XOutputStream_allocate(sockets[0], 16); assert(output);
    memset(output->buffer.data, 0x6a, 16); output->buffer.position = 16;
    void* original = output->buffer.data;
    atomic_store(&fail_realloc, 1);
    Java_com_winlator_xconnector_XOutputStream_writeByte((jlong)output, 0x7f);
    assert(output->failed && output->bufferFailed && output->buffer.data == original && output->buffer.position == 16);
    Java_com_winlator_xconnector_XOutputStream_writeLong((jlong)output, 0);
    for (int i = 0; i < 16; i++) assert(((unsigned char*)original)[i] == 0x6a);
    assert(!XOutputStream_send(output));
    XOutputStream_destroy(output); close(sockets[0]); close(sockets[1]);
    puts("PASS: forced realloc failure preserves the original allocation and canaries, skips further writes, and returns failure.");

    JNIEnv environment = &fake_jni;
    for (int mode = 0; mode < 5; mode++) {
        pair(sockets); output = XOutputStream_allocate(sockets[0], 16); assert(output);
        memset(output->buffer.data, 0x6b, 16); output->buffer.position = 8;
        if (mode == 0) Java_com_winlator_xconnector_XOutputStream_writePad((jlong)output, -1);
        if (mode == 1) Java_com_winlator_xconnector_XOutputStream_writePad((jlong)output, INT_MAX);
        if (mode == 2) Java_com_winlator_xconnector_XOutputStream_writeAt(&environment, NULL, (jlong)output, 6, (jbyteArray)1);
        if (mode == 3) Java_com_winlator_xconnector_XOutputStream_writeByteBuffer(&environment, NULL, (jlong)output, (jobject)1, 15, 2);
        if (mode == 4) Java_com_winlator_xconnector_XOutputStream_writeByteBuffer(&environment, NULL, (jlong)output, (jobject)1, -1, 1);
        assert(output->failed && output->buffer.position == 8);
        for (int i = 0; i < 16; i++) assert(((unsigned char*)output->buffer.data)[i] == 0x6b);
        assert(!XOutputStream_send(output));
        XOutputStream_destroy(output); close(sockets[0]); close(sockets[1]);
    }
    puts("PASS: negative/overflow padding, out-of-packet header patches, and invalid direct-buffer slices leave canaries intact.");
    assert(fd_count() == initial_fds);
    puts("PASS: bounded queue overflow closes explicitly, never reports truncated success; all owned descriptors released.");
    return 0;
}
