"""Exercise production Vortek extension enumeration without a GPU or Android."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
import shutil
import uuid

ROOT = Path(__file__).resolve().parents[1]
CPP = ROOT / 'host/vortekrenderer'


def function(text, name):
    match = re.search(r'^(?:static\s+)?[\w* \t]+\b' + name + r'\(', text, re.M)
    if not match:
        raise ValueError('Missing production function ' + name)
    start = match.start()
    end = text.index('{', start) + 1
    depth = 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[start:end] + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--helper', type=Path, default=CPP / 'src/vulkan_helper.c')
    parser.add_argument('--request-handler', type=Path, default=CPP / 'src/request_handler.c')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    output = (args.output or ROOT / 'verification/results/extensions' /
              ('extensions-' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:6])).resolve()
    output.relative_to(ROOT)
    output.mkdir(parents=True, exist_ok=False)
    helper = args.helper.resolve(strict=True)
    handler = args.request_handler.resolve(strict=True)
    header = CPP / 'include/vulkan_helper.h'
    code = r'''
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vulkan/vulkan_core.h"
#include "extension_filter.h"
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
typedef struct { int size; void** elements; } ArrayList;
typedef struct { int unused; } JMethods;
typedef struct {
 int memoryPool; ArrayList *exposedDeviceExtensions, *disabledDeviceExtensions;
 void *inputBuffer, *clientRing; JMethods jmethods;
} VkContext;
static struct {
 PFN_vkEnumerateDeviceExtensionProperties vkEnumerateDeviceExtensionProperties;
 PFN_vkCreateDevice vkCreateDevice;
} vulkanWrapper;
static void* vt_alloc(void* pool, size_t size) { (void)pool; return calloc(1, size); }
#define VT_SERIALIZE_CMD(type, value) char* outputBuffer = NULL; int bufferSize = 0
#define VkObject_fromId(id) ((VkPhysicalDevice)(uintptr_t)(id))
#define ANDROID_LOG_ERROR 6
#define __android_log_print(...) 0
enum { VULKAN_DEVICE_CREATE = 18 };
static int deviceInitializations, reports, reportedStage;
static VkResult createResult, reportedResult, sentResult;
static VkFormat reportedFormat;
static VkExtent2D reportedExtent;
static int reportedWindow;
static void vt_unserialize_vkCreateDevice(VkPhysicalDevice id, VkDeviceCreateInfo* info, void* allocator, void* device, void* input, void* pool) {
 *(uint64_t*)id = 1; info->sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
}
static void disableUnsupportedDeviceFeatures(VkPhysicalDevice physical, VkDeviceCreateInfo* info) {}
static void initVulkanDevice(VkContext* context, VkPhysicalDevice physical, VkDevice device) { deviceInitializations++; }
static void reportSwapchainStartup(JMethods* methods, int stage, VkResult result, VkFormat format, VkExtent2D extent, int window) {
 reports++; reportedStage = stage; reportedResult = result; reportedFormat = format; reportedExtent = extent; reportedWindow = window;
}
static void vt_send(void* ring, VkResult result, void* output, int size) { sentResult = result; }
static VkResult VKAPI_CALL createDevice(VkPhysicalDevice physical, const VkDeviceCreateInfo* info, const VkAllocationCallbacks* callbacks, VkDevice* device) {
 *device = createResult == VK_SUCCESS ? (VkDevice)2 : VK_NULL_HANDLE; return createResult;
}
static const char* nativeNames[] = {
 "VK_KHR_swapchain", "VK_EXT_robustness2", "VK_KHR_timeline_semaphore",
 "VK_KHR_present_id", "VK_KHR_present_wait", "VK_KHR_present_id2", "VK_KHR_present_wait2",
 "VK_EXT_swapchain_maintenance1", "VK_KHR_swapchain_maintenance1", "VK_GOOGLE_display_timing",
 "VK_EXT_shader_module_identifier"
};
static VkResult VKAPI_CALL enumerate(VkPhysicalDevice physical, const char* layer, uint32_t* count, VkExtensionProperties* props) {
 (void)physical; (void)layer;
 if (props) for (unsigned i = 0; i < ARRAY_SIZE(nativeNames); i++) {
  strcpy(props[i].extensionName, nativeNames[i]); props[i].specVersion = 9;
 }
 *count = ARRAY_SIZE(nativeNames); return VK_SUCCESS;
}
static int checks, failures;
#define CHECK(c) do { checks++; if (!(c)) { fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #c); failures++; } } while (0)
static const VkExtensionProperties* find(VkExtensionProperties* props, uint32_t count, const char* name) {
 for (uint32_t i = 0; i < count; i++) if (!strcmp(props[i].extensionName, name)) return &props[i];
 return NULL;
}
'''
    declarations = re.search(r'static const char\* globalImplementedDeviceExtensions\[\] = \{[^}]+\};', header.read_text())
    if not declarations:
        raise ValueError('Missing production implemented-extension list')
    code += declarations.group(0) + '\n'
    production = helper.read_text()
    code += function(production, 'injectExtensions')
    code += function(production, 'injectExtensions2')
    if 'static bool isNativeSwapchainExtension(' in production:
        code += function(production, 'isNativeSwapchainExtension')
    code += function(production, 'getExposedDeviceExtensionProperties')
    code += function(handler.read_text(), 'vt_handle_vkCreateDevice')
    code += r'''
int main(void) {
 vulkanWrapper.vkEnumerateDeviceExtensionProperties = enumerate;
 for (int explicitList = 0; explicitList < 2; explicitList++) {
  ArrayList requested = { .size = ARRAY_SIZE(nativeNames), .elements = (void**)nativeNames };
  VkContext context = { .exposedDeviceExtensions = explicitList ? &requested : NULL };
  uint32_t count = 0;
  VkExtensionProperties* props = getExposedDeviceExtensionProperties(&context, (VkPhysicalDevice)1, &count);
  CHECK(props != NULL);
  CHECK(find(props, count, "VK_KHR_swapchain") != NULL);
  const VkExtensionProperties* robust = find(props, count, "VK_EXT_robustness2");
  CHECK(robust && robust->specVersion == 9);
  CHECK(find(props, count, "VK_KHR_timeline_semaphore") != NULL);
  CHECK(find(props, count, "VK_EXT_map_memory_placed") != NULL);
  for (unsigned i = 3; i < ARRAY_SIZE(nativeNames); i++) CHECK(find(props, count, nativeNames[i]) == NULL);
 }
 // Existing per-engine filters still apply to supported native capabilities.
 void* disabledNames[] = { "VK_EXT_robustness2" };
 ArrayList disabled = { .size = 1, .elements = disabledNames };
 VkContext context = { .disabledDeviceExtensions = &disabled };
 uint32_t count = 0;
 VkExtensionProperties* props = getExposedDeviceExtensionProperties(&context, (VkPhysicalDevice)1, &count);
 CHECK(find(props, count, "VK_EXT_robustness2") == NULL);
 CHECK(find(props, count, "VK_KHR_timeline_semaphore") != NULL);
 // The real request handler retains the precise error before any window exists.
 // A successful device creates no failure event and follows its usual init path.
 vulkanWrapper.vkCreateDevice = createDevice;
 VkResult failuresToTest[] = { VK_ERROR_OUT_OF_HOST_MEMORY, VK_ERROR_OUT_OF_DEVICE_MEMORY,
  VK_ERROR_INITIALIZATION_FAILED, VK_ERROR_DEVICE_LOST, VK_ERROR_EXTENSION_NOT_PRESENT,
  VK_ERROR_FEATURE_NOT_PRESENT, VK_ERROR_INCOMPATIBLE_DRIVER, VK_ERROR_UNKNOWN };
 for (unsigned i = 0; i < ARRAY_SIZE(failuresToTest); i++) {
  createResult = failuresToTest[i]; reports = 0; deviceInitializations = 0;
  vt_handle_vkCreateDevice(&context);
  CHECK(reports == 1 && reportedStage == 18 && reportedResult == createResult);
  CHECK(reportedFormat == VK_FORMAT_UNDEFINED && reportedExtent.width == 0 && reportedExtent.height == 0 && reportedWindow == 0);
  CHECK(sentResult == createResult && deviceInitializations == 0);
 }
 createResult = VK_SUCCESS; reports = 0; deviceInitializations = 0;
 vt_handle_vkCreateDevice(&context);
 CHECK(reports == 0 && deviceInitializations == 1 && sentResult == VK_SUCCESS);
 printf("%s: %d production Vortek extension checks; %d failures\n", failures ? "FAIL" : "PASS", checks, failures);
 return failures ? 1 : 0;
}
'''
    source = output / 'extensions.c'
    source.write_text(code)
    compiler = os.environ.get('CC') or next((shutil.which(n) for n in ('cc','clang','gcc','zig') if shutil.which(n)), None)
    if not compiler: raise RuntimeError('Set CC or install a C compiler')
    compiler_command = [compiler] + (['cc'] if Path(compiler).stem.lower() == 'zig' else [])
    command = compiler_command + ['-std=c11', '-O1', '-I' + str(CPP / 'include'), str(source), '-o', str(output / 'extensions.exe')]
    env = dict(os.environ, ZIG_GLOBAL_CACHE_DIR=str(output / 'zig-global'), ZIG_LOCAL_CACHE_DIR=str(output / 'zig-local'))
    build = subprocess.run(command, capture_output=True, env=env, timeout=120)
    (output / 'build.log').write_bytes(build.stdout + build.stderr)
    if build.returncode:
        print(build.stderr.decode(errors='replace'))
        return build.returncode
    run = subprocess.run([str(output / 'extensions.exe')], capture_output=True, timeout=30)
    (output / 'run.log').write_bytes(run.stdout + run.stderr)
    report = {
        'status': 'PASS' if run.returncode == 0 else 'FAIL', 'exitCode': run.returncode,
        'scope': 'Actual native extension enumeration/injection and device-create request with a fake host ICD; no physical GPU execution',
        'sources': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), helper, handler, header]},
        'command': command,
    }
    (output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(run.stdout.decode(errors='replace') + run.stderr.decode(errors='replace'))
    print('REPORT', output.relative_to(ROOT))
    return run.returncode


if __name__ == '__main__':
    raise SystemExit(main())
