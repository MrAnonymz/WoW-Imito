#ifndef VORTEK_FENCE_EXPORT_H
#define VORTEK_FENCE_EXPORT_H
/* An extension name does not imply support for every external handle type. */
static bool supportsSyncFdFenceExport(PFN_vkGetPhysicalDeviceExternalFenceProperties query,
                                     VkPhysicalDevice physical) {
    if (!query) return false;
    VkPhysicalDeviceExternalFenceInfo info = {
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_EXTERNAL_FENCE_INFO,
        .handleType = VK_EXTERNAL_FENCE_HANDLE_TYPE_SYNC_FD_BIT};
    VkExternalFenceProperties properties = {.sType = VK_STRUCTURE_TYPE_EXTERNAL_FENCE_PROPERTIES};
    query(physical, &info, &properties);
    return (properties.externalFenceFeatures & VK_EXTERNAL_FENCE_FEATURE_EXPORTABLE_BIT) &&
        (properties.compatibleHandleTypes & VK_EXTERNAL_FENCE_HANDLE_TYPE_SYNC_FD_BIT);
}
#endif
