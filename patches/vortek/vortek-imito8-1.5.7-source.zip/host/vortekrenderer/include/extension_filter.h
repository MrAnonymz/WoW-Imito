#ifndef VORTEK_EXTENSION_FILTER_H
#define VORTEK_EXTENSION_FILTER_H

#include "vulkan/vulkan_core.h"

static inline int vt_extension_name_equal(const char* left, const char* right) {
    while (*left && *left == *right) { left++; right++; }
    return *left == *right;
}

/* Filter Vortek's optional additions only. Client requests stay untouched. */
static inline uint32_t vt_filter_supported_extensions(
        const char* const* additions, uint32_t additionCount,
        const VkExtensionProperties* supported, uint32_t supportedCount,
        const char** output) {
    uint32_t count = 0;
    for (uint32_t i = 0; i < additionCount; i++) {
        for (uint32_t j = 0; j < supportedCount; j++) {
            if (vt_extension_name_equal(additions[i], supported[j].extensionName)) {
                output[count++] = additions[i];
                break;
            }
        }
    }
    return count;
}

#endif
