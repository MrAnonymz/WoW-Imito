#include <unistd.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <linux/futex.h>
#include <limits.h>

#include "ring_buffer.h"
#include "time_utils.h"
#include "events.h"

#define STRUCT_OFFSETS() \
    struct Offsets { \
        uint32_t head; \
        uint32_t tail; \
        uint32_t status; \
        void* buffer; \
    }

#ifdef __ANDROID__
#include <android/log.h>
#define debug_printf(...) __android_log_print(ANDROID_LOG_DEBUG, "System.out", __VA_ARGS__)
#else
#define debug_printf(...) fprintf(stderr, __VA_ARGS__)
#endif

void RingBuffer_setHead(RingBuffer* ring, uint32_t head) {
    atomic_store_explicit(ring->head, head, memory_order_release);
    atomic_thread_fence(memory_order_seq_cst);
    if (RingBuffer_hasStatus(ring,RING_STATUS_WRITE_SLEEP))
        syscall(SYS_futex,ring->head,FUTEX_WAKE,1,NULL,NULL,0);
}

uint32_t RingBuffer_getHead(RingBuffer* ring) {
    return atomic_load_explicit(ring->head, memory_order_acquire);
}

void RingBuffer_setTail(RingBuffer* ring, uint32_t tail) {
    atomic_store_explicit(ring->tail, tail, memory_order_release);
    atomic_thread_fence(memory_order_seq_cst);
    if (RingBuffer_hasStatus(ring,RING_STATUS_READ_SLEEP))
        syscall(SYS_futex,ring->tail,FUTEX_WAKE,1,NULL,NULL,0);
}

uint32_t RingBuffer_getTail(RingBuffer* ring) {
    return atomic_load_explicit(ring->tail, memory_order_acquire);
}

void RingBuffer_setStatus(RingBuffer* ring, uint32_t status) {
    atomic_fetch_or_explicit(ring->status, status, memory_order_seq_cst);
    if (status & RING_STATUS_EXIT) {
        syscall(SYS_futex,ring->head,FUTEX_WAKE,INT_MAX,NULL,NULL,0);
        syscall(SYS_futex,ring->tail,FUTEX_WAKE,INT_MAX,NULL,NULL,0);
    }
}

void RingBuffer_unsetStatus(RingBuffer* ring, uint32_t status) {
    atomic_fetch_and_explicit(ring->status, ~status, memory_order_seq_cst);
}

bool RingBuffer_hasStatus(RingBuffer* ring, uint32_t status) {
    return (atomic_load_explicit(ring->status, memory_order_seq_cst) & status);
}

RingBuffer* RingBuffer_create(int shmFd, uint32_t bufferSize) {
    if (!bufferSize || (bufferSize & (bufferSize-1)) || bufferSize>INT_MAX-64) return NULL;
    RingBuffer* ring = calloc(1, sizeof(RingBuffer));
    if (!ring) return NULL;

    STRUCT_OFFSETS();

    int shmSize = RingBuffer_getSHMemSize(bufferSize);
    void* sharedData = mmap(NULL, shmSize, PROT_READ | PROT_WRITE, MAP_SHARED, shmFd, 0);
    if (sharedData == MAP_FAILED) { free(ring); return NULL; }
    ring->sharedData = sharedData;
#ifdef __ANDROID__
    memset(sharedData, 0, shmSize); // Host creates; the guest only attaches.
#endif

    ring->head = sharedData + offsetof(struct Offsets, head);
    ring->tail = sharedData + offsetof(struct Offsets, tail);
    ring->status = sharedData + offsetof(struct Offsets, status);
    ring->buffer = sharedData + offsetof(struct Offsets, buffer);
    ring->bufferSize = bufferSize;

    RingBuffer_setStatus(ring, RING_STATUS_IDLE);
#ifdef __ANDROID__
    RingBuffer_setStatus(ring, RING_STATUS_HOST_FUTEX);
#else
    RingBuffer_setStatus(ring, RING_STATUS_GUEST_FUTEX);
#endif
    return ring;
}

uint32_t RingBuffer_size(RingBuffer* ring) {
    return RingBuffer_getTail(ring) - RingBuffer_getHead(ring);
}

uint32_t RingBuffer_freeSpace(RingBuffer* ring) {
    return ring->bufferSize - RingBuffer_size(ring);
}

bool RingBuffer_read(RingBuffer* ring, void* data, uint32_t size) {
    if (size > ring->bufferSize) {
        debug_printf("ring: buffer overflow on read (%d/%d)\n", size, ring->bufferSize);
        return false;
    }

    if (!RingBuffer_waitForRead(ring, size)) return false;
    uint32_t head = RingBuffer_getHead(ring);
    uint32_t offset = head & (ring->bufferSize - 1);

    if ((offset + size) <= ring->bufferSize) {
        memcpy(data, ring->buffer + offset, size);
    }
    else {
        uint32_t start = ring->bufferSize - offset;
        memcpy(data, ring->buffer + offset, start);
        memcpy(data + start, ring->buffer, size - start);
    }

    RingBuffer_setHead(ring, head + size);
    return true;
}

bool RingBuffer_write(RingBuffer* ring, const void* data, uint32_t size) {
    if (size > ring->bufferSize) {
        debug_printf("ring: buffer overflow on write (%d/%d)\n", size, ring->bufferSize);
        return false;
    }

    if (!RingBuffer_waitForWrite(ring, size)) return false;
    uint32_t tail = RingBuffer_getTail(ring);
    uint32_t offset = tail & (ring->bufferSize - 1);

    if ((offset + size) <= ring->bufferSize) {
        memcpy(ring->buffer + offset, data, size);
    }
    else {
        uint32_t start = ring->bufferSize - offset;
        memcpy(ring->buffer + offset, data, start);
        memcpy(ring->buffer, data + start, size - start);
    }

    RingBuffer_setTail(ring, tail + size);
    return true;
}

uint32_t RingBuffer_getSHMemSize(uint32_t bufferSize) {
    STRUCT_OFFSETS();

    return bufferSize + offsetof(struct Offsets, buffer);
}

void RingBuffer_free(RingBuffer* ring) {
    if (!ring) return;

    if (ring->sharedData) {
        RingBuffer_setStatus(ring, RING_STATUS_EXIT);
        munmap(ring->sharedData, RingBuffer_getSHMemSize(ring->bufferSize));
        ring->sharedData = NULL;
    }

    free(ring);
}

static bool waitForRing(RingBuffer* ring,uint32_t size,bool reading) {
    if(size>ring->bufferSize)return false;
    uint32_t legacyIteration=0,spins=0;
    const uint32_t sleeping=reading?RING_STATUS_READ_SLEEP:RING_STATUS_WRITE_SLEEP;
    atomic_uint* word=reading?ring->tail:ring->head;
    for(;;) {
        if(RingBuffer_hasStatus(ring,RING_STATUS_EXIT))return false;
        if((reading?RingBuffer_size(ring):RingBuffer_freeSpace(ring))>=size)return true;
        uint32_t status=atomic_load_explicit(ring->status,memory_order_acquire);
        if((status&RING_STATUS_FUTEX_MASK)!=RING_STATUS_FUTEX_READY) {
            busyWait(&legacyIteration);continue; // Paired upgrade; old bridges remain compatible.
        }
        if(spins++<32) {__asm__ volatile("yield");continue;}
        RingBuffer_setStatus(ring,sleeping);
        // Registration + recheck paired with the publisher's StoreLoad fence
        // prevents a missed wake between testing the queue and entering futex.
        uint32_t expected=atomic_load_explicit(word,memory_order_acquire);
        if(!RingBuffer_hasStatus(ring,RING_STATUS_EXIT) &&
                (reading?RingBuffer_size(ring):RingBuffer_freeSpace(ring))<size) {
            const struct timespec safetyDeadline={.tv_sec=0,.tv_nsec=50000000};
            int result=syscall(SYS_futex,word,FUTEX_WAIT,expected,&safetyDeadline,NULL,0);
            if(result<0 && (errno==ENOSYS || errno==EPERM || errno==EINVAL))
                RingBuffer_setStatus(ring,RING_STATUS_FUTEX_DISABLED);
        }
        RingBuffer_unsetStatus(ring,sleeping);
    }
}
bool RingBuffer_waitForRead(RingBuffer* ring,uint32_t size){return waitForRing(ring,size,true);}
bool RingBuffer_waitForWrite(RingBuffer* ring,uint32_t size){return waitForRing(ring,size,false);}
