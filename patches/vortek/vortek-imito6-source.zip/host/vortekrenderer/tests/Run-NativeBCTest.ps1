$ErrorActionPreference = 'Stop'
$project = 'E:\Code\MD\WoW-Enorial-Android'
$bin = Join-Path $project 'build-tools\sdk\ndk\24.0.8215888\toolchains\llvm\prebuilt\windows-x86_64\bin'
$kernel32 = 'C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0\um\x64\kernel32.lib'
$source = [IO.File]::ReadAllText((Join-Path $PSScriptRoot '..\src\texture_decoder.c'))
$begin = $source.IndexOf('TextureDecoder* TextureDecoder_create(')
$end = $source.IndexOf('void TextureDecoder_destroy(', $begin)
$formatBegin = $source.IndexOf('bool isCompressedFormat(')
$formatEnd = $source.IndexOf('VkResult getCompressedImageFormatProperties(', $formatBegin)
if ($begin -lt 0 -or $end -le $begin -or $formatBegin -lt 0 -or $formatEnd -le $formatBegin) { throw 'Production functions not found' }
$actual = $source.Substring($formatBegin, $formatEnd-$formatBegin) + $source.Substring($begin,$end-$begin)
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'native_bc_actual.inc'),$actual)
$obj = Join-Path $PSScriptRoot 'native_bc_test.obj'
$exe = Join-Path $PSScriptRoot 'native_bc_test.exe'
& (Join-Path $bin 'clang.exe') --target=x86_64-pc-windows-msvc -ffreestanding -fno-builtin -fno-stack-protector -O1 -I (Join-Path $PSScriptRoot '..\include') -c (Join-Path $PSScriptRoot 'native_bc_test.c') -o $obj
if ($LASTEXITCODE -ne 0) { throw 'Native BC capability test compile failed' }
& (Join-Path $bin 'ld.lld.exe') -flavor link /entry:mainCRTStartup /subsystem:console $obj $kernel32 "/out:$exe"
if ($LASTEXITCODE -ne 0) { throw 'Native BC capability test link failed' }
& $exe
if ($LASTEXITCODE -ne 0) { throw "Native BC capability failures: $LASTEXITCODE" }
'PASS: 22 checks; captured S26 formats, missing capabilities, non-BC, unsupported BC, other vendors and full native BC.'
