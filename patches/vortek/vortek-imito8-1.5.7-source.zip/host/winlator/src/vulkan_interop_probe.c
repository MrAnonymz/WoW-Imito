#define VK_USE_PLATFORM_ANDROID_KHR 1
#define VK_NO_PROTOTYPES 1
#include <vulkan/vulkan.h>
#include <android/hardware_buffer.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <GLES2/gl2ext.h>
#include <stdbool.h>
#include <stdlib.h>
#include <dlfcn.h>
#include "fresh_linear_buffer.h"
#include "linear_buffer_import.h"

static bool readExpectedWithGles(AHardwareBuffer* buffer,uint32_t width,uint32_t height,const uint8_t* expected) {
    bool ok=false;
    EGLDisplay display=eglGetDisplay(EGL_DEFAULT_DISPLAY);
    EGLContext context=EGL_NO_CONTEXT;
    EGLSurface surface=EGL_NO_SURFACE;
    EGLImageKHR image=EGL_NO_IMAGE_KHR;
    GLuint texture=0, fbo=0;
    PFNEGLCREATEIMAGEKHRPROC createImage=(void*)eglGetProcAddress("eglCreateImageKHR");
    PFNEGLDESTROYIMAGEKHRPROC destroyImage=(void*)eglGetProcAddress("eglDestroyImageKHR");
    PFNEGLGETNATIVECLIENTBUFFERANDROIDPROC nativeBuffer=(void*)eglGetProcAddress("eglGetNativeClientBufferANDROID");
    PFNGLEGLIMAGETARGETTEXTURE2DOESPROC targetImage=(void*)eglGetProcAddress("glEGLImageTargetTexture2DOES");
    if (!createImage || !destroyImage || !nativeBuffer || !targetImage || display==EGL_NO_DISPLAY) return false;
    if (!eglInitialize(display,NULL,NULL)) return false;
    EGLConfig config; EGLint count=0;
    EGLint attrs[]={EGL_RENDERABLE_TYPE,EGL_OPENGL_ES3_BIT,EGL_SURFACE_TYPE,EGL_PBUFFER_BIT,
            EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_ALPHA_SIZE,8,EGL_NONE};
    if (!eglChooseConfig(display,attrs,&config,1,&count) || !count) goto done;
    EGLint ctxAttrs[]={EGL_CONTEXT_CLIENT_VERSION,3,EGL_NONE};
    context=eglCreateContext(display,config,EGL_NO_CONTEXT,ctxAttrs);
    EGLint surfaceAttrs[]={EGL_WIDTH,1,EGL_HEIGHT,1,EGL_NONE};
    surface=eglCreatePbufferSurface(display,config,surfaceAttrs);
    if (context==EGL_NO_CONTEXT || surface==EGL_NO_SURFACE || !eglMakeCurrent(display,surface,surface,context)) goto done;
    EGLint imageAttrs[]={EGL_IMAGE_PRESERVED_KHR,EGL_TRUE,EGL_NONE};
    image=createImage(display,EGL_NO_CONTEXT,EGL_NATIVE_BUFFER_ANDROID,nativeBuffer(buffer),imageAttrs);
    if (image==EGL_NO_IMAGE_KHR) goto done;
    glGenTextures(1,&texture); glBindTexture(GL_TEXTURE_2D,texture);
    targetImage(GL_TEXTURE_2D,image);
    glGenFramebuffers(1,&fbo); glBindFramebuffer(GL_FRAMEBUFFER,fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,texture,0);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE) goto done;
    ok=true;
    uint32_t xs[3]={0,width/2,width-1},ys[3]={0,height/2,height-1};
    for(unsigned y=0;y<3;y++)for(unsigned x=0;x<3;x++) {
        unsigned char pixel[4]={0};
        glReadPixels(xs[x],ys[y],1,1,GL_RGBA,GL_UNSIGNED_BYTE,pixel);
        ok=ok && glGetError()==GL_NO_ERROR && abs(pixel[0]-expected[0])<=1 &&
            abs(pixel[1]-expected[1])<=1 && abs(pixel[2]-expected[2])<=1 && pixel[3]==255;
    }

done:
    if (fbo) glDeleteFramebuffers(1,&fbo);
    if (texture) glDeleteTextures(1,&texture);
    if (image!=EGL_NO_IMAGE_KHR) destroyImage(display,image);
    eglMakeCurrent(display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);
    if (surface!=EGL_NO_SURFACE) eglDestroySurface(display,surface);
    if (context!=EGL_NO_CONTEXT) eglDestroyContext(display,context);
    eglTerminate(display); eglReleaseThread();
    return ok;
}

/* Real Vulkan -> AHardwareBuffer -> system GLES interoperability. A version
 * string or vkCreateDevice alone cannot establish that the game can display. */
bool probeVulkanInterop(VkDevice device, uint32_t queueFamily, PFN_vkGetDeviceProcAddr getProc) {
#define FN(name) PFN_##name name=(PFN_##name)getProc(device,#name); if(!name) return false
    FN(vkGetAndroidHardwareBufferPropertiesANDROID); FN(vkCreateImage); FN(vkDestroyImage);
    FN(vkAllocateMemory); FN(vkFreeMemory); FN(vkBindImageMemory); FN(vkCreateCommandPool);
    FN(vkDestroyCommandPool); FN(vkAllocateCommandBuffers); FN(vkBeginCommandBuffer);
    FN(vkEndCommandBuffer); FN(vkCmdPipelineBarrier); FN(vkCmdClearColorImage);
    FN(vkGetDeviceQueue); FN(vkQueueSubmit); FN(vkCreateFence); FN(vkDestroyFence);
    FN(vkWaitForFences); FN(vkDeviceWaitIdle);
#undef FN
    bool ok=false, submitted=false;
    AHardwareBuffer* buffer=NULL;
    VkImage image=VK_NULL_HANDLE; VkDeviceMemory memory=VK_NULL_HANDLE;
    VkCommandPool pool=VK_NULL_HANDLE; VkFence fence=VK_NULL_HANDLE;
    AHardwareBuffer_Desc desc={.width=16,.height=16,.layers=1,
            .format=AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM,
            .usage=AHARDWAREBUFFER_USAGE_GPU_COLOR_OUTPUT|AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE};
    if (AHardwareBuffer_allocate(&desc,&buffer)!=0) goto done;
    VkAndroidHardwareBufferFormatPropertiesANDROID format={.sType=VK_STRUCTURE_TYPE_ANDROID_HARDWARE_BUFFER_FORMAT_PROPERTIES_ANDROID};
    VkAndroidHardwareBufferPropertiesANDROID properties={.sType=VK_STRUCTURE_TYPE_ANDROID_HARDWARE_BUFFER_PROPERTIES_ANDROID,.pNext=&format};
    if (vkGetAndroidHardwareBufferPropertiesANDROID(device,buffer,&properties)!=VK_SUCCESS ||
            format.format!=VK_FORMAT_R8G8B8A8_UNORM || !properties.memoryTypeBits) goto done;
    VkExternalMemoryImageCreateInfo external={.sType=VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_IMAGE_CREATE_INFO,
            .handleTypes=VK_EXTERNAL_MEMORY_HANDLE_TYPE_ANDROID_HARDWARE_BUFFER_BIT_ANDROID};
    VkImageCreateInfo imageInfo={.sType=VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,.pNext=&external,
            .imageType=VK_IMAGE_TYPE_2D,.format=format.format,.extent={16,16,1},.mipLevels=1,.arrayLayers=1,
            .samples=VK_SAMPLE_COUNT_1_BIT,.tiling=VK_IMAGE_TILING_OPTIMAL,
            .usage=VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT|VK_IMAGE_USAGE_SAMPLED_BIT|VK_IMAGE_USAGE_TRANSFER_DST_BIT,
            .sharingMode=VK_SHARING_MODE_EXCLUSIVE,.initialLayout=VK_IMAGE_LAYOUT_UNDEFINED};
    if(vkCreateImage(device,&imageInfo,NULL,&image)!=VK_SUCCESS)goto done;
    VkImportAndroidHardwareBufferInfoANDROID import={.sType=VK_STRUCTURE_TYPE_IMPORT_ANDROID_HARDWARE_BUFFER_INFO_ANDROID,.buffer=buffer};
    VkMemoryDedicatedAllocateInfo dedicated={.sType=VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO,.pNext=&import,.image=image};
    VkMemoryAllocateInfo allocate={.sType=VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,.pNext=&dedicated,
            .allocationSize=properties.allocationSize,.memoryTypeIndex=__builtin_ctz(properties.memoryTypeBits)};
    if(vkAllocateMemory(device,&allocate,NULL,&memory)!=VK_SUCCESS || vkBindImageMemory(device,image,memory,0)!=VK_SUCCESS)goto done;
    VkCommandPoolCreateInfo poolInfo={.sType=VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,.queueFamilyIndex=queueFamily};
    if(vkCreateCommandPool(device,&poolInfo,NULL,&pool)!=VK_SUCCESS)goto done;
    VkCommandBuffer command;
    VkCommandBufferAllocateInfo commandInfo={.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
            .commandPool=pool,.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY,.commandBufferCount=1};
    if(vkAllocateCommandBuffers(device,&commandInfo,&command)!=VK_SUCCESS)goto done;
    VkCommandBufferBeginInfo begin={.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,.flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT};
    if(vkBeginCommandBuffer(command,&begin)!=VK_SUCCESS)goto done;
    VkImageSubresourceRange range={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
    VkImageMemoryBarrier barrier={.sType=VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,.dstAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT,
            .oldLayout=VK_IMAGE_LAYOUT_UNDEFINED,.newLayout=VK_IMAGE_LAYOUT_GENERAL,
            .srcQueueFamilyIndex=VK_QUEUE_FAMILY_FOREIGN_EXT,.dstQueueFamilyIndex=queueFamily,.image=image,.subresourceRange=range};
    vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,0,NULL,0,NULL,1,&barrier);
    VkClearColorValue colour={.float32={.25f,.5f,.75f,1.f}};
    vkCmdClearColorImage(command,image,VK_IMAGE_LAYOUT_GENERAL,&colour,1,&range);
    barrier.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT; barrier.dstAccessMask=0;
    barrier.oldLayout=VK_IMAGE_LAYOUT_GENERAL; barrier.srcQueueFamilyIndex=queueFamily;
    barrier.dstQueueFamilyIndex=VK_QUEUE_FAMILY_FOREIGN_EXT;
    vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,0,0,NULL,0,NULL,1,&barrier);
    if(vkEndCommandBuffer(command)!=VK_SUCCESS)goto done;
    VkFenceCreateInfo fenceInfo={.sType=VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    if(vkCreateFence(device,&fenceInfo,NULL,&fence)!=VK_SUCCESS)goto done;
    VkQueue queue;vkGetDeviceQueue(device,queueFamily,0,&queue);
    VkSubmitInfo submit={.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO,.commandBufferCount=1,.pCommandBuffers=&command};
    if(vkQueueSubmit(queue,1,&submit,fence)!=VK_SUCCESS)goto done;
    submitted=true;
    if(vkWaitForFences(device,1,&fence,VK_TRUE,2000000000ULL)!=VK_SUCCESS)goto done;
    submitted=false;
    const uint8_t expected[3]={64,128,191};
    ok=readExpectedWithGles(buffer,16,16,expected);
done:
    // The parent kills this dedicated probe process if a broken driver wedges.
    if(submitted)vkDeviceWaitIdle(device);
    if(fence)vkDestroyFence(device,fence,NULL);
    if(pool)vkDestroyCommandPool(device,pool,NULL);
    if(image)vkDestroyImage(device,image,NULL);
    if(memory)vkFreeMemory(device,memory,NULL);
    if(buffer)AHardwareBuffer_release(buffer);
    return ok;
}

#define DLOG(...) __android_log_print(ANDROID_LOG_INFO,"WrathRTInterop",__VA_ARGS__)
static bool dmaInteropCase(VkPhysicalDevice physical,VkDevice device,uint32_t family,
        PFN_vkGetInstanceProcAddr gip,VkInstance instance,PFN_vkGetDeviceProcAddr gdp,
        GetAhbHandle getHandle,uint32_t width,uint32_t height,uint32_t androidFormat,VkFormat format) {
    bool ok=false,submitted=false;
    FreshLinearBuffer b={.fd=-1};
    VkImage image=VK_NULL_HANDLE;VkDeviceMemory memory=VK_NULL_HANDLE;
    VkCommandPool pool=VK_NULL_HANDLE;VkFence fence=VK_NULL_HANDLE;
    VkImageView view=VK_NULL_HANDLE;VkRenderPass pass=VK_NULL_HANDLE;VkFramebuffer framebuffer=VK_NULL_HANDLE;
#define FN(name) PFN_##name name=(void*)gdp(device,#name);if(!name){DLOG("MISSING %s",#name);return false;}
    FN(vkCreateImage);FN(vkDestroyImage);FN(vkGetImageMemoryRequirements);
    FN(vkGetMemoryFdPropertiesKHR);FN(vkAllocateMemory);FN(vkFreeMemory);FN(vkBindImageMemory);
    FN(vkCreateCommandPool);FN(vkDestroyCommandPool);FN(vkAllocateCommandBuffers);FN(vkResetCommandPool);
    FN(vkBeginCommandBuffer);FN(vkEndCommandBuffer);FN(vkCmdPipelineBarrier);FN(vkCmdClearColorImage);
    FN(vkCreateFence);FN(vkDestroyFence);FN(vkWaitForFences);FN(vkDeviceWaitIdle);FN(vkResetFences);
    FN(vkGetDeviceQueue);FN(vkQueueSubmit);
    FN(vkCreateImageView);FN(vkDestroyImageView);FN(vkCreateRenderPass);FN(vkDestroyRenderPass);
    FN(vkCreateFramebuffer);FN(vkDestroyFramebuffer);FN(vkCmdBeginRenderPass);FN(vkCmdEndRenderPass);
#undef FN
#define NEED(x) do{if(!(x)){DLOG("CASE_FAIL line=%d %s",__LINE__,#x);goto done;}}while(0)
#define VKCHECK(x) do{VkResult result=(x);if(result!=VK_SUCCESS){DLOG("CASE_FAIL line=%d %s result=%d",__LINE__,#x,result);goto done;}}while(0)
    NEED(freshLinearBufferCreate(width,height,androidFormat,getHandle,&b));
    bool srgb=format==VK_FORMAT_R8G8B8A8_SRGB || format==VK_FORMAT_B8G8R8A8_SRGB;
    LinearBufferDispatch dispatch={
        .getImageProperties=(void*)gip(instance,"vkGetPhysicalDeviceImageFormatProperties2"),
        .createImage=vkCreateImage,.destroyImage=vkDestroyImage,.getImageRequirements=vkGetImageMemoryRequirements,
        .getFdProperties=vkGetMemoryFdPropertiesKHR,.allocateMemory=vkAllocateMemory,.freeMemory=vkFreeMemory,
        .bindImageMemory=vkBindImageMemory};
    LinearBufferLayout layout={.fd=b.fd,.bytes=b.bytes,.width=b.width,.height=b.height,
        .rowPitch=b.pitch,.androidFormat=b.format};
    VKCHECK(importLinearBufferImage(&dispatch,physical,device,&layout,format,
        VK_IMAGE_USAGE_TRANSFER_DST_BIT|VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT|VK_IMAGE_USAGE_SAMPLED_BIT,
        0,&image,&memory));
    VkImageViewCreateInfo vi={.sType=VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,.image=image,
        .viewType=VK_IMAGE_VIEW_TYPE_2D,.format=format,.subresourceRange={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1}};
    VKCHECK(vkCreateImageView(device,&vi,NULL,&view));
    VkAttachmentDescription attachment={.format=format,.samples=VK_SAMPLE_COUNT_1_BIT,
        .loadOp=VK_ATTACHMENT_LOAD_OP_CLEAR,.storeOp=VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp=VK_ATTACHMENT_LOAD_OP_DONT_CARE,.stencilStoreOp=VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout=VK_IMAGE_LAYOUT_GENERAL,.finalLayout=VK_IMAGE_LAYOUT_GENERAL};
    VkAttachmentReference reference={.attachment=0,.layout=VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkSubpassDescription subpass={.pipelineBindPoint=VK_PIPELINE_BIND_POINT_GRAPHICS,
        .colorAttachmentCount=1,.pColorAttachments=&reference};
    VkRenderPassCreateInfo pi={.sType=VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO,
        .attachmentCount=1,.pAttachments=&attachment,.subpassCount=1,.pSubpasses=&subpass};
    VKCHECK(vkCreateRenderPass(device,&pi,NULL,&pass));
    VkFramebufferCreateInfo fi={.sType=VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO,
        .renderPass=pass,.attachmentCount=1,.pAttachments=&view,.width=width,.height=height,.layers=1};
    VKCHECK(vkCreateFramebuffer(device,&fi,NULL,&framebuffer));
    VkCommandPoolCreateInfo poolInfo={.sType=VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,.queueFamilyIndex=family};
    VKCHECK(vkCreateCommandPool(device,&poolInfo,NULL,&pool));
    VkCommandBuffer command;
    VkCommandBufferAllocateInfo commandInfo={.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
        .commandPool=pool,.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY,.commandBufferCount=1};
    VKCHECK(vkAllocateCommandBuffers(device,&commandInfo,&command));
    VkCommandBufferBeginInfo begin={.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
        .flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT};
    VkFenceCreateInfo fenceInfo={.sType=VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    VKCHECK(vkCreateFence(device,&fenceInfo,NULL,&fence));
    VkQueue queue;vkGetDeviceQueue(device,family,0,&queue);
    VkSubmitInfo submit={.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO,.commandBufferCount=1,.pCommandBuffers=&command};
    for(unsigned frame=0;frame<2;frame++) {
    if(frame) {
        VKCHECK(vkResetFences(device,1,&fence));
        VKCHECK(vkResetCommandPool(device,pool,0));
    }
    VKCHECK(vkBeginCommandBuffer(command,&begin));
    bool attachmentFrame=(frame&1)!=0;
    VkAccessFlags writes=attachmentFrame?VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT:VK_ACCESS_TRANSFER_WRITE_BIT;
    VkPipelineStageFlags writer=attachmentFrame?VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT:VK_PIPELINE_STAGE_TRANSFER_BIT;
    VkImageSubresourceRange range={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
    VkImageMemoryBarrier barrier={.sType=VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
        .dstAccessMask=writes,.oldLayout=frame?VK_IMAGE_LAYOUT_GENERAL:VK_IMAGE_LAYOUT_UNDEFINED,
        .newLayout=VK_IMAGE_LAYOUT_GENERAL,.srcQueueFamilyIndex=VK_QUEUE_FAMILY_FOREIGN_EXT,
        .dstQueueFamilyIndex=family,.image=image,.subresourceRange=range};
    vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,writer,0,0,NULL,0,NULL,1,&barrier);
    uint8_t expected[3]={(frame*17+31)&255,(frame*47+113)&255,(frame*73+199)&255};
    /* Endpoint values are invariant under sRGB encoding/decoding. This checks
     * channel/layout/ownership of the game's sRGB formats, not gamma accuracy. */
    if(srgb)for(unsigned channel=0;channel<3;channel++)expected[channel]=(frame&(1u<<channel))?255:0;
    VkClearColorValue color={.float32={expected[0]/255.f,expected[1]/255.f,expected[2]/255.f,1.f}};
    if(attachmentFrame) {
        VkClearValue clear={.color=color};
        VkRenderPassBeginInfo bi={.sType=VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,.renderPass=pass,
            .framebuffer=framebuffer,.renderArea={{0,0},{width,height}},.clearValueCount=1,.pClearValues=&clear};
        vkCmdBeginRenderPass(command,&bi,VK_SUBPASS_CONTENTS_INLINE);vkCmdEndRenderPass(command);
    } else vkCmdClearColorImage(command,image,VK_IMAGE_LAYOUT_GENERAL,&color,1,&range);
    barrier.srcAccessMask=writes;barrier.dstAccessMask=0;
    barrier.oldLayout=VK_IMAGE_LAYOUT_GENERAL;barrier.srcQueueFamilyIndex=family;barrier.dstQueueFamilyIndex=VK_QUEUE_FAMILY_FOREIGN_EXT;
    vkCmdPipelineBarrier(command,writer,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,0,0,NULL,0,NULL,1,&barrier);
    VKCHECK(vkEndCommandBuffer(command));
    VKCHECK(vkQueueSubmit(queue,1,&submit,fence));submitted=true;
    VKCHECK(vkWaitForFences(device,1,&fence,VK_TRUE,2000000000ULL));submitted=false;
    /* glReadPixels completes the GLES reads before the next FOREIGN acquire.
     * Diagnostic synchronization, not an implementation of the app presenter. */
    if(!readExpectedWithGles(b.buffer,width,height,expected)) {
        DLOG("REUSE_FAIL frame=%u",frame);goto done;
    }
    }
    ok=true;
done:
    if(submitted)vkDeviceWaitIdle(device); /* owned service watchdog covers a broken driver */
    if(fence)vkDestroyFence(device,fence,NULL);
    if(pool)vkDestroyCommandPool(device,pool,NULL);
    if(framebuffer)vkDestroyFramebuffer(device,framebuffer,NULL);
    if(pass)vkDestroyRenderPass(device,pass,NULL);
    if(view)vkDestroyImageView(device,view,NULL);
    if(image)vkDestroyImage(device,image,NULL);
    if(memory)vkFreeMemory(device,memory,NULL);
    freshLinearBufferDestroy(&b);
    DLOG("DMA_INTEROP %s width=%u height=%u androidFormat=%u vkFormat=%u transferFrames=1 attachmentFrames=1",ok?"PASS":"FAIL",width,height,androidFormat,format);
    return ok;
#undef NEED
#undef VKCHECK
}

bool probeLinearVulkanInterop(VkPhysicalDevice physical,VkDevice device,uint32_t family,
        PFN_vkGetInstanceProcAddr gip,VkInstance instance,PFN_vkGetDeviceProcAddr gdp) {
    GetAhbHandle getHandle=(void*)dlsym(RTLD_DEFAULT,"AHardwareBuffer_getNativeHandle");
    if(!getHandle)return false;
    const VkFormat formats[]={VK_FORMAT_R8G8B8A8_UNORM,VK_FORMAT_B8G8R8A8_UNORM,
        VK_FORMAT_R8G8B8A8_SRGB,VK_FORMAT_B8G8R8A8_SRGB};
    for(unsigned i=0;i<4;i++)if(!dmaInteropCase(physical,device,family,gip,instance,gdp,
        getHandle,17,9,(i&1)?5:1,formats[i]))return false;
    return true;
}
