#include "xwindow_swapchain.h"
#include "vulkan_helper.h"

void reportSwapchainStartup(JMethods* methods, int stage, VkResult result,
        VkFormat format, VkExtent2D extent, int windowId) {
    // Do not disturb a Java allocation exception already propagating to the
    // caller. No paths, messages or per-frame logging cross this callback.
    if (!methods->recordSwapchainStartup || (*methods->env)->ExceptionCheck(methods->env)) return;
    (*methods->env)->CallVoidMethod(methods->env, methods->obj, methods->recordSwapchainStartup,
            stage, (int)result, (int)format, (int)extent.width, (int)extent.height, windowId);
    // Only an exception raised by this diagnostic callback is discarded.
    // The early guard above preserves any original renderer exception.
    if ((*methods->env)->ExceptionCheck(methods->env)) (*methods->env)->ExceptionClear(methods->env);
}

static VkResult failedSwapchainStep(XWindowSwapchain* swapchain, int stage, VkResult result) {
    reportSwapchainStartup(swapchain->jmethods, stage, result,
            swapchain->imageFormat, swapchain->imageExtent, swapchain->windowId);
    return result;
}

void getWindowExtent(JMethods* jmethods, int windowId, VkExtent2D* extent) {
    extent->width = (*jmethods->env)->CallIntMethod(jmethods->env, jmethods->obj, jmethods->getWindowWidth, windowId);
    extent->height = (*jmethods->env)->CallIntMethod(jmethods->env, jmethods->obj, jmethods->getWindowHeight, windowId);
}

static AHardwareBuffer* getWindowHardwareBuffer(JMethods* jmethods, int windowId, jboolean useHALPixelFormatBGRA8888) {
    jlong hardwareBufferPtr = (*jmethods->env)->CallLongMethod(jmethods->env, jmethods->obj, jmethods->getWindowHardwareBuffer, windowId, useHALPixelFormatBGRA8888);
    return (AHardwareBuffer*)hardwareBufferPtr;
}

static VkResult createImageMemory(VkDevice device, XWindowSwapchain* swapchain, VkImage image, AHardwareBuffer* hardwareBuffer, VkDeviceMemory* pMemory) {
    VkAndroidHardwareBufferPropertiesANDROID ahbProperties = {0};
    ahbProperties.sType = VK_STRUCTURE_TYPE_ANDROID_HARDWARE_BUFFER_PROPERTIES_ANDROID;
    VkResult result = vulkanWrapper.vkGetAndroidHardwareBufferPropertiesANDROID(device, hardwareBuffer, &ahbProperties);
    if (result != VK_SUCCESS) return failedSwapchainStep(swapchain, SWAPCHAIN_AHB_PROPERTIES, result);

    VkImportAndroidHardwareBufferInfoANDROID memoryImportInfo = {0};
    memoryImportInfo.sType = VK_STRUCTURE_TYPE_IMPORT_ANDROID_HARDWARE_BUFFER_INFO_ANDROID;
    memoryImportInfo.buffer = hardwareBuffer;

    VkMemoryDedicatedAllocateInfo memoryDedicatedInfo = {0};
    memoryDedicatedInfo.sType = VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO;
    memoryDedicatedInfo.pNext = &memoryImportInfo;
    memoryDedicatedInfo.image = image;
    memoryDedicatedInfo.buffer = VK_NULL_HANDLE;

    VkMemoryAllocateInfo memoryInfo = {0};
    memoryInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    memoryInfo.pNext = &memoryDedicatedInfo;
    memoryInfo.allocationSize = ahbProperties.allocationSize;
    memoryInfo.memoryTypeIndex = getMemoryTypeIndex(ahbProperties.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    // Device-local memory is preferred, but an imported AHB may only allow
    // another type. Never fall back to an index absent from the import mask.
    if (memoryInfo.memoryTypeIndex == UINT32_MAX)
        memoryInfo.memoryTypeIndex = getMemoryTypeIndex(ahbProperties.memoryTypeBits, 0);
    if (memoryInfo.memoryTypeIndex == UINT32_MAX) return failedSwapchainStep(swapchain, SWAPCHAIN_MEMORY_TYPE, VK_ERROR_OUT_OF_DEVICE_MEMORY);

    VkDeviceMemory memory;
    result = vulkanWrapper.vkAllocateMemory(device, &memoryInfo, NULL, &memory);
    if (result != VK_SUCCESS) return failedSwapchainStep(swapchain, SWAPCHAIN_MEMORY_ALLOCATE, result);

    result = vulkanWrapper.vkBindImageMemory(device, image, memory, 0);
    if (result != VK_SUCCESS) {
        vulkanWrapper.vkFreeMemory(device, memory, NULL);
        return failedSwapchainStep(swapchain, SWAPCHAIN_MEMORY_BIND, result);
    }

    *pMemory = memory;
    return VK_SUCCESS;
}

static VkResult createImage(VkDevice device, XWindowSwapchain* swapchain, XWindowSwapchain_Image* swapchainImage) {
    jboolean useHALPixelFormatBGRA8888 = swapchain->imageFormat == VK_FORMAT_B8G8R8A8_UNORM || swapchain->imageFormat == VK_FORMAT_B8G8R8A8_SRGB;
    AHardwareBuffer* hardwareBuffer = getWindowHardwareBuffer(swapchain->jmethods, swapchain->windowId, useHALPixelFormatBGRA8888);
    if (!hardwareBuffer) return failedSwapchainStep(swapchain, SWAPCHAIN_AHB, VK_ERROR_OUT_OF_HOST_MEMORY);

    AHardwareBuffer_Desc ahbDesc = {0};
    AHardwareBuffer_describe(hardwareBuffer, &ahbDesc);

    VkExternalFormatANDROID externalFormatAndroid = {0};
    externalFormatAndroid.sType = VK_STRUCTURE_TYPE_EXTERNAL_FORMAT_ANDROID;
    externalFormatAndroid.externalFormat = 0;

    VkExternalMemoryImageCreateInfo externalMemoryImageInfo = {0};
    externalMemoryImageInfo.sType = VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_IMAGE_CREATE_INFO;
    externalMemoryImageInfo.pNext = &externalFormatAndroid;
    externalMemoryImageInfo.handleTypes = VK_EXTERNAL_MEMORY_HANDLE_TYPE_ANDROID_HARDWARE_BUFFER_BIT_ANDROID;

    VkImageCreateInfo imageInfo = {0};
    imageInfo.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    imageInfo.pNext = &externalMemoryImageInfo;
    imageInfo.flags = VK_IMAGE_CREATE_ALIAS_BIT;
    imageInfo.imageType = VK_IMAGE_TYPE_2D;
    imageInfo.format = swapchain->imageFormat;
    imageInfo.extent.width = ahbDesc.width;
    imageInfo.extent.height = ahbDesc.height;
    imageInfo.extent.depth = 1;
    imageInfo.mipLevels = 1;
    imageInfo.arrayLayers = 1;
    imageInfo.samples = VK_SAMPLE_COUNT_1_BIT;
    imageInfo.tiling = VK_IMAGE_TILING_OPTIMAL;
    imageInfo.usage = swapchain->imageUsage;
    imageInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    imageInfo.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;

    VkImage image;
    VkDeviceMemory memory;
    VkResult result;

    result = vulkanWrapper.vkCreateImage(device, &imageInfo, NULL, &image);
    if (result != VK_SUCCESS) return failedSwapchainStep(swapchain, SWAPCHAIN_IMAGE, result);

    result = createImageMemory(device, swapchain, image, hardwareBuffer, &memory);
    if (result != VK_SUCCESS) {
        vulkanWrapper.vkDestroyImage(device, image, NULL);
        return result;
    }

    swapchainImage->image = image;
    swapchainImage->memory = memory;
    return VK_SUCCESS;
}

int getSurfaceMinImageCount() {
    return 1;
}

VkSurfaceFormatKHR* getSurfaceFormats(uint32_t* formatCount) {
    static const VkFormat supportedFormats[] = {VK_FORMAT_B8G8R8A8_UNORM, VK_FORMAT_B8G8R8A8_SRGB, VK_FORMAT_R8G8B8A8_UNORM, VK_FORMAT_R8G8B8A8_SRGB};
    int supportedFormatCount = ARRAY_SIZE(supportedFormats);
    VkSurfaceFormatKHR* surfaceFormats = calloc(supportedFormatCount, sizeof(VkSurfaceFormatKHR));

    if (formatCount) *formatCount = supportedFormatCount;

    for (int i = 0; i < supportedFormatCount; i++) {
        surfaceFormats[i].format = supportedFormats[i];
        surfaceFormats[i].colorSpace = VK_COLOR_SPACE_SRGB_NONLINEAR_KHR;
    }

    return surfaceFormats;
}

XWindowSwapchain* XWindowSwapchain_create(VkDevice device, uint32_t graphicsQueueIndex, VkSwapchainCreateInfoKHR* swapchainInfo, JMethods* jmethods, int windowId) {
    XWindowSwapchain* swapchain = calloc(1, sizeof(XWindowSwapchain));
    swapchain->device = device;
    swapchain->windowId = windowId;
    swapchain->imageCount = swapchainInfo->minImageCount;
    swapchain->images = calloc(swapchain->imageCount, sizeof(XWindowSwapchain_Image));
    swapchain->imageFormat = swapchainInfo->imageFormat;
    swapchain->imageUsage = swapchainInfo->imageUsage;
    memcpy(&swapchain->imageExtent, &swapchainInfo->imageExtent, sizeof(VkExtent2D));
    swapchain->jmethods = jmethods;

    VkResult result;
    for (int i = 0; i < swapchain->imageCount; i++) {
        result = createImage(device, swapchain, &swapchain->images[i]);
        if (result != VK_SUCCESS) goto error;
    }

    vulkanWrapper.vkGetDeviceQueue(device, graphicsQueueIndex, 0, &swapchain->queue);
    reportSwapchainStartup(jmethods, SWAPCHAIN_READY, VK_SUCCESS,
            swapchain->imageFormat, swapchain->imageExtent, windowId);
    return swapchain;

error:
    XWindowSwapchain_destroy(device, swapchain);
    return NULL;
}

void XWindowSwapchain_destroy(VkDevice device, XWindowSwapchain* swapchain) {
    if (!swapchain) return;
    // A relay timeout/host allocation error is not proof of hardware device
    // loss. Terminal contexts retain all pending objects until process exit.
    if (swapchain->presentFencePending) return;
    if (swapchain->presentFence) vulkanWrapper.vkDestroyFence(device, swapchain->presentFence, NULL);
    for (int i = 0; i < swapchain->imageCount; i++) {
        vulkanWrapper.vkDestroyImage(device, swapchain->images[i].image, NULL);
        vulkanWrapper.vkFreeMemory(device, swapchain->images[i].memory, NULL);
    }

    MEMFREE(swapchain->images);
    MEMFREE(swapchain);
}

VkResult XWindowSwapchain_acquireNextImage(XWindowSwapchain* swapchain, uint64_t timeout, VkSemaphore signalSemaphore, VkFence fence, uint32_t* imageIndex) {
    if (signalSemaphore || fence) {
        VkSubmitInfo submitInfo = {0};
        submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
        if (signalSemaphore) {
            submitInfo.pSignalSemaphores = &signalSemaphore;
            submitInfo.signalSemaphoreCount = 1;
        }

        VkResult result = vulkanWrapper.vkQueueSubmit(swapchain->queue, 1, &submitInfo, fence);
        if (result != VK_SUCCESS) {
            // A failed submit did not signal the acquire semaphore/fence.
            // Reporting success lets the client wait forever for that signal.
            // Keep the image index untouched and propagate the exact VkResult.
            if (!swapchain->acquireFailureReported) {
                swapchain->acquireFailureReported = true;
                failedSwapchainStep(swapchain, SWAPCHAIN_ACQUIRE_SUBMIT, result);
            }
            return result;
        }
    }

    VkExtent2D windowSize;
    getWindowExtent(swapchain->jmethods, swapchain->windowId, &windowSize);

    VkResult result = VK_SUCCESS;
    if (swapchain->imageExtent.width != windowSize.width || swapchain->imageExtent.height != windowSize.height) {
        result = VK_ERROR_SURFACE_LOST_KHR;
    }

    *imageIndex = 0;
    return result;
}

static VkResult failedPresentStep(XWindowSwapchain* swapchain, int stage, VkResult result) {
    if (!swapchain->presentFailureReported) {
        swapchain->presentFailureReported = true;
        failedSwapchainStep(swapchain, stage, result);
    }
    return result;
}

VkResult XWindowSwapchain_waitForPresent(VkQueue queue, const VkPresentInfoKHR* presentInfo,
        const _Atomic VkResult* contextStatus) {
    if (!queue || !presentInfo->swapchainCount || !presentInfo->pSwapchains ||
            !presentInfo->pImageIndices || (presentInfo->waitSemaphoreCount && !presentInfo->pWaitSemaphores))
        return VK_ERROR_INITIALIZATION_FAILED;
    XWindowSwapchain* first = (XWindowSwapchain*)presentInfo->pSwapchains[0];
    if (!first) return VK_ERROR_INITIALIZATION_FAILED;
    // All images currently alias the window's one AHB; acquire only returns0.
    // Validate every entry before consuming semaphores or publishing any window.
    for (uint32_t i=0; i<presentInfo->swapchainCount; ++i) {
        XWindowSwapchain* swapchain = (XWindowSwapchain*)presentInfo->pSwapchains[i];
        if (!swapchain || swapchain->device != first->device || !swapchain->imageCount ||
                presentInfo->pImageIndices[i] != 0)
            return failedPresentStep(first, SWAPCHAIN_PRESENT_INDEX, VK_ERROR_OUT_OF_DATE_KHR);
    }
    if (*contextStatus < 0 || first->presentFencePending) return VK_ERROR_DEVICE_LOST;
    VkResult result;
    if (!first->presentFence) {
        VkFenceCreateInfo info = { .sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO };
        result = vulkanWrapper.vkCreateFence(first->device, &info, NULL, &first->presentFence);
    } else result = vulkanWrapper.vkResetFences(first->device, 1, &first->presentFence);
    if (result != VK_SUCCESS) return failedPresentStep(first, SWAPCHAIN_PRESENT_FENCE, result);

    VkPipelineStageFlags* stages = presentInfo->waitSemaphoreCount ?
            calloc(presentInfo->waitSemaphoreCount, sizeof(*stages)) : NULL;
    if (presentInfo->waitSemaphoreCount && !stages) return VK_ERROR_OUT_OF_HOST_MEMORY;
    for (uint32_t i=0; i<presentInfo->waitSemaphoreCount; ++i) stages[i] = VK_PIPELINE_STAGE_ALL_COMMANDS_BIT;
    VkSubmitInfo submit = { .sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
        .waitSemaphoreCount = presentInfo->waitSemaphoreCount,
        .pWaitSemaphores = presentInfo->pWaitSemaphores, .pWaitDstStageMask = stages };
    // Consume each binary render-finished semaphore exactly once for the entire
    // present batch. Otherwise its next signal is invalid (VUID00067).
    // The context's single request thread also owns all normal queue submits.
    result = vulkanWrapper.vkQueueSubmit(queue, 1, &submit, first->presentFence);
    free(stages);
    if (result != VK_SUCCESS) return failedPresentStep(first, SWAPCHAIN_PRESENT_SUBMIT, result);
    first->presentFencePending = true;
    // GLES cannot import this VkFence. Publish only after the submitted waits
    // complete, without draining unrelated later work with QueueWaitIdle.
    // Fifty-ms slices let session shutdown interrupt a never-signalled present;
    // a five-second watchdog retires this virtual device instead of hanging it.
    for (unsigned slice=0; slice<100; ++slice) {
        if (*contextStatus < 0) return VK_ERROR_DEVICE_LOST;
        result = vulkanWrapper.vkWaitForFences(first->device, 1, &first->presentFence, VK_TRUE, 50000000ULL);
        if (result == VK_SUCCESS) { first->presentFencePending=false; return VK_SUCCESS; }
        if (result != VK_TIMEOUT) return failedPresentStep(first, SWAPCHAIN_PRESENT_WAIT, result);
    }
    // A pending fence is retained until normal swapchain/device teardown. Never
    // reset/free it while its submission can still be in flight. The distinct
    // stage identifies our watchdog, not a driver-returned DEVICE_LOST.
    return failedPresentStep(first, SWAPCHAIN_PRESENT_TIMEOUT, VK_ERROR_DEVICE_LOST);
}

void XWindowSwapchain_presentImage(XWindowSwapchain* swapchain) {
    if (!swapchain->firstPresentReported) {
        swapchain->firstPresentReported = true;
        reportSwapchainStartup(swapchain->jmethods, SWAPCHAIN_FIRST_PRESENT, VK_SUCCESS,
                swapchain->imageFormat, swapchain->imageExtent, swapchain->windowId);
    }
    (*swapchain->jmethods->env)->CallVoidMethod(swapchain->jmethods->env, swapchain->jmethods->obj,
                                                swapchain->jmethods->updateWindowContent, swapchain->windowId);
}
