"""Compile changed canonical host units with the Android release toolchain."""
from pathlib import Path
import json, subprocess
ROOT=Path(__file__).resolve().parents[2]
CPP=ROOT/'apk-source/app/src/main/cpp'
OUT=ROOT/'testovanie/154/vortek-present/host-build';OUT.mkdir(exist_ok=True)
NDK=ROOT/'build-tools/sdk/ndk/24.0.8215888/toolchains/llvm/prebuilt/windows-x86_64'
compiler=NDK/'bin/clang.exe'
flags=['--target=aarch64-none-linux-android31','--sysroot='+str(NDK/'sysroot'),'-std=gnu11','-DANDROID',
       '-DVK_USE_PLATFORM_ANDROID_KHR','-D_FORTIFY_SOURCE=2','-Wformat','-Werror=format-security',
       '-Werror=implicit-function-declaration','-O2','-fPIC','-ffunction-sections','-fdata-sections']
flags+=['-I'+str(CPP/p) for p in ['vortekrenderer/include','winlator/include','libadrenotools/include']]
rows=[]
for name in ['xwindow_swapchain.c','request_handler.c','vk_context.c']:
    command=[str(compiler)]+flags+['-c',str(CPP/'vortekrenderer/src'/name),'-o',str(OUT/(name+'.o'))]
    run=subprocess.run(command,capture_output=True,text=True)
    (OUT/(name+'.log')).write_text(run.stdout+run.stderr)
    rows.append({'source':name,'exitCode':run.returncode,'command':command})
    if run.returncode:print(run.stderr);run.check_returncode()
    print('PASS Android compile '+name)
(OUT/'manifest.json').write_text(json.dumps({'status':'PASS','units':rows},indent=2)+'\n')
