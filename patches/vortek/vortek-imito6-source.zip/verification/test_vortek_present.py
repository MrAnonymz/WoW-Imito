"""Actual Vortek host/guest presentation sequence against a deterministic Vulkan driver.

No APK, phone, GPU or network. --baseline substitutes the saved old host handler
and must fail: it publishes unfinished pixels and never consumes binary waits.
"""
from pathlib import Path
import argparse
import os
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HOST = ROOT / 'apk-source/app/src/main/cpp/vortekrenderer'
GUEST = ROOT / 'build-tools/compat-native/vortek-source/brunodev85-vortek-b1730c5'
OUT = ROOT / 'testovanie/154/vortek-present'
OUT.mkdir(parents=True, exist_ok=True)

def function(text, name):
    match = re.search(r'^(?:static\s+)?[A-Za-z_][A-Za-z0-9_* \t]*\b' + name + r'\(', text, re.M)
    if not match:
        raise ValueError(name)
    begin = match.start(); end = text.index('{', begin)+1; depth = 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}'); end += 1
    return text[begin:end]

parser = argparse.ArgumentParser()
parser.add_argument('--baseline', action='store_true')
args = parser.parse_args()
header = (HOST / 'include/xwindow_swapchain.h').read_text('utf-8')
structs = header[header.index('typedef struct XWindowSwapchain_Image'):header.index('/* Bounded startup evidence')]
enums = header[header.index('enum SwapchainStartupStage'):header.index('extern void reportSwapchainStartup')]
swap = (HOST / 'src/xwindow_swapchain.c').read_text('utf-8')
host = (HOST / 'src/request_handler.c').read_text('utf-8')
guest = (GUEST / 'src/vulkan_calls.c').read_text('utf-8')
codes = '\n'.join(re.findall(r'^#define REQUEST_CODE_[^\r\n]+', (HOST/'include/request_codes.h').read_text(), re.M))
assert codes == '\n'.join(re.findall(r'^#define REQUEST_CODE_[^\r\n]+', (GUEST/'include/request_codes.h').read_text(), re.M))
dispatch = re.search(r'(?:static )?HandleRequestFunc handleRequestFuncs\[\] = \{.*?\n\};', host, re.S).group(0)
names = re.findall(r'\bvt_handle_\w+', dispatch)
assert len(names) == 256 and names[255] == 'vt_handle_vkQueuePresentKHRNative'
assert names[354-100] == 'vt_handle_vkWaitForFencesNative'
native = function(host, 'vt_handle_vkQueuePresentKHRNative')
if args.baseline:
    native = (OUT/'vt_handle_vkQueuePresentKHR-old.c').read_text('utf-8').replace(
        'vt_handle_vkQueuePresentKHR(', 'vt_handle_vkQueuePresentKHRNative(')
code = r'''
#define VK_NO_PROTOTYPES 1
#include "vulkan/vulkan_core.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {int unused;} JMethods;
''' + structs + enums + codes + r'''
typedef struct {char* inputBuffer; int memoryPool; _Atomic VkResult status; bool gpuWorkRetired; void* clientRing;} VkContext;
typedef struct {uint64_t id;} VkObject;
typedef struct {VkQueue queue; VkPresentInfoKHR present;} Input;
static VkContext context;
static Input input;
static VkObject queueObject={(uint64_t)0x29};
static XWindowSwapchain swaps[2];
static VkSwapchainKHR handles[2];
static uint32_t indices[2];
static VkSemaphore waits[2];
static VkResult results[2],wireResult;
static int checks,locked,submits,publishes,premature,replies,failed,waitCalls,creates,resets;
static int signalReuse,signaled[256],pendingWork,pendingWaits[256],pendingWaitCount;
static int completeAfter=1,cancelAfter,sendFail,wireCode,recordedStage,records;
static VkQueue lastQueue;
static VkResult createResult,resetResult,submitResult,waitResult;
#define CHECK(x) do {checks++;if(!(x)){fprintf(stderr,"FAIL %d line %d: %s [publish=%d premature=%d waits=%d reuse=%d]\n",checks,__LINE__,#x,publishes,premature,waitCalls,signalReuse);return 1;}}while(0)
static int sid(VkSemaphore s){return (int)(uintptr_t)s;}
static VkResult VKAPI_PTR driverSubmit(VkQueue q,uint32_t count,const VkSubmitInfo* s,VkFence fence){
    submits++;lastQueue=q;
    if(submitResult!=VK_SUCCESS)return submitResult;
    if(count!=1 || s->sType!=VK_STRUCTURE_TYPE_SUBMIT_INFO || s->commandBufferCount)abort();
    for(uint32_t i=0;i<s->waitSemaphoreCount;i++){
        int id=sid(s->pWaitSemaphores[i]);
        if(!signaled[id] || s->pWaitDstStageMask[i]!=VK_PIPELINE_STAGE_ALL_COMMANDS_BIT)abort();
        if(fence)pendingWaits[pendingWaitCount++]=id;
        else signaled[id]=0;
    }
    for(uint32_t i=0;i<s->signalSemaphoreCount;i++){
        int id=sid(s->pSignalSemaphores[i]);
        if(signaled[id]){signalReuse++;return VK_ERROR_DEVICE_LOST;}
        signaled[id]=1;
    }
    return VK_SUCCESS;
}
static VkResult VKAPI_PTR driverCreate(VkDevice d,const VkFenceCreateInfo* i,const VkAllocationCallbacks* a,VkFence* f){
    creates++;if(d!=(VkDevice)(uintptr_t)0x11 || i->flags || i->sType!=VK_STRUCTURE_TYPE_FENCE_CREATE_INFO)abort();
    if(createResult==VK_SUCCESS)*f=(VkFence)(uintptr_t)(0x80+creates);return createResult;
}
static VkResult VKAPI_PTR driverReset(VkDevice d,uint32_t count,const VkFence* f){
    resets++;if(pendingWaitCount)abort();return resetResult;
}
static VkResult VKAPI_PTR driverWait(VkDevice d,uint32_t count,const VkFence* f,VkBool32 all,uint64_t ns){
    waitCalls++;if(count!=1 || !all || ns!=50000000ULL)abort();
    if(cancelAfter && waitCalls>=cancelAfter)context.status=VK_ERROR_DEVICE_LOST;
    if(waitResult!=VK_SUCCESS)return waitResult;
    if(waitCalls<completeAfter)return VK_TIMEOUT;
    for(int i=0;i<pendingWaitCount;i++)signaled[pendingWaits[i]]=0;
    pendingWaitCount=0;pendingWork=0;return VK_SUCCESS;
}
static struct {PFN_vkQueueSubmit vkQueueSubmit; PFN_vkCreateFence vkCreateFence;
    PFN_vkResetFences vkResetFences; PFN_vkWaitForFences vkWaitForFences;} vulkanWrapper={driverSubmit,driverCreate,driverReset,driverWait};
static void reportSwapchainStartup(JMethods* j,int stage,VkResult result,VkFormat f,VkExtent2D e,int id){records++;recordedStage=stage;}
static void getWindowExtent(JMethods* j,int id,VkExtent2D* e){*e=(VkExtent2D){1280,720};}
''' + '\n'.join(function(swap,n) for n in ('failedSwapchainStep','failedPresentStep','XWindowSwapchain_waitForPresent','XWindowSwapchain_acquireNextImage')) + r'''
static void XWindowSwapchain_presentImage(XWindowSwapchain* s){
    publishes++;if(pendingWork || pendingWaitCount)premature++;
}
static void* VkObject_fromId(uint64_t id){return (void*)(uintptr_t)id;}
static VkObject* VkObject_fromHandle(VkQueue q){if(q!=(VkQueue)(uintptr_t)0x29)abort();return &queueObject;}
static void vt_unserialize_VkPresentInfoKHR(VkPresentInfoKHR* p,char* b,int* pool){*p=((Input*)b)->present;}
static void vt_unserialize_vkQueuePresentKHR(VkQueue q,const VkPresentInfoKHR* p,char* b,int* pool){
    *(uint64_t*)q=(uintptr_t)((Input*)b)->queue;*(VkPresentInfoKHR*)p=((Input*)b)->present;
}
static void hostSend(void* ring,int result,void* bytes,int size){wireResult=result;replies++;}
static void failVkContext(VkContext* c,VkResult r){c->status=r;failed++;}
#define vt_send hostSend
''' + function(host,'prepareWindowPresent') + '\n' + function(host,'vt_handle_vkQueuePresentKHR') + '\n' + native + r'''
#undef vt_send
static int guestSend(void* ring,int code,void* bytes,int size){
    if(sendFail)return 0;
    wireCode=code;context.inputBuffer=(char*)&input;
    if(code==REQUEST_CODE_VK_QUEUE_PRESENT_KHR_NATIVE)vt_handle_vkQueuePresentKHRNative(&context);
    else abort();
    return size;
}
static int vt_recv(void* ring,char** bytes,void* size,int* pool){return wireResult;}
static void* serverRing;static void* clientRing;static int globalMemoryPool;
#define VT_CALL_LOCK() do {if(locked)abort();locked++;}while(0)
#define VT_CALL_UNLOCK() do {if(locked!=1)abort();locked--;}while(0)
#define VT_SERIALIZE_CMD(name,q,p) input.queue=(VkQueue)(uintptr_t)(*(uint64_t*)q);input.present=*(p);int bufferSize=sizeof(Input);char* outputBuffer=(char*)&input
#define vt_send guestSend
''' + function(guest,'vt_call_vkQueuePresentKHR') + r'''
#undef vt_send
static void fresh(void){
    memset(&context,0,sizeof(context));memset(swaps,0,sizeof(swaps));memset(signaled,0,sizeof(signaled));
    for(int i=0;i<2;i++){
        swaps[i].device=(VkDevice)(uintptr_t)0x11;swaps[i].queue=(VkQueue)(uintptr_t)0x21;
        swaps[i].windowId=91+i;swaps[i].imageCount=3;swaps[i].imageExtent=(VkExtent2D){1280,720};
        handles[i]=(VkSwapchainKHR)&swaps[i];indices[i]=0;waits[i]=(VkSemaphore)(uintptr_t)(0x31+i);results[i]=VK_INCOMPLETE;
    }
    submits=publishes=premature=replies=failed=waitCalls=creates=resets=signalReuse=pendingWork=pendingWaitCount=0;
    cancelAfter=sendFail=records=recordedStage=0;completeAfter=1;lastQueue=VK_NULL_HANDLE;
    createResult=resetResult=submitResult=waitResult=VK_SUCCESS;wireResult=VK_INCOMPLETE;
    input=(Input){.queue=(VkQueue)(uintptr_t)0x29,.present={.sType=VK_STRUCTURE_TYPE_PRESENT_INFO_KHR,
        .swapchainCount=1,.pSwapchains=handles,.pImageIndices=indices,.waitSemaphoreCount=1,.pWaitSemaphores=waits,.pResults=results}};
}
static VkResult render(void){
    VkSemaphore acquire=(VkSemaphore)(uintptr_t)0x41;uint32_t index=123;
    VkResult r=XWindowSwapchain_acquireNextImage(&swaps[0],UINT64_MAX,acquire,VK_NULL_HANDLE,&index);
    if(r!=VK_SUCCESS || index!=0)return r;
    VkPipelineStageFlags stage=VK_PIPELINE_STAGE_ALL_COMMANDS_BIT;
    VkSubmitInfo s={.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO,.waitSemaphoreCount=1,.pWaitSemaphores=&acquire,
        .pWaitDstStageMask=&stage,.signalSemaphoreCount=1,.pSignalSemaphores=waits};
    r=driverSubmit((VkQueue)(uintptr_t)0x29,1,&s,VK_NULL_HANDLE);if(r==VK_SUCCESS)pendingWork=1;return r;
}
static VkResult present(void){VkPresentInfoKHR p=input.present;return vt_call_vkQueuePresentKHR((VkQueue)(uintptr_t)0x29,&p);}
int main(void){
    fresh();completeAfter=3;
    CHECK(render()==VK_SUCCESS);CHECK(present()==VK_SUCCESS);
    CHECK(publishes==1 && premature==0 && waitCalls==3 && !signaled[0x31] && replies==1);
    CHECK(lastQueue==(VkQueue)(uintptr_t)0x29 && wireCode==REQUEST_CODE_VK_QUEUE_PRESENT_KHR_NATIVE && !locked);
    for(int i=0;i<12;i++){CHECK(render()==VK_SUCCESS);CHECK(present()==VK_SUCCESS);}
    CHECK(publishes==13 && !signalReuse && creates==1 && resets==12 && results[0]==VK_SUCCESS);
    fresh();input.present.swapchainCount=2;input.present.waitSemaphoreCount=2;signaled[0x31]=signaled[0x32]=1;pendingWork=1;
    CHECK(present()==VK_SUCCESS && publishes==2 && submits==1 && !premature && !signaled[0x31] && !signaled[0x32]);
    CHECK(results[0]==VK_SUCCESS && results[1]==VK_SUCCESS);
    fresh();input.present.swapchainCount=2;indices[1]=1;signaled[0x31]=1;
    CHECK(present()==VK_ERROR_OUT_OF_DATE_KHR && !publishes && !submits && signaled[0x31]);
    CHECK(results[0]==VK_ERROR_OUT_OF_DATE_KHR && results[1]==VK_ERROR_OUT_OF_DATE_KHR && recordedStage==SWAPCHAIN_PRESENT_INDEX);
    fresh();input.present.waitSemaphoreCount=0;input.present.pWaitSemaphores=NULL;pendingWork=1;
    CHECK(present()==VK_SUCCESS && publishes==1 && submits==1 && waitCalls==1 && !premature);
    VkResult errors[]={VK_ERROR_OUT_OF_HOST_MEMORY,VK_ERROR_OUT_OF_DEVICE_MEMORY,VK_ERROR_DEVICE_LOST,VK_ERROR_UNKNOWN};
    for(unsigned i=0;i<sizeof(errors)/sizeof(*errors);i++){
        fresh();signaled[0x31]=1;submitResult=errors[i];CHECK(present()==errors[i]);
        CHECK(!publishes && !waitCalls && signaled[0x31] && results[0]==errors[i] && !locked);
        CHECK(recordedStage==SWAPCHAIN_PRESENT_SUBMIT);
        fresh();signaled[0x31]=1;waitResult=errors[i];CHECK(present()==errors[i]);
        CHECK(!publishes && waitCalls==1 && swaps[0].presentFencePending && results[0]==errors[i]);
        CHECK(context.gpuWorkRetired && failed==1);
    }
    fresh();signaled[0x31]=1;createResult=VK_ERROR_OUT_OF_HOST_MEMORY;
    CHECK(present()==createResult && !submits && !publishes && recordedStage==SWAPCHAIN_PRESENT_FENCE);
    fresh();signaled[0x31]=1;waitResult=VK_TIMEOUT;cancelAfter=2;
    CHECK(present()==VK_ERROR_DEVICE_LOST && waitCalls==2 && !publishes && failed==1 && swaps[0].presentFencePending);
    fresh();signaled[0x31]=1;waitResult=VK_TIMEOUT;
    CHECK(present()==VK_ERROR_DEVICE_LOST && waitCalls==100 && !publishes && failed==1);
    CHECK(recordedStage==SWAPCHAIN_PRESENT_TIMEOUT && results[0]==VK_ERROR_DEVICE_LOST);
    int oldSubmits=submits;CHECK(present()==VK_ERROR_DEVICE_LOST && submits==oldSubmits && resets==0);
    fresh();sendFail=1;CHECK(present()==VK_ERROR_DEVICE_LOST && !submits && !replies && !locked && results[0]==VK_ERROR_DEVICE_LOST);
    fresh();signaled[0x31]=1;context.inputBuffer=(char*)&input;vt_handle_vkQueuePresentKHR(&context);
    CHECK(publishes==1 && !premature && !replies && !signaled[0x31] && lastQueue==(VkQueue)(uintptr_t)0x21);
    fresh();input.present.swapchainCount=0;CHECK(present()==VK_ERROR_INITIALIZATION_FAILED && !submits && !publishes);
    fresh();input.present.swapchainCount=2;swaps[1].device=(VkDevice)(uintptr_t)0x12;
    CHECK(present()==VK_ERROR_OUT_OF_DATE_KHR && !submits && !publishes);
    printf("PASS %d actual host/guest presentation checks; repeated binary signals, delayed GPU, actual queue, multi-window, failures, cancellation, watchdog, legacy wire\n",checks);
    return 0;
}
'''
if args.baseline:
    code = code.replace('    fresh();completeAfter=3;', '''
    fresh();CHECK(render()==VK_SUCCESS);context.inputBuffer=(char*)&input;
    vt_handle_vkQueuePresentKHRNative(&context);
    VkResult second=render();
    fprintf(stderr,"OLD actual handler: firstPublish=%d unfinished=%d semaphoreWaits=%d secondRender=%d invalidResignal=%d\\n",publishes,premature,waitCalls,second,signalReuse);
    CHECK(second==VK_SUCCESS && !premature && !signalReuse);
    fresh();completeAfter=3;''')
name = 'present-old' if args.baseline else 'present-fixed'
c = OUT/(name+'.c'); binary = OUT/(name+'.exe')
c.write_text(code, encoding='utf-8')
zig = ROOT.parent/'NFSU2-Coop/tools/native-toolchain/zig-x86_64-windows-0.15.2/zig.exe'
env = os.environ.copy()
env['ZIG_GLOBAL_CACHE_DIR'] = str(ROOT/'build-tools/compat-native/zig-cache')
env['ZIG_LOCAL_CACHE_DIR'] = env['ZIG_GLOBAL_CACHE_DIR']
env['TEMP'] = env['TMP'] = str(OUT)
subprocess.run([str(zig),'cc','-std=c11','-O0','-I'+str(HOST/'include'),str(c),'-o',str(binary)], env=env, check=True)
subprocess.run([str(binary)], env=env, check=True)
