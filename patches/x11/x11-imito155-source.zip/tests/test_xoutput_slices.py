"""Execute production methods from this archive with controlled boundaries.
No historical baseline or operator workspace is required.
"""
from pathlib import Path
import argparse
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
args = parser.parse_args()
args.baseline = False
base = 'source'
source = root / base / 'app/src/main/java/com/winlator/xconnector/XOutputStream.java'
import os
import shutil
def java_tool(name):
    suffix = '.exe' if os.name == 'nt' else ''
    configured = os.environ.get('JAVA_HOME')
    candidate = Path(configured) / 'bin' / (name + suffix) if configured else None
    result = str(candidate) if candidate and candidate.is_file() else shutil.which(name)
    if not result:
        raise RuntimeError('Set JAVA_HOME or put JDK17 java/javac on PATH')
    return result
text = source.read_text('utf-8')
replacements = {
    'import dalvik.annotation.optimization.CriticalNative;': '',
    '@CriticalNative': '',
    'System.loadLibrary("winlator");': '',
    'private native long nativeAllocate(int fd, int initialCapacity);':
        'private long nativeAllocate(int fd, int initialCapacity) { return NativeWrites.allocation; }',
    'private static native void writeByte(long nativePtr, byte value);':
        'private static void writeByte(long nativePtr, byte value) { NativeWrites.bytes.write(value); }',
    'private static native void writeByteBuffer(long nativePtr, ByteBuffer data, int offset, int length);':
        '''private static void writeByteBuffer(long nativePtr, ByteBuffer data, int offset, int length) {
            NativeWrites.directCalls++;
            for (int i=offset; i<offset+length; i++) NativeWrites.bytes.write(data.get(i));
        }''',
}
for old, new in replacements.items():
    if old not in text:
        raise AssertionError('JNI boundary no longer matches: ' + old)
    text = text.replace(old, new)

files = {
    'com/winlator/xconnector/XOutputStream.java': text,
    'com/winlator/xconnector/XStreamLock.java':
        (root / 'source/app/src/main/java/com/winlator/xconnector/XStreamLock.java').read_text('utf-8'),
    'com/winlator/xserver/XServer.java': '''package com.winlator.xserver;
        public final class XServer {
            public static final java.nio.charset.Charset LATIN1_CHARSET = java.nio.charset.StandardCharsets.ISO_8859_1;
        }''',
    'com/winlator/xconnector/XOutputSlicesTest.java': r'''package com.winlator.xconnector;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;

final class NativeWrites {
    static final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    static long allocation = 1;
    static int directCalls;
}
public final class XOutputSlicesTest {
    static int checks, failures;
    static void check(boolean value, String name) {
        checks++;
        if (!value) { failures++; if (failures<=6) System.err.println("FAIL: " + name); }
    }
    static void expect(byte[] value, String name) {
        check(Arrays.equals(NativeWrites.bytes.toByteArray(), value), name);
        NativeWrites.bytes.reset();
    }
    static void invalid(XOutputStream out, byte[] data, int offset, int count) {
        boolean rejected = false;
        try { out.write(data, offset, count); }
        catch (IndexOutOfBoundsException expected) { rejected = true; }
        check(rejected, "reject invalid slice " + offset + "/" + count);
        expect(new byte[0], "invalid slice emits no partial reply");
    }
    static void buffer(XOutputStream out, ByteBuffer data, String label) {
        byte[] expected = new byte[data.remaining()];
        data.duplicate().get(expected);
        int position = data.position(), limit = data.limit();
        data.mark();
        out.write(data);
        expect(expected, label + " payload");
        check(data.position()==position && data.limit()==limit, label + " position/limit unchanged");
        data.reset();
        check(data.position()==position, label + " mark retained");
    }
    public static void main(String[] args) {
        XOutputStream out = new XOutputStream(7, 64);
        byte[] data = new byte[16];
        for (int i=0; i<data.length; i++) data[i]=(byte)(i+32);

        // WindowRequests.getProperty advertises this count after longOffset*4.
        // The next X message must begin after all eight advertised payload bytes.
        byte[] header = {1,8,0,0}, nextMessage = {99,98};
        out.write(header); out.write(data,4,8); out.write(nextMessage);
        expect(new byte[]{1,8,0,0,36,37,38,39,40,41,42,43,99,98},
                "GetProperty offset4/count8 preserves the next X message boundary");
        out.write(data,12,4);
        expect(new byte[]{44,45,46,47}, "offset greater than count still emits the payload");
        for (int offset=0; offset<=data.length; offset++) {
            for (int count=0; count<=data.length-offset; count++) {
                out.write(data,offset,count);
                expect(Arrays.copyOfRange(data,offset,offset+count), "array slice " + offset + "/" + count);
            }
        }
        invalid(out,data,-1,2); invalid(out,data,1,-1); invalid(out,data,15,2);
        invalid(out,data,17,0); invalid(out,data,Integer.MAX_VALUE,2);
        invalid(out,data,1,Integer.MAX_VALUE);
        out.write(data); expect(data,"complete array writes remain unchanged");

        ByteBuffer heap = ByteBuffer.wrap(data); heap.position(4); heap.limit(12);
        buffer(out,heap,"heap nonzero position");
        heap.position(9); heap.limit(12);
        buffer(out,heap,"heap position exceeds remaining");
        ByteBuffer slice = ByteBuffer.wrap(data); slice.position(3); slice.limit(14); slice=slice.slice();
        slice.position(2); slice.limit(9);
        buffer(out,slice,"heap slice with array offset");
        buffer(out,slice.asReadOnlyBuffer(),"read-only heap slice");
        slice.position(slice.limit()); buffer(out,slice,"empty heap slice");
        ByteBuffer direct = ByteBuffer.allocateDirect(16); direct.put(data); direct.position(5); direct.limit(13);
        buffer(out,direct,"direct JNI slice");
        buffer(out,direct.asReadOnlyBuffer(),"read-only direct JNI slice");
        check(NativeWrites.directCalls==2,"direct buffers retain their JNI bulk path");

        NativeWrites.allocation=0;
        boolean failed=false;
        try { new XOutputStream(7,64); }
        catch (IllegalStateException expected) { failed=true; }
        check(failed,"native allocation failure never exposes a zero native pointer");
        if (failures>0) throw new AssertionError(failures + " of " + checks + " checks failed");
        System.out.println("PASS: " + checks + " actual XOutputStream slice, framing, buffer-state and allocation checks");
    }
}''',
}
with tempfile.TemporaryDirectory(prefix='xoutput-slices-', dir=root/'tests') as temporary:
    output = Path(temporary)
    sources = []
    for name, content in files.items():
        path = output/name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
        sources.append(path)
    subprocess.run([java_tool('javac'), '-encoding', 'UTF-8', '-d', str(output),
                    *map(str,sources)], check=True)
    result = subprocess.run([java_tool('java'), '-cp', str(output),
                             'com.winlator.xconnector.XOutputSlicesTest'])
    if args.baseline:
        if result.returncode == 0:
            raise AssertionError('Retained baseline unexpectedly passed')
        print('REPRODUCED: retained public XOutputStream corrupts nonzero-offset output slices')
    else:
        result.check_returncode()
