#include <sys/eventfd.h>
#include <time.h>
#include <errno.h>

#include "timeline_semaphore.h"
#include "vortek_serializer.h"
#include "string_utils.h"
#include "vulkan_helper.h"
#include "vk_context.h"

typedef struct WaitSemaphoresRequest {
    VkContext* context;
    int notifyFd;
    char* inputBuffer;
} WaitSemaphoresRequest;

static void waitSemaphoresThread(void* param) {
    WaitSemaphoresRequest* waitSemaphoresRequest = param;

    uint64_t deviceId;
    VkSemaphoreWaitInfo waitInfo = {0};
    uint64_t timeout;

    MemoryPool memoryPool = {0};
    vt_unserialize_vkWaitSemaphores((VkDevice)&deviceId, &waitInfo, &timeout, waitSemaphoresRequest->inputBuffer, &memoryPool);
    VkDevice device = VkObject_fromId(deviceId);

    // Bound shutdown even if a guest requested UINT64_MAX and never signals.
    // Blocking in the driver consumes no polling CPU; texture/compiler workers
    // are independent of these waits.
    struct timespec started, current;
    clock_gettime(CLOCK_MONOTONIC, &started);
    uint64_t elapsed = 0;
    VkResult result;
    do {
        if (waitSemaphoresRequest->context->status < 0) {result=VK_ERROR_DEVICE_LOST;break;}
        uint64_t remaining=timeout>elapsed?timeout-elapsed:0;
        uint64_t slice=remaining<50000000ULL?remaining:50000000ULL;
        result=vulkanWrapper.vkWaitSemaphores(device,&waitInfo,slice);
        if(result!=VK_TIMEOUT)break;
        clock_gettime(CLOCK_MONOTONIC,&current);
        elapsed=(uint64_t)(current.tv_sec-started.tv_sec)*1000000000ULL+current.tv_nsec-started.tv_nsec;
    } while(elapsed<timeout);

    // Keep existing success/device-lost/unknown wire values. A finite wait
    // expiring is a normal VkResult, not an unspecified device failure.
    uint64_t value = result == VK_SUCCESS ? 1 :
            (result == VK_ERROR_DEVICE_LOST ? 2 : (result == VK_TIMEOUT ? 4 : 3));
    write(waitSemaphoresRequest->notifyFd, &value, sizeof(uint64_t));
    CLOSEFD(waitSemaphoresRequest->notifyFd);

    vt_free(&memoryPool);
    MEMFREE(waitSemaphoresRequest->inputBuffer);
    MEMFREE(waitSemaphoresRequest);
}

void TimelineSemaphore_asyncWait(VkContext* context, char* inputBuffer, int inputBufferSize) {
    WaitSemaphoresRequest* waitSemaphoresRequest = calloc(1, sizeof(WaitSemaphoresRequest));
    if (!waitSemaphoresRequest) {failVkContext(context,VK_ERROR_OUT_OF_HOST_MEMORY);return;}
    waitSemaphoresRequest->context=context;
    waitSemaphoresRequest->inputBuffer = memdup(inputBuffer, inputBufferSize);
    if (!waitSemaphoresRequest->inputBuffer) {free(waitSemaphoresRequest);failVkContext(context,VK_ERROR_OUT_OF_HOST_MEMORY);return;}

    int fd = eventfd(0, EFD_CLOEXEC);
    if (fd<0) {free(waitSemaphoresRequest->inputBuffer);free(waitSemaphoresRequest);failVkContext(context,VK_ERROR_OUT_OF_HOST_MEMORY);return;}
    waitSemaphoresRequest->notifyFd = fd;

    if (send_fds(context->clientFd, &fd, 1, NULL, 0)<0) {
        close(fd);free(waitSemaphoresRequest->inputBuffer);free(waitSemaphoresRequest);failVkContext(context,VK_ERROR_DEVICE_LOST);return;
    }
    ThreadPool_run(context->waitThreadPool, waitSemaphoresThread, waitSemaphoresRequest);
}

typedef struct WaitFencesRequest {
    VkContext* context;
    int notifyFd;
    char* inputBuffer;
} WaitFencesRequest;

static void waitFencesThread(void* param) {
    WaitFencesRequest* request = param;
    uint64_t deviceId, timeout;
    uint32_t fenceCount;
    VkBool32 waitAll;
    MemoryPool memoryPool = {0};
    vt_unserialize_vkWaitForFences((VkDevice)&deviceId, &fenceCount, NULL,
            &waitAll, &timeout, request->inputBuffer, &memoryPool);
    VkDevice device = VkObject_fromId(deviceId);
    VkResult result = VK_ERROR_OUT_OF_HOST_MEMORY;
    VkFence* fences = fenceCount ? calloc(fenceCount, sizeof(VkFence)) : NULL;
    if (fences) {
        vt_unserialize_vkWaitForFences(VK_NULL_HANDLE, NULL, fences,
                NULL, NULL, request->inputBuffer, &memoryPool);
        struct timespec started, current;
        clock_gettime(CLOCK_MONOTONIC, &started);
        uint64_t elapsed = 0;
        do {
            if (request->context->status < 0) {result = VK_ERROR_DEVICE_LOST;break;}
            uint64_t remaining = timeout > elapsed ? timeout - elapsed : 0;
            uint64_t slice = remaining < 50000000ULL ? remaining : 50000000ULL;
            // Preserve nanoseconds and waitAll. Exporting a SYNC_FD instead
            // would consume the original fence's signal payload (and -1 is a
            // valid already-signalled export, not a transferable descriptor).
            result = vulkanWrapper.vkWaitForFences(device, fenceCount, fences, waitAll, slice);
            if (result != VK_TIMEOUT) break;
            clock_gettime(CLOCK_MONOTONIC, &current);
            elapsed = (uint64_t)(current.tv_sec - started.tv_sec) * 1000000000ULL
                    + current.tv_nsec - started.tv_nsec;
        } while (elapsed < timeout);
        free(fences);
    }

    // Dedicated opcode: preserve every signed 32-bit VkResult, including
    // ordinary VK_TIMEOUT. +1 keeps SUCCESS away from eventfd's zero value.
    uint64_t value = (uint64_t)(uint32_t)result + 1;
    ssize_t written;
    do {written = write(request->notifyFd, &value, sizeof(value));}
    while (written < 0 && errno == EINTR);
    CLOSEFD(request->notifyFd);
    if (written != sizeof(value)) failVkContext(request->context, VK_ERROR_DEVICE_LOST);
    vt_free(&memoryPool);
    MEMFREE(request->inputBuffer);
    MEMFREE(request);
}

void NativeFence_asyncWait(VkContext* context, char* inputBuffer, int inputBufferSize) {
    WaitFencesRequest* request = calloc(1, sizeof(WaitFencesRequest));
    if (!request) {failVkContext(context, VK_ERROR_OUT_OF_HOST_MEMORY);return;}
    request->context = context;
    request->inputBuffer = memdup(inputBuffer, inputBufferSize);
    if (!request->inputBuffer) {free(request);failVkContext(context, VK_ERROR_OUT_OF_HOST_MEMORY);return;}
    int fd = eventfd(0, EFD_CLOEXEC);
    if (fd < 0) {free(request->inputBuffer);free(request);failVkContext(context, VK_ERROR_OUT_OF_HOST_MEMORY);return;}
    request->notifyFd = fd;
    // Send before queuing the native wait so the guest can release its call
    // lock; another guest thread may need to submit the work being waited for.
    if (send_fds(context->clientFd, &fd, 1, NULL, 0) != 1) {
        close(fd);free(request->inputBuffer);free(request);failVkContext(context, VK_ERROR_DEVICE_LOST);return;
    }
    ThreadPool_run(context->waitThreadPool, waitFencesThread, request);
}
