#ifndef VORTEK_SWAPCHAIN_LAYOUT_H
#define VORTEK_SWAPCHAIN_LAYOUT_H

/* Vortek's guest owns a virtual swapchain. The Android host imports ordinary
 * AHardwareBuffer-backed VkImages with vkCreateImage; it never obtains these
 * images from the native driver's vkGetSwapchainImagesKHR. Native PRESENT is
 * therefore not their layout. Keep the wire protocol unchanged and translate
 * both directions of guest layout transitions, including render-pass initial
 * and final layouts, to GENERAL at the host deserialization boundary. */
static inline VkImageLayout vt_nativeImageLayout(VkImageLayout layout) {
    return layout == VK_IMAGE_LAYOUT_PRESENT_SRC_KHR ? VK_IMAGE_LAYOUT_GENERAL : layout;
}

#endif
