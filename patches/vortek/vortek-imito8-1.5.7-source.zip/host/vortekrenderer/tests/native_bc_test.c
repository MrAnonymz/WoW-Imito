#include <stddef.h>
#include <stdbool.h>
#include "../include/vulkan/vulkan_core.h"
#define DECOMPRESSED_FORMAT VK_FORMAT_B8G8R8A8_UNORM
typedef struct { short imageCacheSize; void* threadPool; uint32_t nativeBCFormats; } TextureDecoder;
typedef struct { short imageCacheSize; void* threadPool; VkDriverId driverID; } VkContext;
static TextureDecoder storage;
static void* calloc(size_t n, size_t size) {
    unsigned char* p = (unsigned char*)&storage;
    if (n * size != sizeof(storage)) return NULL;
    for (size_t i = 0; i < sizeof(storage); i++) p[i] = 0;
    return p;
}
static VkFormatFeatureFlags advertised[12];
static unsigned queries;
static void VKAPI_CALL formats(VkPhysicalDevice device, VkFormat format, VkFormatProperties* out) {
    queries++;
    out->optimalTilingFeatures = advertised[format - VK_FORMAT_BC1_RGB_UNORM_BLOCK];
}
static struct { PFN_vkGetPhysicalDeviceFormatProperties vkGetPhysicalDeviceFormatProperties; }
    vulkanWrapper = { formats };
/* These functions are extracted from the current production C, not reimplemented. */
#include "native_bc_actual.inc"
__declspec(dllimport) void __stdcall ExitProcess(unsigned int exit_code);
void mainCRTStartup(void) {
    unsigned failures = 0;
    VkContext ctx = {0};
    VkPhysicalDeviceFeatures features = {0};
    ctx.driverID = VK_DRIVER_ID_SAMSUNG_PROPRIETARY;
    /* Exact format capability flags captured from the user's S26. */
    for (int i = 0; i < 12; i++) advertised[i] = i < 8 ? 54273 : 0;
    TextureDecoder* d = TextureDecoder_create(&ctx, VK_NULL_HANDLE, &features);
    if (!d || d->nativeBCFormats != 255 || queries != 12) failures++;
    for (int f = 131; f <= 142; f++)
        if (TextureDecoder_needsDecode(d, f) != (f >= 139)) failures++;
    if (TextureDecoder_needsDecode(d, VK_FORMAT_R8G8B8A8_UNORM)) failures++;
    if (!TextureDecoder_needsDecode(d, VK_FORMAT_ASTC_12x12_SRGB_BLOCK)) failures++;
    /* A partially advertised format must retain its decoder fallback. */
    const VkFormatFeatureFlags bits[] = {VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT,
        VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT,
        VK_FORMAT_FEATURE_TRANSFER_SRC_BIT, VK_FORMAT_FEATURE_TRANSFER_DST_BIT};
    for (int i = 0; i < 4; i++) {
        advertised[0] = 54273 & ~bits[i];
        d = TextureDecoder_create(&ctx, VK_NULL_HANDLE, &features);
        if (!TextureDecoder_needsDecode(d, VK_FORMAT_BC1_RGB_UNORM_BLOCK)) failures++;
    }
    advertised[0] = 54273;
    VkDriverId other[] = {VK_DRIVER_ID_ARM_PROPRIETARY, VK_DRIVER_ID_QUALCOMM_PROPRIETARY};
    for (int i = 0; i < 2; i++) {
        ctx.driverID = other[i]; queries = 0;
        d = TextureDecoder_create(&ctx, VK_NULL_HANDLE, &features);
        if (!d || queries != 12 || d->nativeBCFormats != 255 || TextureDecoder_needsDecode(d, VK_FORMAT_BC3_UNORM_BLOCK)) failures++;
    }
    ctx.driverID = VK_DRIVER_ID_SAMSUNG_PROPRIETARY;
    features.textureCompressionBC = VK_TRUE; queries = 0;
    if (TextureDecoder_create(&ctx, VK_NULL_HANDLE, &features) || queries) failures++;
    ExitProcess(failures);
}
