"""Run isolated real Android AF_UNIX tests; explicit device selection required."""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--ndk', type=Path, required=True)
parser.add_argument('--adb', default=shutil.which('adb'))
parser.add_argument('--serial', required=True)
args = parser.parse_args()
if not args.adb:
    parser.error('Supply --adb or put adb on PATH')
host = 'windows-x86_64' if os.name == 'nt' else ('darwin-x86_64' if sys.platform == 'darwin' else 'linux-x86_64')
suffix = '.cmd' if os.name == 'nt' else ''
compiler = args.ndk / 'toolchains/llvm/prebuilt' / host / 'bin' / ('aarch64-linux-android31-clang' + suffix)
if not compiler.is_file():
    parser.error('Android NDK ARM64 API31 compiler not found')
adb = [args.adb, '-s', args.serial]
remote = '/data/local/tmp/imito-xoutput-queue-fixture'
with tempfile.TemporaryDirectory(prefix='xoutput-queue-', dir=HERE) as temporary:
    binary = Path(temporary) / 'test'
    subprocess.run([str(compiler), '-std=gnu11', '-O1', '-Wall', '-Wextra',
                    '-Wno-unused-parameter', '-pthread', '-DWRATHRT_DIAGNOSTICS=0',
                    '-I' + str(ROOT / 'source/app/src/main/cpp/winlator/include'),
                    '-I' + str(ROOT / 'source/app/src/main/cpp/winlator/src'),
                    str(HERE / 'xoutput-queue-fixture.c'), '-o', str(binary)], check=True)
    try:
        subprocess.run(adb + ['push', str(binary), remote], check=True)
        subprocess.run(adb + ['shell', 'chmod', '700', remote], check=True)
        subprocess.run(adb + ['shell', remote], check=True, timeout=30)
    finally:
        subprocess.run(adb + ['shell', 'rm', '-f', remote], check=True)
