"""Execute production methods from this archive with controlled boundaries.
No historical baseline or operator workspace is required.
"""
from pathlib import Path
import argparse
import os
import re
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
args = parser.parse_args()
args.baseline = False
source_root = root/'source/app/src/main'
import os
import shutil
def java_tool(name):
    suffix = '.exe' if os.name == 'nt' else ''
    configured = os.environ.get('JAVA_HOME')
    candidate = Path(configured) / 'bin' / (name + suffix) if configured else None
    result = str(candidate) if candidate and candidate.is_file() else shutil.which(name)
    if not result:
        raise RuntimeError('Set JAVA_HOME or put JDK17 java/javac on PATH')
    return result
base = root/'source'
connector = (base/'app/src/main/java/com/winlator/xconnector/XConnectorEpoll.java').read_text('utf-8')
for old,new in {
    'import androidx.annotation.Keep;':'', 'import dalvik.annotation.optimization.CriticalNative;':'',
    '@Keep':'', '@CriticalNative':'', 'System.loadLibrary("winlator");':'',
    'private native long nativeAllocate(String sockPath);':'private long nativeAllocate(String sockPath) { return 1; }',
}.items():
    assert old in connector, old
    connector=connector.replace(old,new)
files={
 'com/winlator/xconnector/XConnectorEpoll.java':connector,
 'android/util/Log.java':'package android.util; public class Log { public static int i(String a,String b){return 0;} }',
 'com/winlator/xconnector/UnixSocketConfig.java':'package com.winlator.xconnector; public class UnixSocketConfig { final String path="test"; }',
 'com/winlator/xconnector/XInputStream.java':'''package com.winlator.xconnector;
 public class XInputStream { static int live; public XInputStream(int fd,int size){live++;}
 public void destroy(){live--;} public int readMoreData(boolean fd){return 0;}
 public int getActivePosition(){return 0;} public void setActivePosition(int n){} }''',
 'com/winlator/xconnector/XOutputStream.java':'''package com.winlator.xconnector;
 public class XOutputStream { static int failure,live; public XOutputStream(int fd,int size){
 if(failure==1)throw new IllegalStateException("test allocation");
 if(failure==2)throw new OutOfMemoryError("test allocation");live++;}
 public void destroy(){live--;} }''',
 'com/winlator/xconnector/InitializationTest.java':r'''package com.winlator.xconnector;
 import java.lang.reflect.*;
 public final class InitializationTest {
  static int checks,failures;
  static void check(boolean v,String name){checks++;if(!v){failures++;System.err.println("FAIL: "+name);}}
  static final class Handler implements ConnectionHandler {
   int owned,started,closed,mode;ConnectedClient last;
   public ConnectedClient newConnectedClient(long pointer,int fd){
    if(mode==3)throw new IllegalStateException("test factory");
    owned++;return last=new ConnectedClient(pointer,fd);
   }
   public void handleNewConnection(ConnectedClient c){started++;if(mode==4)throw new IllegalStateException("test callback");}
   public void handleConnectionShutdown(ConnectedClient c){owned--;closed++;if(mode==5)throw new IllegalStateException("test cleanup");}
  }
  static Object connect(XConnectorEpoll c)throws Exception {
   Method m=XConnectorEpoll.class.getDeclaredMethod("handleNewConnection",long.class,int.class);m.setAccessible(true);
   try{return m.invoke(c,17L,9);}catch(InvocationTargetException old){
    check(false,"initialization failure must not escape the JNI callback");return null;}
  }
  static void failure(int mode,int outputFailure)throws Exception {
   Handler h=new Handler();h.mode=mode;XOutputStream.failure=outputFailure;
   int inputs=XInputStream.live,outputs=XOutputStream.live;
   XConnectorEpoll c=new XConnectorEpoll(new UnixSocketConfig(),h,client->false);
   check(connect(c)==null,"failed initialization returns no native tag");
   check(c.getClients().isEmpty(),"failed client never enters active list");
   check(h.owned==0,"partial resource registrations released");
   check(XInputStream.live==inputs && XOutputStream.live==outputs,"completed streams destroyed after failure");
   check(mode==3 || h.last.isClosed(),"partial client marked closed");
   check(h.closed==(mode==3?0:1),"cleanup callback runs exactly once for an allocated client");
  }
  public static void main(String[] args)throws Exception {
   failure(0,1);failure(0,2);failure(3,0);failure(4,0);failure(5,1);
   XOutputStream.failure=0;Handler h=new Handler();
   XConnectorEpoll c=new XConnectorEpoll(new UnixSocketConfig(),h,client->false);
   Object value=connect(c);
   check(value==h.last && c.getClients().size()==1,"successful client is retained normally");
   check(h.started==1 && h.closed==0 && h.owned==1,"successful initialization does not clean resources early");
   Method shutdown=XConnectorEpoll.class.getDeclaredMethod("handleConnectionShutdown",Object.class);shutdown.setAccessible(true);
   shutdown.invoke(c,value);
   check(c.getClients().isEmpty() && h.last.isClosed() && h.owned==0,"normal shutdown still releases successful client");
   if(failures>0)throw new AssertionError(failures+" of "+checks+" initialization checks failed");
   System.out.println("PASS: "+checks+" actual Java connection initialization and cleanup checks");
  }
 }'''
}
for name in ('ConnectedClient.java','ConnectionHandler.java','RequestHandler.java'):
    files['com/winlator/xconnector/'+name]=(source_root/'java/com/winlator/xconnector'/name).read_text('utf-8')

def function(text,name):
    start=re.search(r'^static\s+[^\n]*\b'+name+r'\(',text,re.M).start()
    end=text.index('{',start)+1;depth=1
    while depth:
        depth+=(text[end]=='{')-(text[end]=='}');end+=1
    return text[start:end]+'\n'

native=(source_root/'cpp/winlator/src/xconnector_epoll.c').read_text('utf-8')
c=r'''
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
typedef int64_t jlong;typedef void* jobject;typedef void* jmethodID;
typedef const struct JNI* JNIEnv;typedef const struct VM* JavaVM;
struct JNI {jobject(*CallObjectMethod)(JNIEnv*,jobject,jmethodID,...);
 bool(*ExceptionCheck)(JNIEnv*);void(*ExceptionClear)(JNIEnv*);
 void(*CallVoidMethod)(JNIEnv*,jobject,jmethodID,...);};
struct VM {void(*DetachCurrentThread)(JavaVM*);};
typedef struct {JavaVM* jvm;JNIEnv* env;jobject obj;jmethodID handleConnectionShutdown,handleNewConnection,handleExistingConnection;} JMethods;
typedef struct {uintptr_t pollThread;int fd,shutdownFd;bool running;void* tag;JMethods jmethods;} ConnectedClient;
typedef struct {int epollFd;bool multithreadedClients;JMethods jmethods;} XConnectorEpoll;
static int mode,clears,callbacks,closes,adds,removes,frees,detaches,threadDetaches;
static bool pending,allocationFailure,addFailure,eventFailure,threadFailure;
static void* allocated;static void*(*threadMain)(void*);static void* threadArg;
static jobject callback(JNIEnv*e,jobject o,jmethodID m,...){callbacks++;pending=mode==2;return mode==1?NULL:(void*)0x1234;}
static bool exception(JNIEnv*e){return pending;}static void clear(JNIEnv*e){clears++;pending=false;}
static void shutdownCallback(JNIEnv*e,jobject o,jmethodID m,...){assert(!pending);}
static void detach(JavaVM*v){detaches++;}
static const struct JNI jni={callback,exception,clear,shutdownCallback};static JNIEnv environment=&jni;
static const struct VM vm={detach};static JavaVM virtualMachine=&vm;
static void loadJMethods(JMethods*j){j->env=&environment;}
static bool addFdToEpoll(int epoll,int fd,void*p){adds++;return !addFailure;}
static void removeFdFromEpoll(int epoll,int fd){removes++;}
static void socket_io_diagnostic(const char*s,int fd,int a,int b){}
static void closeFd(int fd){assert(fd>=0);closes++;}
#define close closeFd
#define CLOSEFD(fd) do{if((fd)>=0){closeFd(fd);(fd)=-1;}}while(0)
static void* allocate(size_t n,size_t s){if(allocationFailure)return NULL;allocated=calloc(n,s);return allocated;}
static void release(void*p){frees++;free(p);}
#define calloc allocate
#define free release
#define EFD_NONBLOCK 1
static int eventfd(int value,int flags){return eventFailure?-1:29;}
static int pthread_create(uintptr_t*t,void*a,void*(*fn)(void*),void*arg){threadMain=fn;threadArg=arg;*t=1;return threadFailure?1:0;}
static uintptr_t pthread_self(void){return 1;}
static int pthread_detach(uintptr_t t){threadDetaches++;return 0;}
static int waitForSocketRead(int fd,int shutdown){return -1;}
'''
for name in ('initializeClient','rejectClient','pollThread','XConnectorEpoll_handleNewConnection'):
    if not args.baseline:c+=function(native,name)
c+=r'''
static void reset(void){mode=clears=callbacks=closes=adds=removes=frees=detaches=threadDetaches=0;
 pending=allocationFailure=addFailure=eventFailure=threadFailure=false;threadMain=NULL;threadArg=NULL;allocated=NULL;}
int main(void){
 XConnectorEpoll connector={.epollFd=7,.jmethods={.jvm=&virtualMachine,.env=&environment}};
 for(int failure=1;failure<=2;failure++){
  reset();mode=failure;XConnectorEpoll_handleNewConnection(&connector,19);
  assert(callbacks==1 && adds==1 && removes==1 && closes==1 && frees==1 && !pending);
  assert(clears==(failure==2));
 }
 reset();XConnectorEpoll_handleNewConnection(&connector,19);
 assert(callbacks==1 && adds==1 && removes==0 && closes==0 && frees==0);
 assert(((ConnectedClient*)allocated)->tag==(void*)0x1234);rejectClient(allocated);
 reset();allocationFailure=true;XConnectorEpoll_handleNewConnection(&connector,19);
 assert(closes==1 && adds==0 && callbacks==0 && frees==0);
 reset();mode=1;XConnectorEpoll_handleNewConnection(&connector,0);
 assert(closes==1 && removes==1 && frees==1);
 reset();allocationFailure=true;XConnectorEpoll_handleNewConnection(&connector,0);
 assert(closes==1 && callbacks==0 && frees==0);
 reset();addFailure=true;XConnectorEpoll_handleNewConnection(&connector,19);
 assert(closes==1 && frees==1 && callbacks==0);
 connector.multithreadedClients=true;
 for(int failure=1;failure<=2;failure++){
  reset();mode=failure;XConnectorEpoll_handleNewConnection(&connector,19);assert(threadMain);
  threadMain(threadArg);
  assert(callbacks==1 && closes==2 && frees==1 && !pending && detaches==1 && threadDetaches==1);
 }
 reset();eventFailure=true;XConnectorEpoll_handleNewConnection(&connector,19);
 assert(closes==1 && frees==1 && callbacks==0 && !threadMain);
 reset();threadFailure=true;XConnectorEpoll_handleNewConnection(&connector,19);
 assert(closes==2 && frees==1 && callbacks==0);
 puts("PASS: actual native connection paths reject null/exception tags, close accepted descriptors, remove epoll registrations, detach failed workers and retain successful clients");
 return 0;
}
'''
with tempfile.TemporaryDirectory(prefix='xconnector-init-',dir=root/'tests') as temporary:
    out=Path(temporary);sources=[]
    for name,text in files.items():
        path=out/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,'utf-8');sources.append(path)
    subprocess.run([java_tool('javac'),'-encoding','UTF-8','-d',str(out),*map(str,sources)],check=True)
    result=subprocess.run([java_tool('java'),'-cp',str(out),'com.winlator.xconnector.InitializationTest'])
    if args.baseline:
        assert result.returncode!=0,'Baseline unexpectedly cleaned failed initialization'
        print('REPRODUCED: retained Java callback leaks partial initialization and lets failure escape JNI')
    else:
        result.check_returncode()
        source=out/'native.c';source.write_text(c,'utf-8');exe=out/'native.exe'
        compiler = os.environ.get('CC') or next((shutil.which(n) for n in ('cc','clang','gcc','zig') if shutil.which(n)), None)
        if not compiler: raise RuntimeError('Set CC or install a C compiler')
        command = [compiler] + (['cc'] if Path(compiler).stem.lower() == 'zig' else [])
        env=os.environ.copy(); env['ZIG_GLOBAL_CACHE_DIR']=str(out/'zig-cache')
        env['ZIG_LOCAL_CACHE_DIR']=env['ZIG_GLOBAL_CACHE_DIR']; env['TMP']=env['TEMP']=str(out)
        subprocess.run(command+['-std=c11','-O0','-Wall',str(source),'-o',str(exe)],env=env,check=True)
        subprocess.run([str(exe)],env=env,check=True)
