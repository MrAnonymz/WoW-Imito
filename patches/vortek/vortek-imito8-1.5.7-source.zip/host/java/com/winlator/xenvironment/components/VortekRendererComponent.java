package com.winlator.xenvironment.components;

import android.content.Context;

import androidx.annotation.Keep;

import com.winlator.contentdialog.VortekConfigDialog;
import com.winlator.core.GPUHelper;
import com.winlator.core.GeneralComponents;
import com.winlator.core.KeyValueSet;
import com.winlator.renderer.GPUImage;
import com.winlator.renderer.Texture;
import com.winlator.xconnector.ConnectedClient;
import com.winlator.xconnector.ConnectionHandler;
import com.winlator.xconnector.RequestHandler;
import com.winlator.xconnector.UnixSocketConfig;
import com.winlator.xconnector.XConnectorEpoll;
import com.winlator.xconnector.XInputStream;
import com.winlator.xenvironment.EnvironmentComponent;
import com.winlator.xserver.Drawable;
import com.winlator.xserver.Window;
import com.winlator.xserver.XServer;

import java.io.IOException;

public class VortekRendererComponent extends EnvironmentComponent implements ConnectionHandler, RequestHandler {
    private static final byte REQUEST_CODE_CREATE_CONTEXT = 1;
    private static final byte REQUEST_CODE_SEND_EXTRA_DATA = 2;
    public static final short IMAGE_CACHE_SIZE = 256;
    public static final int VK_MAX_VERSION = GPUHelper.vkMakeVersion(1, 3, 128);
    private final XServer xServer;
    private final UnixSocketConfig socketConfig;
    private XConnectorEpoll connector;
    private final Options options;
    private volatile boolean stopping;
    private PanvkTextureSettings textureSettings;
    private final java.util.concurrent.ConcurrentHashMap<Long, PresentationBuffer> presentationBuffers = new java.util.concurrent.ConcurrentHashMap<>();
    private static final int SURFACE_LOST = -1000000000, OUT_OF_DATE = -1000001004, DEVICE_LOST = -4;
    private static final class PresentationBuffer {
        final Window window; final Drawable content; final GPUImage image; final int format;
        volatile PresentationFrame pending;
        boolean firstPresented;
        PresentationBuffer(Window window, Drawable content, GPUImage image, int format) {
            this.window=window;this.content=content;this.image=image;this.format=format;
        }
    }
    private static final class PresentationFrame {
        final java.util.concurrent.CountDownLatch finished=new java.util.concurrent.CountDownLatch(1);
        volatile boolean cancelled;
        volatile int result=DEVICE_LOST;
        long activeWaitRemaining=java.util.concurrent.TimeUnit.SECONDS.toNanos(5);
    }
    private final long evidenceGeneration = com.winlator.wowmobile.GameRuntimeEvidence.generation();

    static {
        System.loadLibrary("vortekrenderer");
    }

    public static class Options {
        public int vkMaxVersion = VK_MAX_VERSION;
        public short maxDeviceMemory = 0;
        public short imageCacheSize = IMAGE_CACHE_SIZE;
        public byte resourceMemoryType = 0;
        public String[] exposedDeviceExtensions = null;
        public String libvulkanPath = null;
        public boolean linearDmaPresentation = false;
        public boolean recoverAutomaticPresentation;
        public boolean exactPanvkTextures;
        public int compilerThreads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() / 2));

        public static Options fromKeyValueSet(Context context, KeyValueSet config) {
            if (config == null || config.isEmpty()) return new Options();

            Options options = new Options();
            String exposedDeviceExtensions = config.get("exposedDeviceExtensions", "all");
            if (!exposedDeviceExtensions.isEmpty() && !exposedDeviceExtensions.equals("all")) {
                options.exposedDeviceExtensions = exposedDeviceExtensions.split("\\|");
            }

            String vkMaxVersion = config.get("vkMaxVersion", VortekConfigDialog.DEFAULT_VK_MAX_VERSION);
            if (!vkMaxVersion.equals(VortekConfigDialog.DEFAULT_VK_MAX_VERSION)) {
                String[] parts = vkMaxVersion.split("\\.");
                options.vkMaxVersion = GPUHelper.vkMakeVersion(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), 128);
            }

            options.maxDeviceMemory = (short)config.getInt("maxDeviceMemory");
            options.imageCacheSize = (short)config.getInt("imageCacheSize", VortekRendererComponent.IMAGE_CACHE_SIZE);
            options.resourceMemoryType = (byte)config.getInt("resourceMemoryType");

            String adrenotoolsDriver = config.get("adrenotoolsDriver");
            options.libvulkanPath = GeneralComponents.getDefinitivePath(GeneralComponents.Type.ADRENOTOOLS_DRIVER, context, adrenotoolsDriver);
            return options;
        }
    }

    public VortekRendererComponent(XServer xServer, UnixSocketConfig socketConfig, Options options) {
        this.xServer = xServer;
        this.socketConfig = socketConfig;
        this.options = options;
        xServer.getRenderer().xServerView.enableVortekFrameQueue();

        String nativeLibraryDir = xServer.activity.getApplicationInfo().nativeLibraryDir;
        if (!initVulkanWrapper(nativeLibraryDir, options.libvulkanPath)) {
            com.winlator.wowmobile.WrathRTRuntimeFailure.graphicsContextFailed();
            throw new IllegalStateException("The selected Vulkan driver could not be loaded.");
        }
    }

    @Override
    public void start() {
        if (connector != null) return;
        stopping = false;
        // The ICD reads these options at physical device / image creation. Set them
        // before opening the socket that accepts the guest's first Vulkan request.
        if (options.exactPanvkTextures) textureSettings = PanvkTextureSettings.enable();
        connector = new XConnectorEpoll(socketConfig, this, this);
        connector.setInitialInputBufferCapacity(8);
        connector.setInitialOutputBufferCapacity(0);
        connector.start();
    }

    @Override
    public void stop() {
        stopping = true;
        if (connector != null) {
            connector.destroy();
            connector = null;
        }
        if (textureSettings != null) {
            textureSettings.restore();
            textureSettings = null;
        }
    }

    @Keep
    private int getWindowWidth(int windowId) {
        Window window = xServer.windowManager.getWindow(windowId);
        return window != null ? window.getWidth() : 0;
    }

    @Keep
    private int getWindowHeight(int windowId) {
        Window window = xServer.windowManager.getWindow(windowId);
        return window != null ? window.getHeight() : 0;
    }

    @Keep
    private boolean attachWindowHardwareBuffer(int windowId, int format, long buffer) {
        Window window=xServer.windowManager.getWindow(windowId);
        if(window==null || buffer==0)return false;
        Drawable content=window.getContent();
        GPUImage image=new GPUImage(content,buffer);
        PresentationBuffer value=new PresentationBuffer(window,content,image,format);
        if(presentationBuffers.putIfAbsent(buffer,value)!=null) {
            xServer.getRenderer().xServerView.queueEvent(image::destroy);return false;
        }
        return true;
    }

    @Keep
    private void releaseWindowHardwareBuffer(long buffer) {
        PresentationBuffer value=presentationBuffers.remove(buffer);
        if(value!=null)xServer.getRenderer().xServerView.queueEvent(value.image::destroy);
    }

    @Keep
    private int updateWindowContent(int windowId, long buffer) {
        PresentationBuffer value=presentationBuffers.get(buffer);
        Window window=xServer.windowManager.getWindow(windowId);
        if(window==null)return SURFACE_LOST;
        if(value==null || value.window!=window || value.content!=window.getContent())return OUT_OF_DATE;
        PresentationFrame previous=value.pending;
        if(previous!=null && (previous.finished.getCount()!=0 || previous.result!=0))return DEVICE_LOST;
        PresentationFrame frame=new PresentationFrame();value.pending=frame;
        xServer.getRenderer().xServerView.queueNativeFrame(() -> {
            try {
                if(frame.cancelled || stopping)return;
                if(xServer.windowManager.getWindow(windowId)!=window || window.getContent()!=value.content) {
                    frame.result=OUT_OF_DATE;return;
                }
                Drawable content=value.content;
                Texture previousTexture=content.getTexture();
                boolean replace=previousTexture==null || content.getData()!=null || previousTexture instanceof GPUImage || previousTexture.getOwner()!=content;
                Texture target=replace ? new Texture(content) : previousTexture;
                if (replace) {
                    boolean installed=false;
                    try {
                        if(!value.image.copyToTexture(target,content.width,content.height) || frame.cancelled || stopping)return;
                        installed=content.installFrameTexture(xServer,previousTexture,target,
                                () -> !frame.cancelled && !stopping && xServer.windowManager.getWindow(windowId)==window && window.getContent()==content);
                        if(!installed){
                            if(!frame.cancelled && !stopping)frame.result=OUT_OF_DATE;
                            return;
                        }
                    } finally {
                        if(!installed)target.destroy();
                    }
                    if(previousTexture!=null && previousTexture.getOwner()==content)previousTexture.destroy();
                }
                synchronized(content.renderLock) {
                    if (content.getTexture()!=target || window.getContent()!=content || xServer.windowManager.getWindow(windowId)!=window) {
                        frame.result=OUT_OF_DATE;return;
                    }
                    if(!replace && !value.image.copyToTexture(target,content.width,content.height))return;
                    if(frame.cancelled || stopping)return;
                    if (!window.markNativeFramePresented(content)) { frame.result=OUT_OF_DATE; return; }
                    content.forceUpdate();target.setNeedsUpdate(false);
                    if(!value.firstPresented) {
                        value.firstPresented=true;
                        recordSwapchainStartup(9,0,value.format,content.width,content.height,windowId);
                    }
                }
                frame.result=0;
            } catch(RuntimeException failure) {
                frame.result=DEVICE_LOST;
            } finally {
                if(frame.result==DEVICE_LOST && !frame.cancelled && !stopping)
                    recordSwapchainStartup(20,DEVICE_LOST,value.format,value.content.width,value.content.height,windowId);
                frame.finished.countDown();
            }
        });
        // The private VkImage is already copied and may render the next frame.
        // The next native copy must await this GL read before reusing the AHB.
        return 0;
    }

    @Keep
    private int awaitWindowContent(long buffer, boolean contextCancelled) {
        PresentationBuffer value=presentationBuffers.get(buffer);
        if(value==null)return OUT_OF_DATE;
        PresentationFrame frame=value.pending;
        if(frame==null)return 0;
        if(contextCancelled || stopping){frame.cancelled=true;return DEVICE_LOST;}
        try {
            if(frame.finished.getCount()!=0) {
                boolean paused=xServer.getRenderer().xServerView.isPresentationPaused();
                long before=System.nanoTime();
                if(frame.finished.await(50,java.util.concurrent.TimeUnit.MILLISECONDS))
                    return frame.cancelled?DEVICE_LOST:frame.result;
                // Android pauses the GL consumer and guest together. A normal
                // background interval must not masquerade as a failed GPU.
                if(!paused && !xServer.getRenderer().xServerView.isPresentationPaused())frame.activeWaitRemaining-=System.nanoTime()-before;
                if(frame.activeWaitRemaining<=0){frame.cancelled=true;return DEVICE_LOST;}
                // Return to native every slice so a disconnected guest can
                // interrupt this wait even while the GL view remains paused.
                return 1; // VK_NOT_READY
            }
        } catch(InterruptedException interrupted) {
            frame.cancelled=true;Thread.currentThread().interrupt();return DEVICE_LOST;
        }
        return frame.cancelled?DEVICE_LOST:frame.result;
    }

    @Keep
    private void recordSwapchainStartup(int stage,int result,int format,int width,int height,int windowId) {
        com.winlator.wowmobile.GameRuntimeEvidence.vortekStartup(evidenceGeneration,
                stage,result,format,width,height,windowId & 0xffffffffL);
        com.winlator.wowmobile.WrathRTRuntimeFailure.vulkanRenderFailure(evidenceGeneration,stage,result);
        if (options.recoverAutomaticPresentation && !stopping && stage == 14 && result == DEVICE_LOST && format == 37)
            com.winlator.wowmobile.WrathRTGraphicsRecovery.presentWaitLost(environment.getContext(), evidenceGeneration, options.linearDmaPresentation);
    }

    @Override
    public void handleConnectionShutdown(ConnectedClient client) {
        if (client.getTag() != null) {
            long contextPtr = (long)client.getTag();
            destroyVkContext(contextPtr);
        }
    }

    @Override
    public void handleNewConnection(ConnectedClient client) {}

    @Override
    public boolean handleRequest(ConnectedClient client) throws IOException {
        XInputStream inputStream = client.getInputStream();
        if (client.isClosed() || inputStream == null) return false;
        if (inputStream.available() < 8) return false;
        int requestCode = inputStream.readInt();
        int requestLength = inputStream.readInt();

        if (requestCode == REQUEST_CODE_CREATE_CONTEXT) {
            long contextPtr = createVkContext(client.fd, options);
            // Android heap tags occupy the top byte. A valid native pointer can
            // therefore be negative as a Java long; only zero means failure.
            if (com.winlator.BuildConfig.WRATHRT_DIAGNOSTICS)
                android.util.Log.i("WrathRTVortek", "context_created=" + (contextPtr != 0)
                        + " signed_high_bit=" + (contextPtr < 0));
            if (contextPtr != 0) {
                client.setTag(contextPtr);
            }
            else {
                com.winlator.wowmobile.WrathRTRuntimeFailure.graphicsContextFailed();
                throw new IOException("The graphics connection could not be prepared.");
            }
        }
        else if (requestCode > Short.MAX_VALUE && (requestCode >> 16) == REQUEST_CODE_SEND_EXTRA_DATA) {
            int requestId = requestCode & 0xffff;
            if (!(client.getTag() instanceof Long)) throw new IOException("Graphics context is missing.");
            long contextPtr = (long)client.getTag();
            boolean success = handleExtraDataRequest(contextPtr, requestId, requestLength);
            if (!success) throw new IOException("Failed to handle extra data request.");
        }

        return true;
    }

    private native long createVkContext(int clientFd, Options options);

    private native void destroyVkContext(long contextPtr);

    private native boolean initVulkanWrapper(String nativeLibraryDir, String libvulkanPath);

    private native boolean handleExtraDataRequest(long contextPtr, int requestCode, int requestLength);
}
