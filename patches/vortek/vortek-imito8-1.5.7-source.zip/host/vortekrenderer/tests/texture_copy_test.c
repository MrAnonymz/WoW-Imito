#include <stddef.h>
#include "../include/texture_copy_layout.h"
#define MIN(a,b) ((a)<(b)?(a):(b))
typedef struct { int numThreads; } ThreadPool;
static unsigned tasksRun;
static void ThreadPool_run(ThreadPool* pool, void (*fn)(void*), void* arg) { tasksRun++; fn(arg); }
static void ThreadPool_wait(ThreadPool* pool) {}
void* memset(void* target, int value, size_t count) {
    unsigned char* p=target; for (size_t i=0;i<count;i++) p[i]=(unsigned char)value; return target;
}
void* memcpy(void* target,const void* source,size_t count) {
    unsigned char* p=target; const unsigned char* s=source;
    for(size_t i=0;i<count;i++) p[i]=s[i]; return target;
}
#include "../include/bc_decoder.h"
static unsigned failures;
static uint8_t source[32768], target[262144];
static void check(bool value) { if(!value) failures++; }
static void block(uint8_t* p,int bc,uint16_t color) {
    if(bc==2) { memset(p,255,8); p+=8; }
    if(bc==3) { memset(p,0,8); p[0]=255; p+=8; }
    BCColor c={color,0,0}; memcpy(p,&c,sizeof(c));
}
static void regionTest(int bc, uint32_t mip, uint32_t layer, uint32_t extent, bool padded) {
    TextureCopyImageLayout image; TextureCopyLayout copy;
    check(TextureCopy_imageLayout(&image,64,64,1,7,6));
    uint32_t side=TextureCopy_mipSize(64,mip), size=extent?extent:side;
    uint32_t offset=extent?4:0;
    VkBufferImageCopy r={.bufferOffset=32,.bufferRowLength=padded?size+4:0,
        .bufferImageHeight=padded?size+4:0,
        .imageSubresource={VK_IMAGE_ASPECT_COLOR_BIT,mip,layer,1},
        .imageOffset={offset,offset,0},.imageExtent={size,size,1}};
    uint32_t bytes=bc==1?8:16;
    check(TextureCopy_regionLayout(&image,&r,bytes,sizeof(source),&copy));
    memset(source,0xA5,sizeof(source)); memset(target,0xCD,sizeof(target));
    for(uint32_t y=0;y<size;y+=4) for(uint32_t x=0;x<size;x+=4)
        block(source+copy.sourceOffset+(y/4)*copy.sourceRowPitch+(x/4)*bytes,bc,
              ((x/4+y/4)&1)?0x07e0:0xf800);
    BCDecoder_decodeStrided(source+copy.sourceOffset,target+copy.targetOffset,size,size,
            copy.sourceRowPitch,copy.targetRowPitch,bc,false,NULL);
    // Whole mip chain/layer guards detect corruption outside the requested atlas rectangle.
    for(size_t i=0;i<sizeof(target);i++) {
        size_t base=layer*image.layerSize+image.mipOffsets[mip];
        bool inMip=i>=base && i<base+(size_t)side*side*4;
        size_t pixel=(i-base)/4, x=pixel%side,y=pixel/side;
        bool inside=inMip && x>=offset && x<offset+size && y>=offset && y<offset+size;
        uint8_t expected=0xCD;
        if(inside) {
            bool green=(((x-offset)/4+(y-offset)/4)&1)!=0;
            unsigned ch=(i-base)%4;
            expected=ch==3?255:(ch==1&&green)||(ch==2&&!green)?255:0;
        }
        if(target[i]!=expected) { failures++; break; }
    }
}
__declspec(dllimport) void __stdcall ExitProcess(unsigned int exit_code);
void mainCRTStartup(void) {
    for(int bc=1;bc<=3;bc++) {
        for(uint32_t mip=0;mip<7;mip++) regionTest(bc,mip,mip%6,0,false);
        regionTest(bc,0,5,8,true);
    }
    TextureCopyImageLayout image; TextureCopyLayout copy;
    check(TextureCopy_imageLayout(&image,8,8,1,4,6));
    VkBufferImageCopy r={.bufferOffset=24,.bufferRowLength=12,.bufferImageHeight=12,
        .imageSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,2,3},.imageExtent={8,8,1}};
    check(TextureCopy_regionLayout(&image,&r,8,sizeof(source),&copy));
    check(copy.sourceRowPitch==24 && copy.sourceSlicePitch==72 && copy.sourceLayerPitch==72);
    check(copy.targetOffset==2*image.layerSize && copy.targetLayerPitch==image.layerSize);
    check(!TextureCopy_regionLayout(&image,&r,8,24+144+24+16-1,&copy));
    check(TextureCopy_regionLayout(&image,&r,8,24+144+24+16,&copy));
    r.imageSubresource.mipLevel=4; check(!TextureCopy_regionLayout(&image,&r,8,sizeof(source),&copy));
    r.imageSubresource.mipLevel=0; r.imageOffset.x=1; check(!TextureCopy_regionLayout(&image,&r,8,sizeof(source),&copy));
    r.imageOffset.x=0;r.bufferOffset=UINT64_MAX; check(!TextureCopy_regionLayout(&image,&r,8,sizeof(source),&copy));
    check(!TextureCopy_imageLayout(&image,0,8,1,1,1));
    check(!TextureCopy_imageLayout(&image,8,8,1,5,1));
    // Four worker chunks must advance by the padded source/destination pitches.
    ThreadPool pool={4};
    for(int bc=1;bc<=5;bc++) {
        unsigned bytes=(bc==1||bc==4)?8:16;
        memset(source,0,sizeof(source)); memset(target,0xCD,sizeof(target));
        for(unsigned y=0;y<33;y++) for(unsigned x=0;x<2;x++) {
            uint8_t* p=source+y*bytes*3+x*bytes;
            if(bc<=3) block(p,bc,y<16?0xf800:0x07e0);
            else { p[0]=y<16?255:127; if(bc==5) p[8]=63; }
        }
        tasksRun=0;
        BCDecoder_decodeStrided(source,target,8,130,bytes*3,48,bc,true,&pool);
        check(tasksRun==4);
        for(unsigned y=0;y<130;y++) for(unsigned x=0;x<48;x++) {
            uint8_t expected=0xCD;
            if(x<32 && bc<=3) expected=x%4==3?255:(x%4==2&&y<64)||(x%4==1&&y>=64)?255:0;
            else if(x<32 && x%4==0) expected=y<64?255:127;
            else if(x<32 && bc==5 && x%4==1) expected=63;
            if(target[y*48+x]!=expected) { failures++; y=130; break; }
        }
        check(target[130*48]==0xCD);
    }
    ExitProcess(failures);
}
