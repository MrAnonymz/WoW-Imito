"""Exercise actual swapchain enumeration and terminal retirement, without a GPU."""
from pathlib import Path
import json, os, re, subprocess
ROOT=Path(__file__).resolve().parents[2]
HOST=ROOT/'apk-source/app/src/main/cpp/vortekrenderer'
GUEST=ROOT/'build-tools/compat-native/vortek-source/brunodev85-vortek-b1730c5'
OUT=ROOT/'testovanie/154/vortek-present'
def fn(text,name):
    m=re.search(r'^(?:static\s+)?[A-Za-z_][A-Za-z0-9_* \t]*\b'+name+r'\(',text,re.M)
    start=m.start(); end=text.index('{',start)+1; depth=1
    while depth:
        depth+=(text[end]=='{')-(text[end]=='}');end+=1
    return text[start:end]
h=(HOST/'src/request_handler.c').read_text();s=(HOST/'src/xwindow_swapchain.c').read_text()
g=(GUEST/'src/vulkan_calls.c').read_text();v=(HOST/'src/vk_context.c').read_text()
header=(HOST/'include/xwindow_swapchain.h').read_text()
structs=header[header.index('typedef struct XWindowSwapchain_Image'):header.index('/* Bounded startup evidence')]
c=r'''
#define VK_NO_PROTOTYPES 1
#include "vulkan/vulkan_core.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {void* obj;} JMethods;
'''+structs+r'''
typedef struct {int size;void** elements;} ArrayList;
typedef struct {void* data;} ExtraDataRequest;
typedef struct VkContext {bool gpuWorkRetired;char* inputBuffer;struct {void* data;} memoryPool;
 void *clientRing,*serverRing,*threadPool,*waitThreadPool,*pipelineThreadPool,*shaderInspector,*textureDecoder;
 void *exposedDeviceExtensions,*disabledDeviceExtensions,*engineName;int requestHandlerThread,graphicsQueueIndex;
 int extraDataRequestsReady,extraDataRequestsMutex;ArrayList extraDataRequests;JMethods jmethods;} VkContext;
typedef struct {uint64_t id;} VkObject;
typedef struct JNIT {void(*DeleteGlobalRef)(void*,void*);} JNIT;typedef const JNIT* JNIEnv;
static int checks,allocFail,allocations,destroyFence,destroyImage,freeMemory,destroyDevice,freed;
static int decoders,threads,rings,joins,fails,globalRefs,wireCalls,locked,wireHasImages;
static size_t allocBytes;static uint32_t requestCount,replyCount;static VkImage replyImages[3];
static XWindowSwapchain* current;static VkResult result;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL line%d %s\n",__LINE__,#x);return 1;}}while(0)
static void* alloc(size_t count,size_t size){allocations++;allocBytes=count*size;return allocFail?NULL:calloc(count,size);}
static void release(void* p){if(p){freed++;free(p);}}
#define MEMFREE(p) do{release(p);p=NULL;}while(0)
static void driverFence(VkDevice d,VkFence f,const VkAllocationCallbacks* a){destroyFence++;}
static void driverImage(VkDevice d,VkImage f,const VkAllocationCallbacks* a){destroyImage++;}
static void driverMemory(VkDevice d,VkDeviceMemory f,const VkAllocationCallbacks* a){freeMemory++;}
static void driverDevice(VkDevice d,const VkAllocationCallbacks* a){destroyDevice++;}
static struct {PFN_vkDestroyFence vkDestroyFence;PFN_vkDestroyImage vkDestroyImage;
 PFN_vkFreeMemory vkFreeMemory;PFN_vkDestroyDevice vkDestroyDevice;} vulkanWrapper={driverFence,driverImage,driverMemory,driverDevice};
'''+fn(s,'XWindowSwapchain_destroy')+r'''
static void* VkObject_fromId(uint64_t id){return (void*)(uintptr_t)id;}
static void unmarshal(VkDevice d,VkSwapchainKHR s,uint32_t* count){if(d)*(uint64_t*)d=11;if(s)*(uint64_t*)s=(uintptr_t)current;if(count)*count=requestCount;}
static void vt_unserialize_vkGetSwapchainImagesKHR(VkDevice d,VkSwapchainKHR s,uint32_t* count,VkImage* images,void* b,void* pool){
 if(!d&&!s){*count=replyCount;if(images&&wireHasImages)memcpy(images,replyImages,replyCount*sizeof(VkImage));}
 else unmarshal(d,s,count);
}
static void vt_unserialize_vkDestroySwapchainKHR(VkDevice d,VkSwapchainKHR s,void* a,void* b,void* pool){unmarshal(d,s,NULL);}
static void vt_unserialize_vkDestroyDevice(VkDevice d,void* a,void* b,void* pool){unmarshal(d,0,NULL);}
static void serialize(uint32_t* count,VkImage* images){replyCount=*count;wireHasImages=images!=NULL;
 if(images)memcpy(replyImages,images,*count*sizeof(VkImage));}
#define VT_SERIALIZE_CMD(n,d,s,count,images) serialize(count,images);char* outputBuffer=NULL;int bufferSize=0
static void vt_send(void* ring,VkResult r,void* p,int size){result=r;wireCalls++;}
#define calloc alloc
'''+fn(h,'vt_handle_vkGetSwapchainImagesKHR')+r'''
#undef calloc
'''+fn(h,'vt_handle_vkDestroySwapchainKHR')+'\n'+fn(h,'vt_handle_vkDestroyDevice')+r'''
static VkObject object={11};static VkObject* VkObject_fromHandle(void* h){return &object;}
#undef VT_SERIALIZE_CMD
#define VT_CALL_LOCK() do{locked++;}while(0)
#define VT_CALL_UNLOCK() do{locked--;}while(0)
#define VT_SERIALIZE_CMD(n,d,s,count,images) requestCount=*count
#define VT_RETURN 0
#define REQUEST_CODE_VK_GET_SWAPCHAIN_IMAGES_KHR 0
#define VT_SEND_CHECKED(code,ret) do{VkContext context={0};vt_handle_vkGetSwapchainImagesKHR(&context);}while(0)
#define VT_RECV_CHECKED(ret) do{}while(0)
static void* inputBuffer;static int globalMemoryPool;
'''+fn(g,'vt_call_vkGetSwapchainImagesKHR')+r'''
static void failVkContext(VkContext* c,VkResult r){fails++;}
static void RingBuffer_setStatus(void* p,int s){}
#define RING_STATUS_EXIT 1
static void pthread_join(int t,void* r){joins++;}
static void ThreadPool_destroy(void* p){if(p)threads++;}
static void RingBuffer_free(void* p){if(p)rings++;}
static void TextureDecoder_destroy(void* p){if(p)decoders++;}
static void ArrayList_free(void* p,bool b){}
static void pthread_cond_destroy(void* p){}
static void pthread_mutex_destroy(void* p){}
static void deleteGlobal(void* e,void* obj){globalRefs++;}
'''+fn(v,'destroyVkContext')+r'''
static XWindowSwapchain* makeSwap(void){
 XWindowSwapchain* x=calloc(1,sizeof(*x));x->imageCount=3;x->presentFence=(VkFence)(uintptr_t)99;
 x->images=calloc(3,sizeof(*x->images));for(int i=0;i<3;i++)x->images[i].image=(VkImage)(uintptr_t)(101+i);return x;
}
int main(void){
 current=makeSwap();VkImage images[5];
 for(uint32_t capacity=0;capacity<6;capacity++){
  for(int i=0;i<5;i++)images[i]=(VkImage)(uintptr_t)999;
  uint32_t count=capacity;int oldWire=wireCalls;VkResult r=vt_call_vkGetSwapchainImagesKHR((void*)11,current,&count,images);
  CHECK(r==(capacity<3?VK_INCOMPLETE:VK_SUCCESS));CHECK(count==(capacity<3?capacity:3));
  CHECK(!locked);if(!capacity)CHECK(wireCalls==oldWire);
  else{CHECK(allocBytes==count*sizeof(VkImage));for(uint32_t i=0;i<count;i++)CHECK(images[i]==(VkImage)(uintptr_t)(101+i));}
  if(count<5)CHECK(images[count]==(VkImage)(uintptr_t)999);
 }
 uint32_t count=111;int oldAlloc=allocations;
 CHECK(vt_call_vkGetSwapchainImagesKHR((void*)11,current,&count,NULL)==VK_SUCCESS&&count==3);
 CHECK(allocations==oldAlloc&&!wireHasImages);
 allocFail=1;count=2;CHECK(vt_call_vkGetSwapchainImagesKHR((void*)11,current,&count,images)==VK_ERROR_OUT_OF_HOST_MEMORY);
 CHECK(count==0&&!wireHasImages&&!locked);allocFail=0;
 VkContext context={0};context.gpuWorkRetired=true;
 vt_handle_vkDestroySwapchainKHR(&context);vt_handle_vkDestroyDevice(&context);
 CHECK(!destroyFence&&!destroyImage&&!freeMemory&&!destroyDevice);
 current->presentFencePending=true;XWindowSwapchain_destroy((void*)11,current);
 CHECK(!destroyFence&&!destroyImage&&!freeMemory);
 current->presentFencePending=false;context.gpuWorkRetired=false;
 vt_handle_vkDestroySwapchainKHR(&context);vt_handle_vkDestroyDevice(&context);
 CHECK(destroyFence==1&&destroyImage==3&&freeMemory==3&&destroyDevice==1);
 JNIT table={deleteGlobal};JNIEnv env=&table;
 for(int retired=0;retired<2;retired++){
  VkContext* c=calloc(1,sizeof(*c));c->gpuWorkRetired=retired;c->textureDecoder=(void*)1;
  c->threadPool=c->waitThreadPool=c->pipelineThreadPool=(void*)1;c->clientRing=c->serverRing=(void*)1;
  c->requestHandlerThread=1;c->jmethods.obj=(void*)1;int previous=decoders;
  destroyVkContext(&env,c);CHECK(decoders==previous+(retired?0:1));
  CHECK(threads==3*(retired+1)&&rings==2*(retired+1)&&joins==retired+1&&globalRefs==retired+1&&fails==retired+1);
 }
 printf("PASS %d actual capacity, zero-capacity guest, sentinels, allocation failure, pending GPU and terminal context retirement checks\n",checks);return 0;
}
'''
source=OUT/'present-lifetime.c';binary=OUT/'present-lifetime.exe';source.write_text(c)
env=os.environ.copy();env['ZIG_GLOBAL_CACHE_DIR']=env['ZIG_LOCAL_CACHE_DIR']=str(ROOT/'build-tools/compat-native/zig-cache')
env['TEMP']=env['TMP']=str(OUT)
zig=ROOT.parent/'NFSU2-Coop/tools/native-toolchain/zig-x86_64-windows-0.15.2/zig.exe'
subprocess.run([str(zig),'cc','-std=c11','-O0','-I'+str(HOST/'include'),str(source),'-o',str(binary)],env=env,check=True)
run=subprocess.run([str(binary)],capture_output=True,text=True,check=True);print(run.stdout,end='')
(OUT/'present-lifetime-result.json').write_text(json.dumps({'status':'PASS','output':run.stdout.strip()},indent=2)+'\n')
