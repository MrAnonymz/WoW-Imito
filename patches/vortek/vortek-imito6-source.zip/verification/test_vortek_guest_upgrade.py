"""Exercise the production cache-key/invalidation prefix against old and new roots."""
from pathlib import Path
import os
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
JAVA = ROOT / 'apk-source/app/src/main/java/com/winlator'
OUT = ROOT / 'testovanie/issue-123/timeline-guest-upgrade'
OUT.mkdir(parents=True, exist_ok=True)
version_source = (JAVA / 'core/DefaultVersion.java').read_text(encoding='utf-8')
constants = re.findall(r'public static final String (VORTEK|VIRGL|GLADIO|TURNIP) = "([^"]+)";', version_source)
version = dict(constants)['VORTEK']
assert version in ('2.1-enorial4', '2.1-enorial5', '2.1-enorial6')
previous_version = '2.1-enorial' + str(int(version.rsplit('enorial', 1)[1]) - 1)
assert (ROOT / 'apk-source/app/src/main/assets/graphics_driver' / ('vortek-' + version + '.tzst')).is_file()
packager = (ROOT / 'build-tools/compat-native/package-runtime.py').read_text(encoding='utf-8')
assert "'graphics_driver/vortek-" + previous_version + ".tzst'," in packager
assert "'graphics_driver/vortek-" + version + ".tzst'," not in packager
activity = (JAVA / 'XServerDisplayActivity.java').read_text(encoding='utf-8')
start = activity.index('    private boolean extractGraphicsDriverFiles() {')
end = activity.index('        if (changed) {', start)
actual = activity[start:end] + '        return changed;\n    }\n'
actual = actual.replace('private boolean', 'boolean', 1)
value_start = version_source.index('    public static String valueOf(')
value_end = version_source.index('\n    }', value_start) + len('\n    }')
# Keep production switch semantics; unrelated constants are harmless literal fixtures.
all_constants = '\n'.join('static final String ' + k + '="' + v + '";' for k, v in constants)
for key in ['BOX64', 'ZINK', 'D7VK', 'D8VK', 'VKD3D', 'WINED3D', 'CNC_DDRAW', 'SOUNDFONT']:
    all_constants += '\nstatic final String ' + key + '="fixture";'
code = '''import java.io.*;import java.nio.file.*;import java.nio.charset.*;import java.util.*;
public class VortekUpgradeTest {
 static int checks;static void check(boolean result){checks++;if(!result)throw new AssertionError(checks);}
 static class DefaultVersion { CONST VALUE }
 static class GraphicsDrivers {static final String TURNIP="turnip",VORTEK="vortek";}
 static class Config {String get(String key,String fallback){return fallback;}}
 static class Container {String installed;String getExtra(String key){return installed;}}
 static class RootFS {File root;RootFS(File root){this.root=root;}File getRootDir(){return root;}File getLibDir(){return new File(root,"lib");}}
 static class FileUtils {static byte[] read(File path){try{return Files.readAllBytes(path.toPath());}catch(IOException e){return null;}}}
 Map<String,String> envVars=new HashMap<>();String[] graphicsDriver={"vortek","gladio"};
 Config[] graphicsDriverConfig={new Config(),new Config()};Container container=new Container();RootFS rootFS;
 METHOD
 void state(String stored,String marker,boolean library)throws Exception{
   container.installed=stored;File markerFile=new File(rootFS.root,".winlator/.enorial-graphics-driver");
   markerFile.getParentFile().mkdirs();if(marker==null)Files.deleteIfExists(markerFile.toPath());
   else Files.writeString(markerFile.toPath(),marker,StandardCharsets.UTF_8);
   File lib=new File(rootFS.getLibDir(),"libGL.so.1.7.0");lib.getParentFile().mkdirs();
   if(library)Files.write(lib.toPath(),new byte[]{1});else Files.deleteIfExists(lib.toPath());
 }
 public static void main(String[] args)throws Exception{
  VortekUpgradeTest app=new VortekUpgradeTest();app.rootFS=new RootFS(new File(args[0]));
  for(String secondary:new String[]{"gladio","virgl"}){
   app.graphicsDriver[1]=secondary;String suffix="-"+secondary+"-"+DefaultVersion.valueOf(secondary);
   String old="vortek-OLD_VERSION"+suffix,now="vortek-"+DefaultVersion.VORTEK+suffix;
   app.state(old,old,true);check(app.extractGraphicsDriverFiles());
   app.state(now,old,true);check(app.extractGraphicsDriverFiles());
   app.state(old,now,true);check(app.extractGraphicsDriverFiles());
   app.state(now,now,true);check(!app.extractGraphicsDriverFiles());
   app.state(now,null,true);check(app.extractGraphicsDriverFiles());
   app.state(now,now,false);check(app.extractGraphicsDriverFiles());
  }
  app.graphicsDriver=new String[]{"turnip","virgl"};String turnip="turnip-"+DefaultVersion.TURNIP+"-virgl-"+DefaultVersion.VIRGL;
  app.state(turnip,turnip,true);check(!app.extractGraphicsDriverFiles());
  check("0".equals(app.envVars.get("vblank_mode")));
  System.out.println("PASS "+checks+" actual driver upgrade/cache checks");
 }
}
'''.replace('CONST', all_constants).replace('VALUE', version_source[value_start:value_end]).replace('METHOD', actual).replace('OLD_VERSION', previous_version)
source = OUT / 'VortekUpgradeTest.java'
source.write_text(code, encoding='utf-8')
jdk = ROOT / 'build-tools/java-home/jdk-17.0.20.1+1/bin'
env = os.environ.copy()
env['TEMP'] = env['TMP'] = str(OUT)
subprocess.run([str(jdk / 'javac.exe'), '-encoding', 'UTF-8', '-d', str(OUT), str(source)], env=env, check=True)
subprocess.run([str(jdk / 'java.exe'), '-cp', str(OUT), 'VortekUpgradeTest', str(OUT / 'rootfs')], env=env, check=True)
