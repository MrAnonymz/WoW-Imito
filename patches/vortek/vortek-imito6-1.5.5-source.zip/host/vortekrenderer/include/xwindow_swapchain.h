#ifndef VORTEK_XWINDOW_SWAPCHAIN_H
#define VORTEK_XWINDOW_SWAPCHAIN_H

#include <android/hardware_buffer.h>

#include "vortek.h"

typedef struct XWindowSwapchain_Image {
    VkImage image;
    VkDeviceMemory memory;
} XWindowSwapchain_Image;

typedef struct XWindowSwapchain {
    int windowId;
    XWindowSwapchain_Image* images;
    int imageCount;
    VkFormat imageFormat;
    VkExtent2D imageExtent;
    VkImageUsageFlags imageUsage;
    VkQueue queue;
    VkDevice device;
    VkFence presentFence;
    bool presentFencePending;
    bool presentFailureReported;
    JMethods* jmethods;
    bool firstPresentReported;
    bool acquireFailureReported;
} XWindowSwapchain;

/* Bounded startup evidence only. Values are shared with GameRuntimeEvidence. */
enum SwapchainStartupStage { SWAPCHAIN_REQUEST=1, SWAPCHAIN_AHB=2,
    SWAPCHAIN_IMAGE=3, SWAPCHAIN_AHB_PROPERTIES=4, SWAPCHAIN_MEMORY_TYPE=5,
    SWAPCHAIN_MEMORY_ALLOCATE=6, SWAPCHAIN_MEMORY_BIND=7,
    SWAPCHAIN_READY=8, SWAPCHAIN_FIRST_PRESENT=9, SWAPCHAIN_EXTENT=10,
    SWAPCHAIN_ACQUIRE_SUBMIT=12, SWAPCHAIN_PRESENT_SUBMIT=13,
    SWAPCHAIN_PRESENT_WAIT=14, SWAPCHAIN_PRESENT_INDEX=15,
    SWAPCHAIN_PRESENT_FENCE=16, SWAPCHAIN_PRESENT_TIMEOUT=17,
    VULKAN_DEVICE_CREATE=18 };
extern void reportSwapchainStartup(JMethods* methods, int stage, VkResult result,
        VkFormat format, VkExtent2D extent, int windowId);

extern void getWindowExtent(JMethods* jmethods, int windowId, VkExtent2D* extent);
extern int getSurfaceMinImageCount();
extern VkSurfaceFormatKHR* getSurfaceFormats(uint32_t* formatCount);

extern XWindowSwapchain* XWindowSwapchain_create(VkDevice device, uint32_t graphicsQueueIndex, VkSwapchainCreateInfoKHR* swapchainInfo, JMethods* jmethods, int windowId);
extern void XWindowSwapchain_destroy(VkDevice device, XWindowSwapchain* swapchain);
extern VkResult XWindowSwapchain_acquireNextImage(XWindowSwapchain* swapchain, uint64_t timeout, VkSemaphore signalSemaphore, VkFence fence, uint32_t* imageIndex);
extern void XWindowSwapchain_presentImage(XWindowSwapchain* swapchain);
extern VkResult XWindowSwapchain_waitForPresent(VkQueue queue, const VkPresentInfoKHR* presentInfo,
        const _Atomic VkResult* contextStatus);

#endif
