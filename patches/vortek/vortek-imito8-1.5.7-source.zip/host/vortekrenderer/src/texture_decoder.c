#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include "texture_decoder.h"
#include "vulkan_helper.h"
#include "bc_decoder.h"
#include "string_utils.h"
#include "file_utils.h"

#define CACHE_DIR APP_CACHE_DIR "/vortek"
#define CACHE_MIN_IMAGE_WIDTH 1024

bool TextureDecoder_canDecode(VkFormat format) {
    switch (format) {
        case VK_FORMAT_BC1_RGB_UNORM_BLOCK:
        case VK_FORMAT_BC1_RGB_SRGB_BLOCK:
        case VK_FORMAT_BC1_RGBA_UNORM_BLOCK:
        case VK_FORMAT_BC1_RGBA_SRGB_BLOCK:
        case VK_FORMAT_BC2_UNORM_BLOCK:
        case VK_FORMAT_BC2_SRGB_BLOCK:
        case VK_FORMAT_BC3_UNORM_BLOCK:
        case VK_FORMAT_BC3_SRGB_BLOCK:
        case VK_FORMAT_BC4_UNORM_BLOCK:
        case VK_FORMAT_BC4_SNORM_BLOCK:
        case VK_FORMAT_BC5_UNORM_BLOCK:
        case VK_FORMAT_BC5_SNORM_BLOCK:
            return true;
        default:
            return false;
    }
}

static int indexOfBoundBuffer(TextureDecoder* textureDecoder, VkBuffer buffer) {
    for (int i = 0; i < textureDecoder->boundBuffers.size; i++) {
        TextureDecoder_BoundBuffer* current = textureDecoder->boundBuffers.elements[i];
        if (current->buffer == buffer) return i;
    }
    return -1;
}

static int indexOfImage(TextureDecoder* textureDecoder, VkImage image) {
    for (int i = 0; i < textureDecoder->images.size; i++) {
        TextureDecoder_Image* current = textureDecoder->images.elements[i];
        if (current->image == image) return i;
    }
    return -1;
}

static void invalidatePendingCopies(TextureDecoder* textureDecoder,
        TextureDecoder_BoundBuffer* buffer, TextureDecoder_Image* image) {
    // Recorded commands may be discarded without ever submitting them. Resource
    // destruction must invalidate our deferred CPU work before freeing metadata.
    // Keep recording ownership: reset/free releases staging, decode skips invalid copies.
    ArrayDeque* copies = &textureDecoder->bufferImageCopies;
    for (int i = copies->head; i != copies->tail; i = (i + 1) & (copies->size - 1)) {
        TextureDecoder_BufferImageCopy* copy = copies->elements[i];
        if (!copy) continue;
        if (buffer && copy->srcBuffer == buffer) copy->srcBuffer = NULL;
        if (image && copy->dstImage == image) copy->dstImage = NULL;
    }
}

static void getBCInfo(VkFormat format, int* bcN, int* blockSize, bool* isNoAlphaU) {
    *isNoAlphaU = false;
    switch (format) {
        case VK_FORMAT_BC1_RGB_UNORM_BLOCK:
        case VK_FORMAT_BC1_RGB_SRGB_BLOCK:
            *isNoAlphaU = true;
        case VK_FORMAT_BC1_RGBA_UNORM_BLOCK:
        case VK_FORMAT_BC1_RGBA_SRGB_BLOCK:
            *blockSize = 8;
            *bcN = 1;
            break;
        case VK_FORMAT_BC2_UNORM_BLOCK:
        case VK_FORMAT_BC2_SRGB_BLOCK:
            *blockSize = 16;
            *bcN = 2;
            break;
        case VK_FORMAT_BC3_UNORM_BLOCK:
        case VK_FORMAT_BC3_SRGB_BLOCK:
            *blockSize = 16;
            *bcN = 3;
            break;
        case VK_FORMAT_BC4_UNORM_BLOCK:
            *isNoAlphaU = true;
        case VK_FORMAT_BC4_SNORM_BLOCK:
            *blockSize = 8;
            *bcN = 4;
            break;
        case VK_FORMAT_BC5_UNORM_BLOCK:
            *isNoAlphaU = true;
        case VK_FORMAT_BC5_SNORM_BLOCK:
            *blockSize = 16;
            *bcN = 5;
            break;
        default:
            *blockSize = 0;
            *bcN = 0;
            break;
    }
}

static void internalDestroyImage(VkDevice device, TextureDecoder_Image* targetImage) {
    if (targetImage->decompressedData) vulkanWrapper.vkUnmapMemory(device, targetImage->memory);
    if (targetImage->image) vulkanWrapper.vkDestroyImage(device, targetImage->image, NULL);
    if (targetImage->buffer) vulkanWrapper.vkDestroyBuffer(device, targetImage->buffer, NULL);
    if (targetImage->memory) vulkanWrapper.vkFreeMemory(device, targetImage->memory, NULL);
    MEMFREE(targetImage);
}

static TextureDecoder_Command* findCommand(TextureDecoder* decoder, VkCommandBuffer command) {
    for (int i = 0; i < decoder->commands.size; ++i) {
        TextureDecoder_Command* entry = decoder->commands.elements[i];
        if (entry->handle == command) return entry;
    }
    return NULL;
}

void TextureDecoder_resetCommand(TextureDecoder* decoder, VkCommandBuffer command, bool remove) {
    ArrayDeque* copies = &decoder->bufferImageCopies;
    int count = copies->size ? (copies->tail - copies->head) & (copies->size - 1) : 0;
    for (int i = 0; i < count; ++i) {
        TextureDecoder_BufferImageCopy* copy = ArrayDeque_removeFirst(copies);
        if (copy->commandBuffer != command) { ArrayDeque_addLast(copies, copy); continue; }
        MEMFREE(copy);
    }
    for (int i = 0; i < decoder->commands.size; ++i) {
        TextureDecoder_Command* entry = decoder->commands.elements[i];
        if (entry->handle != command) continue;
        ArrayList_free(&entry->secondary, false);
        for (int j = 0; j < entry->staging.size; ++j) {
            TextureDecoder_Image* staging = entry->staging.elements[j];
            internalDestroyImage(staging->device, staging);
        }
        ArrayList_free(&entry->staging, false);
        entry->result = VK_SUCCESS;
        if (remove) { MEMFREE(entry); ArrayList_removeAt(&decoder->commands, i); }
        return;
    }
}

void TextureDecoder_resetPool(TextureDecoder* decoder, VkCommandPool pool, bool remove) {
    for (int i = decoder->commands.size - 1; i >= 0; --i) {
        TextureDecoder_Command* entry = decoder->commands.elements[i];
        if (entry->pool == pool) TextureDecoder_resetCommand(decoder, entry->handle, remove);
    }
}

void TextureDecoder_registerCommands(TextureDecoder* decoder, VkCommandPool pool,
        uint32_t count, const VkCommandBuffer* commands) {
    for (uint32_t i = 0; i < count; ++i) {
        TextureDecoder_resetCommand(decoder, commands[i], true);
        TextureDecoder_Command* entry = calloc(1, sizeof(*entry));
        if (!entry) continue; // decodeCommands reports a missing registration as allocation failure.
        entry->handle = commands[i]; entry->pool = pool;
        ArrayList_add(&decoder->commands, entry);
    }
}

void TextureDecoder_executeCommands(TextureDecoder* decoder, VkCommandBuffer command,
        uint32_t count, const VkCommandBuffer* secondary) {
    TextureDecoder_Command* entry = findCommand(decoder, command);
    if (entry) for (uint32_t i = 0; i < count; ++i) ArrayList_add(&entry->secondary, secondary[i]);
}

static VkResult allocateStaging(TextureDecoder_Image* staging) {
    VkBufferCreateInfo bufferInfo = {.sType=VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
            .size=staging->layout.size, .usage=VK_BUFFER_USAGE_TRANSFER_SRC_BIT};
    VkResult result = vulkanWrapper.vkCreateBuffer(staging->device, &bufferInfo, NULL, &staging->buffer);
    if (result != VK_SUCCESS) return result;
    VkMemoryRequirements requirements;
    vulkanWrapper.vkGetBufferMemoryRequirements(staging->device, staging->buffer, &requirements);
    uint32_t type = getMemoryTypeIndex(requirements.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);
    if (type >= 32 || !(requirements.memoryTypeBits & (1u << type)) ||
            !(getMemoryPropertyFlags(type) & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) return VK_ERROR_OUT_OF_DEVICE_MEMORY;
    staging->coherent = (getMemoryPropertyFlags(type) & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT) != 0;
    VkMemoryAllocateInfo allocation = {.sType=VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
            .allocationSize=requirements.size, .memoryTypeIndex=type};
    result = vulkanWrapper.vkAllocateMemory(staging->device, &allocation, NULL, &staging->memory);
    if (result != VK_SUCCESS) return result;
    result = vulkanWrapper.vkBindBufferMemory(staging->device, staging->buffer, staging->memory, 0);
    if (result != VK_SUCCESS) return result;
    return vulkanWrapper.vkMapMemory(staging->device, staging->memory, 0, VK_WHOLE_SIZE, 0, &staging->decompressedData);
}

static VkResult reserveStaging(TextureDecoder_Command* command, VkDevice device,
        VkDeviceSize bytes, TextureDecoder_BufferImageCopy* copy) {
    TextureDecoder_Image* block = command->staging.size ?
            command->staging.elements[command->staging.size - 1] : NULL;
    if (!block || bytes > block->layout.size - block->usedSize) {
        // Suballocate compact uploads instead of one vkAllocateMemory per mip.
        // The command owns every block until reset/free, including unused commands.
        VkDeviceSize capacity = block ? MIN(block->layout.size * 2, (VkDeviceSize)4 << 20) : 65536;
        if (capacity < bytes) capacity = bytes;
        block = calloc(1, sizeof(*block));
        if (!block) return VK_ERROR_OUT_OF_HOST_MEMORY;
        block->device = device; block->layout.size = capacity;
        VkResult result = allocateStaging(block);
        if (result != VK_SUCCESS) { internalDestroyImage(device, block); return result; }
        ArrayList_add(&command->staging, block);
    }
    // Every decoded texel is four bytes, so adjacent regions satisfy the buffer
    // offset alignment without sharing any writable upload bytes.
    copy->staging = block; copy->stagingOffset = block->usedSize;
    block->usedSize += bytes;
    return VK_SUCCESS;
}

static bool readCachedImage(TextureDecoder_Image* image, uint64_t hash) {
    char filename[128] = {0};
    sprintf(filename, CACHE_DIR "/bc2-%lx-%dx%d-%d.imd", hash, image->width, image->height, image->format);

    createDirectory(CACHE_DIR);
    size_t size = image->width * image->height * 4;
    return fileGetContents(filename, image->decompressedData, &size) &&
           size == (size_t)image->width * image->height * 4;
}

static void writeImageToCache(TextureDecoder* textureDecoder, TextureDecoder_Image* image, uint64_t hash) {
    if (textureDecoder->imageCacheSize == 0) return;
    createDirectory(CACHE_DIR);

    char* content = fileGetContents(CACHE_DIR "/.cache-size", NULL, NULL);
    uint64_t currentCacheSize = 0;
    if (content) {
        currentCacheSize = strtoll(content, NULL, 10);
        MEMFREE(content);
    }

    uint64_t maxCacheSize = (uint64_t)textureDecoder->imageCacheSize << 20;
    while (currentCacheSize > maxCacheSize) {
        FindFileInfo fileInfo = {0};
        if (findFirstFile(CACHE_DIR, &fileInfo) && remove(fileInfo.path) == 0) {
            currentCacheSize -= fileInfo.size;
        }
        else return;
    }

    char filename[128] = {0};
    sprintf(filename, CACHE_DIR "/bc2-%lx-%dx%d-%d.imd", hash, image->width, image->height, image->format);
    size_t size = image->width * image->height * 4;

    bool success = false;
    if (filePutContents(filename, image->decompressedData, size)) {
        currentCacheSize += size;
        char value[32] = {0};
        sprintf(value, "%ld", currentCacheSize);
        success = filePutContents(CACHE_DIR "/.cache-size", value, strlen(value));
    }

    if (!success) remove(filename);
}

TextureDecoder* TextureDecoder_create(VkContext* context, VkPhysicalDevice physicalDevice, VkPhysicalDeviceFeatures* supportedFeatures) {
    if (supportedFeatures->textureCompressionBC) return NULL;
    TextureDecoder* textureDecoder = calloc(1, sizeof(TextureDecoder));
    textureDecoder->imageCacheSize = context->imageCacheSize;
    textureDecoder->threadPool = context->threadPool;
    // Some drivers support individual BC formats without the all-BC feature.
    // Query the real formats on every vendor; the supported hardware path is
    // unchanged, and only missing formats go through software decoding.
    {
        const VkFormatFeatureFlags required = VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT |
                VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT |
                VK_FORMAT_FEATURE_TRANSFER_SRC_BIT | VK_FORMAT_FEATURE_TRANSFER_DST_BIT;
        for (int format = VK_FORMAT_BC1_RGB_UNORM_BLOCK; format <= VK_FORMAT_BC5_SNORM_BLOCK; format++) {
            VkFormatProperties properties = {0};
            vulkanWrapper.vkGetPhysicalDeviceFormatProperties(physicalDevice, format, &properties);
            if ((properties.optimalTilingFeatures & required) == required)
                textureDecoder->nativeBCFormats |= 1u << (format - VK_FORMAT_BC1_RGB_UNORM_BLOCK);
        }
    }
    return textureDecoder;
}

VkFormat TextureDecoder_decodedFormat(VkFormat format) {
    switch (format) {
        case VK_FORMAT_BC1_RGB_SRGB_BLOCK:
        case VK_FORMAT_BC1_RGBA_SRGB_BLOCK:
        case VK_FORMAT_BC2_SRGB_BLOCK:
        case VK_FORMAT_BC3_SRGB_BLOCK: return VK_FORMAT_B8G8R8A8_SRGB;
        case VK_FORMAT_BC4_SNORM_BLOCK:
        case VK_FORMAT_BC5_SNORM_BLOCK: return VK_FORMAT_R8G8B8A8_SNORM;
        case VK_FORMAT_BC4_UNORM_BLOCK:
        case VK_FORMAT_BC5_UNORM_BLOCK: return VK_FORMAT_R8G8B8A8_UNORM;
        default: return DECOMPRESSED_FORMAT;
    }
}

bool TextureDecoder_needsDecode(TextureDecoder* textureDecoder, VkFormat format) {
    // Do not divert native ETC/ASTC/BC6/BC7 images into a BC1-5 decoder.
    if (!TextureDecoder_canDecode(format)) return false;
    if (format >= VK_FORMAT_BC1_RGB_UNORM_BLOCK && format <= VK_FORMAT_BC5_SNORM_BLOCK &&
            (textureDecoder->nativeBCFormats & (1u << (format - VK_FORMAT_BC1_RGB_UNORM_BLOCK))))
        return false;
    return true;
}

void TextureDecoder_destroy(TextureDecoder* textureDecoder) {
    // Context teardown has stopped workers; release the remaining host metadata.
    // The Vulkan device owns remaining GPU objects and is torn down separately.
    for (int i = 0; i < textureDecoder->commands.size; ++i) {
        TextureDecoder_Command* command = textureDecoder->commands.elements[i];
        ArrayList_free(&command->secondary, false);
        ArrayList_free(&command->staging, true);
    }
    ArrayList_free(&textureDecoder->commands, true);
    ArrayList_free(&textureDecoder->images, true);
    ArrayList_free(&textureDecoder->boundBuffers, true);
    ArrayDeque_free(&textureDecoder->bufferImageCopies, true);
    MEMFREE(textureDecoder);
}

static VkResult decodeCommand(TextureDecoder* textureDecoder, VkCommandBuffer handle) {
    TextureDecoder_Command* command = findCommand(textureDecoder, handle);
    if (!command) return VK_ERROR_OUT_OF_HOST_MEMORY;
    if (command->result != VK_SUCCESS) return command->result;
    if (command->decoding) return VK_ERROR_UNKNOWN;
    command->decoding = true;
    VkResult result = TextureDecoder_decodeCommands(textureDecoder, command->secondary.size,
            (const VkCommandBuffer*)command->secondary.elements);
    command->decoding = false;
    if (result != VK_SUCCESS) return result;
    ArrayDeque* copies = &textureDecoder->bufferImageCopies;
    for (int index = copies->head; index != copies->tail; index = (index + 1) & (copies->size - 1)) {
        TextureDecoder_BufferImageCopy* bufferImageCopy = copies->elements[index];
        if (!bufferImageCopy || bufferImageCopy->commandBuffer != handle) continue;

        TextureDecoder_BoundBuffer* srcBuffer = bufferImageCopy->srcBuffer;
        TextureDecoder_Image* dstImage = bufferImageCopy->dstImage;
        TextureDecoder_Image* staging = bufferImageCopy->staging;
        VkBufferImageCopy region = bufferImageCopy->region;

        if (!srcBuffer || !dstImage || !staging) continue;
        TextureDecoder_Image decoded = {.width=region.imageExtent.width, .height=region.imageExtent.height,
                .format=dstImage->format, .decompressedData=(uint8_t*)staging->decompressedData + bufferImageCopy->stagingOffset};

        int blockSize;
        int bcN;
        bool isNoAlphaU;
        getBCInfo(dstImage->format, &bcN, &blockSize, &isNoAlphaU);
        TextureCopyLayout copy;
        if (srcBuffer->memoryOffset > srcBuffer->memory->allocationSize ||
                !TextureCopy_regionLayout(&dstImage->layout, &region, blockSize,
                    srcBuffer->memory->allocationSize - srcBuffer->memoryOffset, &copy)) return VK_ERROR_MEMORY_MAP_FAILED;
        void* data = mmap(NULL, srcBuffer->memory->allocationSize, PROT_READ, MAP_SHARED, srcBuffer->memory->fd, 0);
        if (data == MAP_FAILED) return VK_ERROR_MEMORY_MAP_FAILED;
        const uint8_t* imageData = (const uint8_t*)data + srcBuffer->memoryOffset + copy.sourceOffset;

        uint64_t hash = 0;
        bool isCachedImage = false;
        if (region.imageSubresource.mipLevel == 0 && dstImage->layout.arrayLayers == 1 &&
                dstImage->layout.depth == 1 && region.imageOffset.x == 0 && region.imageOffset.y == 0 &&
                region.imageExtent.width == dstImage->width && region.imageExtent.height == dstImage->height &&
                !region.bufferRowLength && !region.bufferImageHeight &&
                dstImage->width >= CACHE_MIN_IMAGE_WIDTH && dstImage->height >= CACHE_MIN_IMAGE_WIDTH) {
            size_t memorySize = ((dstImage->width + 3) / 4) * ((dstImage->height + 3) / 4) * blockSize;
            hash = murmurHash64((const char*)imageData, memorySize, dstImage->format);
            isCachedImage = readCachedImage(&decoded, hash);
        }

        if (!isCachedImage) {
            for (uint32_t layer = 0; layer < region.imageSubresource.layerCount; layer++) {
                for (uint32_t z = 0; z < region.imageExtent.depth; z++) {
                    const uint8_t* source = imageData + layer * copy.sourceLayerPitch + z * copy.sourceSlicePitch;
                    const size_t rowPitch = (size_t)region.imageExtent.width * 4;
                    const size_t slicePitch = rowPitch * region.imageExtent.height;
                    uint8_t* target = (uint8_t*)decoded.decompressedData +
                            (layer * region.imageExtent.depth + z) * slicePitch;
                    // BC4/5 have no B/alpha channel: preserve their Vulkan defaults.
                    if (bcN >= 4) {
                        for (uint32_t y = 0; y < region.imageExtent.height; y++)
                            for (uint32_t x = 0; x < region.imageExtent.width; x++) {
                                uint8_t* p = target + y * rowPitch + x * 4;
                                p[0] = p[1] = p[2] = 0; p[3] = isNoAlphaU ? 255 : 127;
                            }
                    }
                    BCDecoder_decodeStrided(source, target, region.imageExtent.width, region.imageExtent.height,
                            copy.sourceRowPitch, rowPitch, bcN, isNoAlphaU, textureDecoder->threadPool);
                }
            }
            if (hash > 0) writeImageToCache(textureDecoder, &decoded, hash);
        }

        munmap(data, srcBuffer->memory->allocationSize);
    }
    for (int i = 0; i < command->staging.size; ++i) {
        TextureDecoder_Image* staging = command->staging.elements[i];
        if (!staging->coherent) {
            VkMappedMemoryRange range = {.sType=VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE,
                    .memory=staging->memory, .offset=0, .size=VK_WHOLE_SIZE};
            result = vulkanWrapper.vkFlushMappedMemoryRanges(staging->device, 1, &range);
            if (result != VK_SUCCESS) return result;
        }
    }
    return VK_SUCCESS;
}

VkResult TextureDecoder_decodeCommands(TextureDecoder* decoder, uint32_t count, const VkCommandBuffer* commands) {
    for (uint32_t i = 0; i < count; ++i) {
        VkResult result = decodeCommand(decoder, commands[i]);
        if (result != VK_SUCCESS) return result;
    }
    return VK_SUCCESS;
}

void TextureDecoder_copyBufferToImage(TextureDecoder* textureDecoder, VkCommandBuffer commandBuffer, VkBuffer srcBuffer, VkImage dstImage, VkImageLayout dstImageLayout, uint32_t regionCount, const VkBufferImageCopy* regions) {
    TextureDecoder_Command* command = findCommand(textureDecoder, commandBuffer);
    if (!command || command->result != VK_SUCCESS) return;
    int index = indexOfBoundBuffer(textureDecoder, srcBuffer);
    if (index == -1) return;
    TextureDecoder_BoundBuffer* boundBuffer = textureDecoder->boundBuffers.elements[index];

    index = indexOfImage(textureDecoder, dstImage);
    if (index == -1) return;
    TextureDecoder_Image* targetImage = textureDecoder->images.elements[index];

    int bcN, blockSize;
    bool noAlpha;
    getBCInfo(targetImage->format, &bcN, &blockSize, &noAlpha);
    for (uint32_t i = 0; i < regionCount; i++) {
        TextureCopyLayout copy;
        if (boundBuffer->memoryOffset > boundBuffer->memory->allocationSize ||
                !TextureCopy_regionLayout(&targetImage->layout, &regions[i], blockSize,
                    boundBuffer->memory->allocationSize - boundBuffer->memoryOffset, &copy)) continue;
        TextureDecoder_BufferImageCopy* pending = calloc(1, sizeof(*pending));
        if (!pending) { command->result = VK_ERROR_OUT_OF_HOST_MEMORY; return; }
        TextureCopyImageLayout layout;
        if (!TextureCopy_imageLayout(&layout, regions[i].imageExtent.width, regions[i].imageExtent.height,
                regions[i].imageExtent.depth, 1, regions[i].imageSubresource.layerCount)) {
            command->result = VK_ERROR_OUT_OF_DEVICE_MEMORY;
        } else command->result = reserveStaging(command, targetImage->device, layout.size, pending);
        if (command->result != VK_SUCCESS) {
            MEMFREE(pending); return;
        }
        pending->commandBuffer = commandBuffer;
        pending->srcBuffer = boundBuffer;
        pending->dstImage = targetImage;
        pending->region = regions[i];
        ArrayDeque_addLast(&textureDecoder->bufferImageCopies, pending);
        // Every upload has a distinct range until command reset/free. Sharing
        // the same bytes per image overwrites earlier copies before the GPU runs.
        VkBufferImageCopy decoded = regions[i];
        decoded.bufferOffset = pending->stagingOffset; decoded.bufferRowLength = 0; decoded.bufferImageHeight = 0;
        vulkanWrapper.vkCmdCopyBufferToImage(commandBuffer, pending->staging->buffer, dstImage, dstImageLayout, 1, &decoded);
    }
}

bool TextureDecoder_containsImage(TextureDecoder* textureDecoder, VkImage image) {
    return indexOfImage(textureDecoder, image) != -1;
}

VkResult TextureDecoder_createImage(TextureDecoder* textureDecoder, VkDevice device, VkImageCreateInfo* imageInfo, VkImage* pImage) {
    *pImage = VK_NULL_HANDLE;
    VkResult result;
    if (!TextureDecoder_canDecode(imageInfo->format)) return VK_ERROR_FORMAT_NOT_SUPPORTED;

    TextureDecoder_Image* newImage = calloc(1, sizeof(TextureDecoder_Image));
    if (!newImage) return VK_ERROR_OUT_OF_HOST_MEMORY;
    newImage->format = imageInfo->format;
    newImage->width = imageInfo->extent.width;
    newImage->height = imageInfo->extent.height;
    newImage->device = device;
    if (!TextureCopy_imageLayout(&newImage->layout, imageInfo->extent.width, imageInfo->extent.height,
            imageInfo->extent.depth, imageInfo->mipLevels, imageInfo->arrayLayers)) {
        MEMFREE(newImage);
        return VK_ERROR_FORMAT_NOT_SUPPORTED;
    }

    imageInfo->format = TextureDecoder_decodedFormat(imageInfo->format);
    imageInfo->flags &= ~VK_IMAGE_CREATE_BLOCK_TEXEL_VIEW_COMPATIBLE_BIT;

    VkImageFormatListCreateInfo* formatListInfo = findNextVkStructure((void*)imageInfo->pNext, VK_STRUCTURE_TYPE_IMAGE_FORMAT_LIST_CREATE_INFO);
    if (formatListInfo && formatListInfo->pViewFormats) {
        VkFormat* viewFormats = (VkFormat*)formatListInfo->pViewFormats;
        for (uint32_t i = 0; i < formatListInfo->viewFormatCount; i++)
            viewFormats[i] = TextureDecoder_decodedFormat(viewFormats[i]);
    }

    result = vulkanWrapper.vkCreateImage(device, imageInfo, NULL, &newImage->image);
    if (result != VK_SUCCESS) goto error;

    ArrayList_add(&textureDecoder->images, newImage);

    *pImage = newImage->image;
    return result;

error:
    internalDestroyImage(device, newImage);
    return result;
}

void TextureDecoder_destroyImage(TextureDecoder* textureDecoder, VkDevice device, VkImage image) {
    int index = indexOfImage(textureDecoder, image);
    if (index != -1) {
        TextureDecoder_Image* targetImage = textureDecoder->images.elements[index];
        invalidatePendingCopies(textureDecoder, NULL, targetImage);
        internalDestroyImage(device, targetImage);
        ArrayList_removeAt(&textureDecoder->images, index);
    }
}

void TextureDecoder_addBoundBuffer(TextureDecoder* textureDecoder, ResourceMemory* memory, VkBuffer buffer, VkDeviceSize memoryOffset) {
    if (memory->fd < 0) return;
    TextureDecoder_removeBoundBuffer(textureDecoder, buffer);

    TextureDecoder_BoundBuffer* boundBuffer = calloc(1, sizeof(TextureDecoder_BoundBuffer));
    if (!boundBuffer) return;
    boundBuffer->buffer = buffer;
    boundBuffer->memoryOffset = memoryOffset;
    boundBuffer->memory = memory;

    ArrayList_add(&textureDecoder->boundBuffers, boundBuffer);
}

void TextureDecoder_removeBoundBuffer(TextureDecoder* textureDecoder, VkBuffer buffer) {
    int index = indexOfBoundBuffer(textureDecoder, buffer);
    if (index != -1) {
        TextureDecoder_BoundBuffer* boundBuffer = textureDecoder->boundBuffers.elements[index];
        invalidatePendingCopies(textureDecoder, boundBuffer, NULL);
        MEMFREE(boundBuffer);
        ArrayList_removeAt(&textureDecoder->boundBuffers, index);
    }
}

void TextureDecoder_removeBoundMemory(TextureDecoder* textureDecoder, ResourceMemory* memory) {
    // Vulkan permits freeing memory before destroying its bound buffers. Such
    // buffers are unusable, including by copies left over from discarded work.
    for (int i = textureDecoder->boundBuffers.size - 1; i >= 0; i--) {
        TextureDecoder_BoundBuffer* buffer = textureDecoder->boundBuffers.elements[i];
        if (buffer->memory != memory) continue;
        invalidatePendingCopies(textureDecoder, buffer, NULL);
        MEMFREE(buffer);
        ArrayList_removeAt(&textureDecoder->boundBuffers, i);
    }
}

bool isCompressedFormat(VkFormat format) {
    switch(format) {
        case VK_FORMAT_BC1_RGB_UNORM_BLOCK:
        case VK_FORMAT_BC1_RGB_SRGB_BLOCK:
        case VK_FORMAT_BC1_RGBA_UNORM_BLOCK:
        case VK_FORMAT_BC1_RGBA_SRGB_BLOCK:
        case VK_FORMAT_BC2_UNORM_BLOCK:
        case VK_FORMAT_BC2_SRGB_BLOCK:
        case VK_FORMAT_BC3_UNORM_BLOCK:
        case VK_FORMAT_BC3_SRGB_BLOCK:
        case VK_FORMAT_BC4_UNORM_BLOCK:
        case VK_FORMAT_BC4_SNORM_BLOCK:
        case VK_FORMAT_BC5_UNORM_BLOCK:
        case VK_FORMAT_BC5_SNORM_BLOCK:
        case VK_FORMAT_BC6H_UFLOAT_BLOCK:
        case VK_FORMAT_BC6H_SFLOAT_BLOCK:
        case VK_FORMAT_BC7_UNORM_BLOCK:
        case VK_FORMAT_BC7_SRGB_BLOCK:
        case VK_FORMAT_ETC2_R8G8B8_UNORM_BLOCK:
        case VK_FORMAT_ETC2_R8G8B8_SRGB_BLOCK:
        case VK_FORMAT_ETC2_R8G8B8A1_UNORM_BLOCK:
        case VK_FORMAT_ETC2_R8G8B8A1_SRGB_BLOCK:
        case VK_FORMAT_ETC2_R8G8B8A8_UNORM_BLOCK:
        case VK_FORMAT_ETC2_R8G8B8A8_SRGB_BLOCK:
        case VK_FORMAT_EAC_R11_UNORM_BLOCK:
        case VK_FORMAT_EAC_R11_SNORM_BLOCK:
        case VK_FORMAT_EAC_R11G11_UNORM_BLOCK:
        case VK_FORMAT_EAC_R11G11_SNORM_BLOCK:
        case VK_FORMAT_ASTC_4x4_UNORM_BLOCK:
        case VK_FORMAT_ASTC_4x4_SRGB_BLOCK:
        case VK_FORMAT_ASTC_5x4_UNORM_BLOCK:
        case VK_FORMAT_ASTC_5x4_SRGB_BLOCK:
        case VK_FORMAT_ASTC_5x5_UNORM_BLOCK:
        case VK_FORMAT_ASTC_5x5_SRGB_BLOCK:
        case VK_FORMAT_ASTC_6x5_UNORM_BLOCK:
        case VK_FORMAT_ASTC_6x5_SRGB_BLOCK:
        case VK_FORMAT_ASTC_6x6_UNORM_BLOCK:
        case VK_FORMAT_ASTC_6x6_SRGB_BLOCK:
        case VK_FORMAT_ASTC_8x5_UNORM_BLOCK:
        case VK_FORMAT_ASTC_8x5_SRGB_BLOCK:
        case VK_FORMAT_ASTC_8x6_UNORM_BLOCK:
        case VK_FORMAT_ASTC_8x6_SRGB_BLOCK:
        case VK_FORMAT_ASTC_8x8_UNORM_BLOCK:
        case VK_FORMAT_ASTC_8x8_SRGB_BLOCK:
        case VK_FORMAT_ASTC_10x5_UNORM_BLOCK:
        case VK_FORMAT_ASTC_10x5_SRGB_BLOCK:
        case VK_FORMAT_ASTC_10x6_UNORM_BLOCK:
        case VK_FORMAT_ASTC_10x6_SRGB_BLOCK:
        case VK_FORMAT_ASTC_10x8_UNORM_BLOCK:
        case VK_FORMAT_ASTC_10x8_SRGB_BLOCK:
        case VK_FORMAT_ASTC_10x10_UNORM_BLOCK:
        case VK_FORMAT_ASTC_10x10_SRGB_BLOCK:
        case VK_FORMAT_ASTC_12x10_UNORM_BLOCK:
        case VK_FORMAT_ASTC_12x10_SRGB_BLOCK:
        case VK_FORMAT_ASTC_12x12_UNORM_BLOCK:
        case VK_FORMAT_ASTC_12x12_SRGB_BLOCK:
            return true;
        default:
            return false;
    }
}

VkResult getCompressedImageFormatProperties(VkPhysicalDevice physicalDevice, VkFormat format,
        VkImageType type, VkImageTiling tiling, VkImageUsageFlags usage, VkImageCreateFlags flags,
        VkImageFormatProperties* properties) {
    const VkImageUsageFlags supportedUsage = VK_IMAGE_USAGE_SAMPLED_BIT |
            VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
    const VkImageCreateFlags supportedFlags = VK_IMAGE_CREATE_MUTABLE_FORMAT_BIT |
            VK_IMAGE_CREATE_CUBE_COMPATIBLE_BIT | VK_IMAGE_CREATE_BLOCK_TEXEL_VIEW_COMPATIBLE_BIT;
    if (!TextureDecoder_canDecode(format) || tiling != VK_IMAGE_TILING_OPTIMAL ||
            type != VK_IMAGE_TYPE_2D || (usage & ~supportedUsage) || (flags & ~supportedFlags))
        return VK_ERROR_FORMAT_NOT_SUPPORTED;
    VkImageFormatProperties decoded = {0};
    VkResult result = vulkanWrapper.vkGetPhysicalDeviceImageFormatProperties(physicalDevice,
            TextureDecoder_decodedFormat(format), type, tiling, usage,
            flags & ~VK_IMAGE_CREATE_BLOCK_TEXEL_VIEW_COMPATIBLE_BIT, &decoded);
    if (result != VK_SUCCESS) return result;
    // Bound decoder allocations by BOTH its own limits and this device's limits.
    decoded.maxExtent.width = MIN(decoded.maxExtent.width, 16384);
    decoded.maxExtent.height = MIN(decoded.maxExtent.height, 16384);
    decoded.maxExtent.depth = 1;
    decoded.maxMipLevels = MIN(decoded.maxMipLevels, 15);
    decoded.maxArrayLayers = MIN(decoded.maxArrayLayers, 2048);
    decoded.sampleCounts = VK_SAMPLE_COUNT_1_BIT;
    decoded.maxResourceSize = MIN(decoded.maxResourceSize, (VkDeviceSize)1 << 31);
    *properties = decoded;
    return VK_SUCCESS;
}
