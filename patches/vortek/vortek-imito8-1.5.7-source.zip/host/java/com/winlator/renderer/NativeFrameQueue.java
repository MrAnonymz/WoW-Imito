package com.winlator.renderer;

import java.util.ArrayDeque;

/** Ordered GL work with a composition boundary after each native Present. */
public final class NativeFrameQueue {
    private static final class Work {
        final Runnable task;
        final boolean present;
        Work(Runnable task, boolean present) { this.task = task; this.present = present; }
    }
    private final ArrayDeque<Work> pending = new ArrayDeque<>();
    private volatile Thread applyingFrameThread;

    public synchronized void add(Runnable task, boolean present) {
        if (task == null) throw new IllegalArgumentException("A GL task is required.");
        pending.addLast(new Work(task, present));
    }

    /** GL thread. Never run tasks while holding the queue's monitor. */
    public void beforeDraw() {
        applyingFrameThread = Thread.currentThread();
        try { applyFrameWork(); }
        finally { applyingFrameThread = null; }
    }

    /** A synchronous content notification here is already part of this draw.
     * Other threads must still be able to request a later frame concurrently.
     */
    public boolean isApplyingCurrentFrame() {
        return applyingFrameThread == Thread.currentThread();
    }

    private void applyFrameWork() {
        final int available;
        synchronized (this) { available = pending.size(); }
        for (int i = 0; i < available; i++) {
            final Work next;
            synchronized (this) { next = pending.pollFirst(); }
            if (next == null) return;
            next.task.run();
            // Preserve order with texture retirement/scene changes, but do not
            // overwrite this frame with the next one before it is composed.
            if (next.present) return;
        }
    }

    public synchronized boolean hasPending() { return !pending.isEmpty(); }
}
