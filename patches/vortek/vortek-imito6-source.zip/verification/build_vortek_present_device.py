"""Build a small Android31+ Vulkan semaphore smoke test; never access a phone.

Executes the production acquire/present helpers on the system Vulkan driver.
It tests real synchronization and timings, not game pixels or Mali hardware.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT/'apk-source/app/src/main/cpp/vortekrenderer'
OUT = ROOT/'testovanie/154/vortek-present/device'
OUT.mkdir(parents=True, exist_ok=True)

def function(text, name):
    m = re.search(r'^(?:static\s+)?[A-Za-z_][A-Za-z0-9_* \t]*\b'+name+r'\(', text, re.M)
    start=m.start(); end=text.index('{', start)+1; depth=1
    while depth:
        depth+=(text[end]=='{')-(text[end]=='}'); end+=1
    return text[start:end]

header=(SRC/'include/xwindow_swapchain.h').read_text('utf-8')
structs=header[header.index('typedef struct XWindowSwapchain_Image'):header.index('/* Bounded startup evidence')]
enums=header[header.index('enum SwapchainStartupStage'):header.index('extern void reportSwapchainStartup')]
source=(SRC/'src/xwindow_swapchain.c').read_text('utf-8')
code=r'''
#define VK_NO_PROTOTYPES 1
#include "vulkan/vulkan_core.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <time.h>
typedef struct {int unused;} JMethods;
''' + structs + enums + r'''
static struct {PFN_vkQueueSubmit vkQueueSubmit;PFN_vkCreateFence vkCreateFence;
    PFN_vkResetFences vkResetFences;PFN_vkWaitForFences vkWaitForFences;} vulkanWrapper;
static void getWindowExtent(JMethods* j,int window,VkExtent2D* e){*e=(VkExtent2D){1280,720};}
static void reportSwapchainStartup(JMethods* j,int stage,VkResult result,VkFormat f,VkExtent2D e,int id){
    printf("diagnostic stage=%d result=%d\n",stage,result);
}
''' + '\n'.join(function(source,n) for n in ('failedSwapchainStep','failedPresentStep','XWindowSwapchain_waitForPresent','XWindowSwapchain_acquireNextImage')) + r'''
static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
#define CHECK(call) do {VkResult r=(call);if(r!=VK_SUCCESS){printf("FAIL line=%d result=%d\n",__LINE__,r);return 1;}}while(0)
#define INSTANCE_FN(name) PFN_##name name=(PFN_##name)get(instance,#name);if(!name)return 2
#define DEVICE_FN(name) PFN_##name name=(PFN_##name)vkGetDeviceProcAddr(device,#name);if(!name)return 2
int main(void){
    void* library=dlopen("libvulkan.so",RTLD_NOW|RTLD_LOCAL);if(!library)return 2;
    PFN_vkGetInstanceProcAddr get=(PFN_vkGetInstanceProcAddr)dlsym(library,"vkGetInstanceProcAddr");if(!get)return 2;
    PFN_vkCreateInstance create=(PFN_vkCreateInstance)get(VK_NULL_HANDLE,"vkCreateInstance");if(!create)return 2;
    VkApplicationInfo app={.sType=VK_STRUCTURE_TYPE_APPLICATION_INFO,.pApplicationName="ImitoPresentTest",.apiVersion=VK_API_VERSION_1_1};
    VkInstanceCreateInfo ci={.sType=VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,.pApplicationInfo=&app};VkInstance instance;
    CHECK(create(&ci,NULL,&instance));
    INSTANCE_FN(vkEnumeratePhysicalDevices);INSTANCE_FN(vkGetPhysicalDeviceQueueFamilyProperties);
    INSTANCE_FN(vkGetPhysicalDeviceProperties);INSTANCE_FN(vkCreateDevice);INSTANCE_FN(vkGetDeviceProcAddr);INSTANCE_FN(vkDestroyInstance);
    uint32_t count=8;VkPhysicalDevice physical[8];CHECK(vkEnumeratePhysicalDevices(instance,&count,physical));if(!count)return 2;
    VkPhysicalDeviceProperties properties;vkGetPhysicalDeviceProperties(physical[0],&properties);
    printf("device=%s api=%u driver=%u\n",properties.deviceName,properties.apiVersion,properties.driverVersion);
    uint32_t qcount=32;VkQueueFamilyProperties qp[32];vkGetPhysicalDeviceQueueFamilyProperties(physical[0],&qcount,qp);
    uint32_t family=UINT32_MAX;for(uint32_t i=0;i<qcount;i++)if(qp[i].queueCount && (qp[i].queueFlags&VK_QUEUE_GRAPHICS_BIT)){family=i;break;}
    if(family==UINT32_MAX)return 2;float priority=1;
    VkDeviceQueueCreateInfo qi={.sType=VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,.queueFamilyIndex=family,.queueCount=1,.pQueuePriorities=&priority};
    VkDeviceCreateInfo di={.sType=VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO,.queueCreateInfoCount=1,.pQueueCreateInfos=&qi};VkDevice device;
    CHECK(vkCreateDevice(physical[0],&di,NULL,&device));
    DEVICE_FN(vkQueueSubmit);DEVICE_FN(vkCreateFence);DEVICE_FN(vkResetFences);DEVICE_FN(vkWaitForFences);
    DEVICE_FN(vkCreateSemaphore);DEVICE_FN(vkDestroySemaphore);DEVICE_FN(vkDestroyFence);DEVICE_FN(vkGetDeviceQueue);DEVICE_FN(vkDestroyDevice);
    vulkanWrapper.vkQueueSubmit=vkQueueSubmit;vulkanWrapper.vkCreateFence=vkCreateFence;
    vulkanWrapper.vkResetFences=vkResetFences;vulkanWrapper.vkWaitForFences=vkWaitForFences;
    VkQueue queue;vkGetDeviceQueue(device,family,0,&queue);
    VkSemaphore sem[3];VkSemaphoreCreateInfo si={.sType=VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
    for(int i=0;i<3;i++)CHECK(vkCreateSemaphore(device,&si,NULL,&sem[i]));
    XWindowSwapchain swap[2]={{.device=device,.queue=queue,.imageCount=3,.windowId=91,.imageExtent={1280,720}},
        {.device=device,.queue=queue,.imageCount=3,.windowId=92,.imageExtent={1280,720}}};
    VkSwapchainKHR handles[2]={(VkSwapchainKHR)&swap[0],(VkSwapchainKHR)&swap[1]};uint32_t indices[2]={0,0};
    _Atomic VkResult status=VK_SUCCESS;VkPipelineStageFlags stage=VK_PIPELINE_STAGE_ALL_COMMANDS_BIT;
    const int frames=128;uint64_t start=now(),waitNs=0,maxWaitNs=0;
    for(int frame=0;frame<frames;frame++){
        uint32_t image=UINT32_MAX;CHECK(XWindowSwapchain_acquireNextImage(&swap[0],UINT64_MAX,sem[0],VK_NULL_HANDLE,&image));
        if(image!=0)return 3;
        VkSubmitInfo render={.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO,.waitSemaphoreCount=1,.pWaitSemaphores=sem,
            .pWaitDstStageMask=&stage,.signalSemaphoreCount=2,.pSignalSemaphores=sem+1};
        CHECK(vkQueueSubmit(queue,1,&render,VK_NULL_HANDLE));
        VkPresentInfoKHR present={.sType=VK_STRUCTURE_TYPE_PRESENT_INFO_KHR,.waitSemaphoreCount=2,.pWaitSemaphores=sem+1,
            .swapchainCount=2,.pSwapchains=handles,.pImageIndices=indices};
        uint64_t before=now();CHECK(XWindowSwapchain_waitForPresent(queue,&present,&status));
        uint64_t elapsed=now()-before;waitNs+=elapsed;if(elapsed>maxWaitNs)maxWaitNs=elapsed;
    }
    printf("PASS real Vulkan acquire/render/present %dframes,2binarywaits,2swapchainentries; batchMs=%.3f presentMeanUs=%.3f presentMaxUs=%.3f\n",
        frames,(now()-start)/1000000.0,waitNs/(frames*1000.0),maxWaitNs/1000.0);
    vkDestroyFence(device,swap[0].presentFence,NULL);
    for(int i=0;i<3;i++)vkDestroySemaphore(device,sem[i],NULL);
    vkDestroyDevice(device,NULL);vkDestroyInstance(instance,NULL);dlclose(library);return 0;
}
'''
c=OUT/'present-device.c'; binary=OUT/'present-device'; c.write_text(code,encoding='utf-8')
clang=ROOT/'build-tools/sdk/ndk/24.0.8215888/toolchains/llvm/prebuilt/windows-x86_64/bin/clang.exe'
env=os.environ.copy();env['TEMP']=env['TMP']=str(OUT)
command=[str(clang),'--target=aarch64-linux-android31','-std=c11','-O2','-I'+str(SRC/'include'),str(c),'-ldl','-Wl,-z,max-page-size=16384','-o',str(binary)]
subprocess.run(command,env=env,check=True)
manifest={'scope':'Real system-Vulkan semaphore acquire/present sequence; no game pixels or Mali claim',
          'sourceSha256':hashlib.sha256((SRC/'src/xwindow_swapchain.c').read_bytes()).hexdigest(),
          'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'bytes':binary.stat().st_size,
          'command':command,'deviceRun':'not_run_by_builder'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Built:',binary,manifest['bytes'],'bytes; no phone action')
