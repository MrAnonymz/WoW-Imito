#include "async_pipeline_creator.h"
#include "vortek_serializer.h"
#include "vulkan_helper.h"
#include <errno.h>
#include <fcntl.h>
#include <poll.h>

typedef struct PipelineCreateRequest {
    VkDevice device;
    VkPipelineCache pipelineCache;
    PipelineType type;
    uint32_t pipelineCount;
    void* pipelineInfos;
    ShaderInspector* shaderInspector;
    MemoryPool memoryPool;
    int notifyFd;
    VkContext* context;
} PipelineCreateRequest;

static void pipelineCreateThread(void* param) {
    PipelineCreateRequest* pipelineCreateRequest = param;
    VkPipeline* pipelines=calloc(pipelineCreateRequest->pipelineCount,sizeof(VkPipeline));
    if(!pipelines) {
        failVkContext(pipelineCreateRequest->context,VK_ERROR_OUT_OF_HOST_MEMORY);
        close(pipelineCreateRequest->notifyFd);vt_free(&pipelineCreateRequest->memoryPool);
        free(pipelineCreateRequest->pipelineInfos);free(pipelineCreateRequest);return;
    }
    VkResult result = VK_SUCCESS;

    if (pipelineCreateRequest->type == PIPELINE_TYPE_GRAPHICS) {
        VkGraphicsPipelineCreateInfo* createInfos = pipelineCreateRequest->pipelineInfos;

        for (int i = 0; i < pipelineCreateRequest->pipelineCount; i++) {
            result = ShaderInspector_inspectShaderStages(pipelineCreateRequest->shaderInspector, pipelineCreateRequest->device, (VkPipelineShaderStageCreateInfo*)createInfos[i].pStages, createInfos[i].stageCount, createInfos[i].pVertexInputState);
            if (result != VK_SUCCESS) break;
        }

        if (result == VK_SUCCESS) result = vulkanWrapper.vkCreateGraphicsPipelines(pipelineCreateRequest->device, pipelineCreateRequest->pipelineCache, pipelineCreateRequest->pipelineCount, createInfos, NULL, pipelines);
    }
    else if (pipelineCreateRequest->type == PIPELINE_TYPE_COMPUTE) {
        VkComputePipelineCreateInfo* createInfos = pipelineCreateRequest->pipelineInfos;

        for (int i = 0; i < pipelineCreateRequest->pipelineCount; i++) {
            result = ShaderInspector_inspectShaderStages(pipelineCreateRequest->shaderInspector, pipelineCreateRequest->device, (VkPipelineShaderStageCreateInfo*)&createInfos[i].stage, 1, NULL);
            if (result != VK_SUCCESS) break;
        }

        if (result == VK_SUCCESS) result = vulkanWrapper.vkCreateComputePipelines(pipelineCreateRequest->device, pipelineCreateRequest->pipelineCache, pipelineCreateRequest->pipelineCount, createInfos, NULL, pipelines);
    }

    vt_free(&pipelineCreateRequest->memoryPool);

    int bufferSize = sizeof(VkResult) + pipelineCreateRequest->pipelineCount * VK_HANDLE_BYTE_COUNT;
    char* outputBuffer=malloc(bufferSize);
    if(!outputBuffer) {
        for(uint32_t i=0;i<pipelineCreateRequest->pipelineCount;i++)if(pipelines[i])
            vulkanWrapper.vkDestroyPipeline(pipelineCreateRequest->device,pipelines[i],NULL);
        free(pipelines);failVkContext(pipelineCreateRequest->context,VK_ERROR_OUT_OF_HOST_MEMORY);
        close(pipelineCreateRequest->notifyFd);free(pipelineCreateRequest->pipelineInfos);free(pipelineCreateRequest);return;
    }

    *(int*)(outputBuffer + 0) = result;
    for (int i = 0, j = sizeof(VkResult); i < pipelineCreateRequest->pipelineCount; i++, j += VK_HANDLE_BYTE_COUNT) {
        uint64_t handle=(uint64_t)pipelines[i];
        memcpy(outputBuffer+j,&handle,sizeof(handle));
    }

    int sent=0;
    while(sent<bufferSize) {
        if(pipelineCreateRequest->context->status<0)break;
        ssize_t n=write(pipelineCreateRequest->notifyFd,outputBuffer+sent,bufferSize-sent);
        if(n<0 && errno==EINTR)continue;
        if(n<0 && (errno==EAGAIN || errno==EWOULDBLOCK)) {
            struct pollfd ready={.fd=pipelineCreateRequest->notifyFd,.events=POLLOUT};
            int result=poll(&ready,1,50);
            if(result<0 && errno!=EINTR)break;
            if(result>0 && (ready.revents&(POLLERR|POLLHUP|POLLNVAL)))break;
            continue;
        }
        if(n<=0)break;
        sent+=n;
    }
    if(sent<bufferSize) {
        for(uint32_t i=0;i<pipelineCreateRequest->pipelineCount;i++)if(pipelines[i])
            vulkanWrapper.vkDestroyPipeline(pipelineCreateRequest->device,pipelines[i],NULL);
        failVkContext(pipelineCreateRequest->context,VK_ERROR_DEVICE_LOST);
    }
    free(outputBuffer);free(pipelines);

    CLOSEFD(pipelineCreateRequest->notifyFd);
    MEMFREE(pipelineCreateRequest->pipelineInfos);
    MEMFREE(pipelineCreateRequest);
}

void AsyncPipelineCreator_create(VkContext* context, PipelineType type) {
    PipelineCreateRequest* pipelineCreateRequest = calloc(1, sizeof(PipelineCreateRequest));
    if(!pipelineCreateRequest){failVkContext(context,VK_ERROR_OUT_OF_HOST_MEMORY);return;}
    pipelineCreateRequest->context=context;
    pipelineCreateRequest->type = type;
    pipelineCreateRequest->shaderInspector = context->shaderInspector;

    uint64_t deviceId = 0;
    uint64_t pipelineCacheId = 0;

    if (type == PIPELINE_TYPE_GRAPHICS) {
        vt_unserialize_vkCreateGraphicsPipelines((VkDevice)&deviceId, (VkPipelineCache)&pipelineCacheId, &pipelineCreateRequest->pipelineCount, NULL, NULL, NULL, context->inputBuffer, NULL);
        if(!pipelineCreateRequest->pipelineCount || pipelineCreateRequest->pipelineCount>4096) {
            free(pipelineCreateRequest);failVkContext(context,VK_ERROR_OUT_OF_HOST_MEMORY);return;
        }
        VkGraphicsPipelineCreateInfo* createInfos = calloc(pipelineCreateRequest->pipelineCount, sizeof(VkGraphicsPipelineCreateInfo));
        if(!createInfos) {
            free(createInfos);free(pipelineCreateRequest);failVkContext(context,VK_ERROR_OUT_OF_HOST_MEMORY);return;
        }
        vt_unserialize_vkCreateGraphicsPipelines(VK_NULL_HANDLE, VK_NULL_HANDLE, NULL, createInfos, NULL, NULL, context->inputBuffer, &pipelineCreateRequest->memoryPool);
        pipelineCreateRequest->pipelineInfos = createInfos;
    }
    else if (type == PIPELINE_TYPE_COMPUTE) {
        vt_unserialize_vkCreateComputePipelines((VkDevice)&deviceId, (VkPipelineCache)&pipelineCacheId, &pipelineCreateRequest->pipelineCount, NULL, NULL, NULL, context->inputBuffer, NULL);
        if(!pipelineCreateRequest->pipelineCount || pipelineCreateRequest->pipelineCount>4096) {
            free(pipelineCreateRequest);failVkContext(context,VK_ERROR_OUT_OF_HOST_MEMORY);return;
        }
        VkComputePipelineCreateInfo* createInfos = calloc(pipelineCreateRequest->pipelineCount, sizeof(VkComputePipelineCreateInfo));
        if(!createInfos) {
            free(createInfos);free(pipelineCreateRequest);failVkContext(context,VK_ERROR_OUT_OF_HOST_MEMORY);return;
        }
        vt_unserialize_vkCreateComputePipelines(VK_NULL_HANDLE, VK_NULL_HANDLE, NULL, createInfos, NULL, NULL, context->inputBuffer, &pipelineCreateRequest->memoryPool);
        pipelineCreateRequest->pipelineInfos = createInfos;
    }

    pipelineCreateRequest->device = VkObject_fromId(deviceId);
    pipelineCreateRequest->pipelineCache = VkObject_fromId(pipelineCacheId);

    int fds[2] = {-1,-1};
    char success = pipe2(fds,O_CLOEXEC) == 0 ? 1 : 0;
    // Only the producer is nonblocking. The guest still receives a blocking
    // read descriptor; shutdown can cancel a stalled reader without hanging
    // ThreadPool_destroy while draining outstanding pipeline results.
    if(success && fcntl(fds[1],F_SETFL,O_NONBLOCK)<0)success=0;
    if(!success || send_fds(context->clientFd, fds, 1, &success, 1)<0) {
        if(fds[0]>=0)close(fds[0]);if(fds[1]>=0)close(fds[1]);
        vt_free(&pipelineCreateRequest->memoryPool);free(pipelineCreateRequest->pipelineInfos);
        free(pipelineCreateRequest);failVkContext(context,VK_ERROR_OUT_OF_HOST_MEMORY);return;
    }

    if (success) {
        pipelineCreateRequest->notifyFd = fds[1];
        CLOSEFD(fds[0]);
        ThreadPool_run(context->pipelineThreadPool, pipelineCreateThread, pipelineCreateRequest);
    }
    else {
        vt_free(&pipelineCreateRequest->memoryPool);
        MEMFREE(pipelineCreateRequest->pipelineInfos);
        MEMFREE(pipelineCreateRequest);
    }
}
