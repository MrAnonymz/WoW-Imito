package com.winlator.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.opengl.GLSurfaceView;
import android.opengl.EGL14;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.winlator.renderer.GLRenderer;
import com.winlator.xserver.XServer;

@SuppressLint("ViewConstructor")
public class XServerView extends GLSurfaceView {
    private final GLRenderer renderer;
    private volatile com.winlator.renderer.NativeFrameQueue nativeFrames;
    private volatile boolean presentationPaused;
    private volatile boolean vortekFrameEvents;
    private float targetFrameRate;

    public XServerView(Context context, XServer xServer) {
        super(context);
        nativeFrames = xServer.nativeHardwareBuffers ? new com.winlator.renderer.NativeFrameQueue() : null;
        setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 0, 0);
        setPreserveEGLContextOnPause(true);
        renderer = new GLRenderer(this, xServer);
        setRenderer(renderer);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
    }

    public GLRenderer getRenderer() {
        return renderer;
    }

    /** Vortek retains its asynchronous GL event scheduling while active. Work
     * without a current draw surface is deferred until the next actual draw. */
    public void enableVortekFrameQueue() {
        if (nativeFrames == null) nativeFrames = new com.winlator.renderer.NativeFrameQueue();
        vortekFrameEvents = true;
    }

    public boolean isPresentationPaused() { return presentationPaused; }

    @Override public void onPause() {
        presentationPaused = true;
        super.onPause();
    }

    @Override public void onResume() {
        super.onResume();
        presentationPaused = false;
        requestRender();
    }

    @Override public void queueEvent(Runnable task) {
        if (nativeFrames == null) { super.queueEvent(task); return; }
        nativeFrames.add(task, false);
        if (vortekFrameEvents) super.queueEvent(this::applyVortekFrameEvent);
        requestRender();
    }

    public void queueNativeFrame(Runnable task) {
        // Legacy runtime selection can occur after this view is constructed.
        // Keep that established GL event path unchanged.
        if (nativeFrames == null) { super.queueEvent(task); requestRender(); return; }
        nativeFrames.add(task, true);
        if (vortekFrameEvents) super.queueEvent(this::applyVortekFrameEvent);
        requestRender();
    }

    private void applyVortekFrameEvent() {
        // GLSurfaceView may execute events even while paused or before its EGL
        // surface exists. Keep their FIFO order, but defer GL calls in that case.
        if (presentationPaused || EGL14.EGL_NO_CONTEXT.equals(EGL14.eglGetCurrentContext()) ||
                EGL14.EGL_NO_SURFACE.equals(EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW))) return;
        nativeFrames.beforeDraw();
        requestRender();
    }

    public void beforeNativeFrameDraw() {
        if (nativeFrames == null) return;
        nativeFrames.beforeDraw();
        if (nativeFrames.hasPending()) requestRender();
    }

    public void requestContentRender() {
        // Native Present forceUpdate runs synchronously before this frame is
        // drawn. Scheduling it again would swap the same pixels twice. Keep
        // external updates and legacy GL event scheduling unchanged.
        if (nativeFrames == null || !nativeFrames.isApplyingCurrentFrame()) requestRender();
    }

    /** Consume an already copied CPU status row without composing the same
     * game image again. This must never submit graphics or resource work:
     * those tasks keep their ordered native-frame queue.
     */
    public void queueStatusEvent(Runnable task) {
        super.queueEvent(task);
    }

    public void setTargetFrameRate(int fps) {
        targetFrameRate=fps;
        // Match the activity's ordinary UI surface to the game's hint. The
        // touch overlay otherwise keeps some high-refresh devices voting for
        // their maximum rate even while the game is capped. This is a scoped
        // preference, not a forced display mode or a change to system settings.
        if (getContext() instanceof android.app.Activity) {
            android.view.Window window=((android.app.Activity)getContext()).getWindow();
            android.view.WindowManager.LayoutParams attributes=window.getAttributes();
            attributes.preferredRefreshRate=fps;
            window.setAttributes(attributes);
        }
        applyFrameRate();
    }
    private void applyFrameRate() {
        android.view.Surface surface=getHolder().getSurface();
        if(android.os.Build.VERSION.SDK_INT>=31 && surface!=null && surface.isValid()) {
            try {
                // A scheduling hint only. Keep the OS thermal/refresh policy and
                // prohibit non-seamless switches that would flash a black screen.
                surface.setFrameRate(targetFrameRate,android.view.Surface.FRAME_RATE_COMPATIBILITY_DEFAULT,
                        android.view.Surface.CHANGE_FRAME_RATE_ONLY_IF_SEAMLESS);
            } catch(IllegalArgumentException | IllegalStateException ignored) {}
        }
    }
    @Override public void surfaceCreated(android.view.SurfaceHolder holder) {
        super.surfaceCreated(holder);
        applyFrameRate();
    }
}
