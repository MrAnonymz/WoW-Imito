$ErrorActionPreference = 'Stop'
$project = 'E:\Code\MD\WoW-Enorial-Android'
$bin = Join-Path $project 'build-tools\sdk\ndk\24.0.8215888\toolchains\llvm\prebuilt\windows-x86_64\bin'
$kernel32 = 'C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0\um\x64\kernel32.lib'
$obj = Join-Path $PSScriptRoot 'texture_copy_test.obj'
$exe = Join-Path $PSScriptRoot 'texture_copy_test.exe'
& (Join-Path $bin 'clang.exe') --target=x86_64-pc-windows-msvc -ffreestanding -fno-builtin -fno-stack-protector -O1 -c (Join-Path $PSScriptRoot 'texture_copy_test.c') -o $obj
if ($LASTEXITCODE -ne 0) { throw 'Texture layout/decoder compilation failed' }
& (Join-Path $bin 'ld.lld.exe') -flavor link /entry:mainCRTStartup /subsystem:console $obj $kernel32 "/out:$exe"
if ($LASTEXITCODE -ne 0) { throw 'Texture layout/decoder link failed' }
& $exe
if ($LASTEXITCODE -ne 0) { throw "Texture layout/decoder failures: $LASTEXITCODE" }
'PASS: actual decoder; all 7 mip levels, BC1/2/3 atlas offsets and row padding, layer strides, bounds and four-worker BC1/2/3/4/5 pitches.'
