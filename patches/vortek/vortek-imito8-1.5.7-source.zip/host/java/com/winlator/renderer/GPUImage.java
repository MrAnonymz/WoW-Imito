package com.winlator.renderer;

import androidx.annotation.Keep;
import android.opengl.GLES30;

import com.winlator.xserver.Drawable;

import java.nio.ByteBuffer;

public class GPUImage extends Texture {
    private long hardwareBufferPtr;
    private long imageKHRPtr;
    private ByteBuffer virtualData;
    private short stride;
    private boolean locked = false;
    private int nativeHandle;
    private boolean imported;
    private int hardwareBufferFormat;
    private boolean importedBgraInRgba;
    private boolean samplingSwapsRedBlue;
    private final int[] copyFramebuffer = new int[1];
    private final int[] previousCopyBindings = new int[2];

    static {
        System.loadLibrary("winlator");
    }

    public GPUImage(Drawable owner) {
        this(owner, true, true);
    }

    public GPUImage(Drawable owner, boolean cpuAccess) {
        this(owner, cpuAccess, true);
    }

    public GPUImage(Drawable owner, boolean cpuAccess, boolean useHALPixelFormatBGRA8888) {
        super(owner);
        hardwareBufferPtr = createHardwareBuffer(owner.width, owner.height, cpuAccess, useHALPixelFormatBGRA8888);
        if (hardwareBufferPtr == 0) throw new IllegalStateException("Unable to allocate a graphics buffer.");
        if (cpuAccess && hardwareBufferPtr != 0) {
            virtualData = lockHardwareBuffer(hardwareBufferPtr);
            if (virtualData == null) {
                destroyHardwareBuffer(hardwareBufferPtr, false);
                hardwareBufferPtr = 0;
                throw new IllegalStateException("Unable to map a graphics buffer.");
            }
            locked = true;
        }
    }

    public GPUImage(Drawable owner, int socketFd) {
        super(owner);
        hardwareBufferPtr = receiveHardwareBuffer(socketFd, owner.width, owner.height);
        if (hardwareBufferPtr == 0) throw new IllegalArgumentException("Invalid graphics buffer handle.");
        imported = true;
    }

    /** A private Vortek presentation buffer, never installed as the window's
     * live texture. Retain a distinct Android reference until GL retirement. */
    public GPUImage(Drawable owner, long nativeBuffer) {
        super(owner);
        hardwareBufferPtr = retainHardwareBuffer(nativeBuffer, owner.width, owner.height);
        if (hardwareBufferPtr == 0) throw new IllegalArgumentException("Invalid presentation buffer.");
    }

    /** GL thread: snapshot the released Vulkan image into compositor storage.
     * Only GPU commands copy pixels. The bounded fence completes source reads
     * before Vulkan can acquire/write the shared buffer again. */
    public boolean copyToTexture(Texture destination, short width, short height) {
        allocateTexture(width, height, null);
        GLES30.glGetIntegerv(GLES30.GL_READ_FRAMEBUFFER_BINDING, previousCopyBindings, 0);
        long completion = 0;
        try {
            bindCopyFramebuffer(GLES30.GL_READ_FRAMEBUFFER);
            if (!destination.copyFromReadBufferOnRendererContext(width, height)) return false;
            if (GLES30.glGetError() != GLES30.GL_NO_ERROR) return false;
            completion = GLES30.glFenceSync(GLES30.GL_SYNC_GPU_COMMANDS_COMPLETE, 0);
            if (completion == 0) return false;
            GLES30.glFlush();
            for (int slice = 0; slice < 60; slice++) {
                int status = GLES30.glClientWaitSync(completion, 0, 50_000_000L);
                if (status == GLES30.GL_ALREADY_SIGNALED || status == GLES30.GL_CONDITION_SATISFIED) return true;
                if (status != GLES30.GL_TIMEOUT_EXPIRED) return false;
            }
            return false;
        } finally {
            if (completion != 0) GLES30.glDeleteSync(completion);
            GLES30.glBindFramebuffer(GLES30.GL_READ_FRAMEBUFFER, previousCopyBindings[0]);
        }
    }

    public boolean isImported() { return imported; }

    /** Imported swapchain VkImages must agree with this allocation's channels.
     * A BGRA window buffer cannot be reused for a later RGBA swapchain. */
    public boolean matchesHardwareBufferFormat(boolean bgra) {
        return hardwareBufferPtr != 0 && hardwareBufferFormat == (bgra ? 5 : 1);
    }

    public boolean samePresentChannels(GPUImage destination) {
        return destination.samplingSwapsRedBlue == (imported && importedBgraInRgba);
    }

    /** Only for a clipped Present crossing backing stores or channel orders.
     * The ordinary full-frame and same-format paths stay on the GPU. */
    public boolean copyPresentRegion(Drawable destination, int sx, int sy, int w, int h, int dx, int dy) {
        long bytes = 4L * w * h;
        if (owner == null || bytes <= 0 || bytes > Integer.MAX_VALUE) return false;
        ByteBuffer pixels = ByteBuffer.allocateDirect((int)bytes);
        allocateTexture(owner.width, owner.height, null);
        int[] saved = new int[6];
        GLES30.glGetIntegerv(GLES30.GL_READ_FRAMEBUFFER_BINDING, saved, 0);
        GLES30.glGetIntegerv(GLES30.GL_PIXEL_PACK_BUFFER_BINDING, saved, 1);
        GLES30.glGetIntegerv(GLES30.GL_PACK_ALIGNMENT, saved, 2);
        GLES30.glGetIntegerv(GLES30.GL_PACK_ROW_LENGTH, saved, 3);
        GLES30.glGetIntegerv(GLES30.GL_PACK_SKIP_ROWS, saved, 4);
        GLES30.glGetIntegerv(GLES30.GL_PACK_SKIP_PIXELS, saved, 5);
        try {
            bindCopyFramebuffer(GLES30.GL_READ_FRAMEBUFFER);
            GLES30.glBindBuffer(GLES30.GL_PIXEL_PACK_BUFFER, 0);
            GLES30.glPixelStorei(GLES30.GL_PACK_ALIGNMENT, 4);
            GLES30.glPixelStorei(GLES30.GL_PACK_ROW_LENGTH, 0);
            GLES30.glPixelStorei(GLES30.GL_PACK_SKIP_ROWS, 0);
            GLES30.glPixelStorei(GLES30.GL_PACK_SKIP_PIXELS, 0);
            GLES30.glReadPixels(sx, sy, w, h, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, pixels);
            if (GLES30.glGetError() != GLES30.GL_NO_ERROR) return false;
        } finally {
            GLES30.glBindFramebuffer(GLES30.GL_READ_FRAMEBUFFER, saved[0]);
            GLES30.glBindBuffer(GLES30.GL_PIXEL_PACK_BUFFER, saved[1]);
            GLES30.glPixelStorei(GLES30.GL_PACK_ALIGNMENT, saved[2]);
            GLES30.glPixelStorei(GLES30.GL_PACK_ROW_LENGTH, saved[3]);
            GLES30.glPixelStorei(GLES30.GL_PACK_SKIP_ROWS, saved[4]);
            GLES30.glPixelStorei(GLES30.GL_PACK_SKIP_PIXELS, saved[5]);
        }
        if (!(imported && importedBgraInRgba)) swapRedBlue(pixels);
        return destination.uploadPresentPixels(pixels, w, h, dx, dy);
    }

    private static void swapRedBlue(ByteBuffer pixels) {
        for (int i = pixels.position(); i < pixels.limit(); i += 4) {
            byte blue = pixels.get(i);
            pixels.put(i, pixels.get(i + 2));
            pixels.put(i + 2, blue);
        }
    }

    /** GL thread only. Complete the copy before releasing the producer's buffer. */
    public boolean copyTo(GPUImage destination, int width, int height, int x, int y) {
        allocateTexture((short)width, (short)height, null);
        destination.matchCopyFormat(hardwareBufferFormat);
        destination.updateFromDrawable();
        GLES30.glGetIntegerv(GLES30.GL_READ_FRAMEBUFFER_BINDING, previousCopyBindings, 0);
        GLES30.glGetIntegerv(GLES30.GL_DRAW_FRAMEBUFFER_BINDING, previousCopyBindings, 1);
        boolean scissor = GLES30.glIsEnabled(GLES30.GL_SCISSOR_TEST);
        try {
            bindCopyFramebuffer(GLES30.GL_READ_FRAMEBUFFER);
            destination.bindCopyFramebuffer(GLES30.GL_DRAW_FRAMEBUFFER);
            GLES30.glDisable(GLES30.GL_SCISSOR_TEST);
            GLES30.glBlitFramebuffer(0, 0, width, height, x, y, x + width, y + height,
                    GLES30.GL_COLOR_BUFFER_BIT, GLES30.GL_NEAREST);
            GLES30.glFinish();
            if (GLES30.glGetError() != GLES30.GL_NO_ERROR) return false;
            destination.setSamplingSwizzle(imported && importedBgraInRgba);
            return true;
        } finally {
            GLES30.glBindFramebuffer(GLES30.GL_READ_FRAMEBUFFER, previousCopyBindings[0]);
            GLES30.glBindFramebuffer(GLES30.GL_DRAW_FRAMEBUFFER, previousCopyBindings[1]);
            if (scissor) GLES30.glEnable(GLES30.GL_SCISSOR_TEST);
        }
    }

    /** X pixmaps contain BGRA bytes. Preserve pixels outside a partial Present
     * when a software producer follows an imported swapchain on the same window. */
    public boolean uploadPixmap(ByteBuffer pixels, int width, int height, int x, int y) {
        updateFromDrawable();
        boolean full = x == 0 && y == 0 && width == owner.width && height == owner.height;
        boolean swap = full || samplingSwapsRedBlue;
        if (!swap) swapRedBlue(pixels);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId);
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4);
        GLES30.glTexSubImage2D(GLES30.GL_TEXTURE_2D, 0, x, y, width, height,
                GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, pixels);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0);
        if (GLES30.glGetError() != GLES30.GL_NO_ERROR) return false;
        setSamplingSwizzle(swap);
        return true;
    }

    /** The texture attachment is immutable until destroy(). Validate it once,
     * rather than creating, checking and deleting two FBOs for every frame. */
    private void bindCopyFramebuffer(int target) {
        if (copyFramebuffer[0] != 0) {
            GLES30.glBindFramebuffer(target, copyFramebuffer[0]);
            return;
        }
        GLES30.glGenFramebuffers(1, copyFramebuffer, 0);
        GLES30.glBindFramebuffer(target, copyFramebuffer[0]);
        GLES30.glFramebufferTexture2D(target, GLES30.GL_COLOR_ATTACHMENT0,
                GLES30.GL_TEXTURE_2D, textureId, 0);
        if (copyFramebuffer[0] == 0 || GLES30.glCheckFramebufferStatus(target) != GLES30.GL_FRAMEBUFFER_COMPLETE) {
            GLES30.glDeleteFramebuffers(1, copyFramebuffer, 0);
            copyFramebuffer[0] = 0;
            throw new IllegalStateException("Graphics buffer is not renderable.");
        }
    }

    /** Avoid cross-format framebuffer blits. Some ANGLE/native-driver paths
     * copy raw components across BGRA/RGBA attachments without converting the
     * channel order. Retain the producer's format, independent of GPU model. */
    private void matchCopyFormat(int sourceFormat) {
        boolean bgra = sourceFormat == 5; // Android BGRA_8888
        if (hardwareBufferPtr != 0 && (hardwareBufferFormat == 5) == bgra) return;
        if (imported || locked) throw new IllegalStateException("Cannot change a shared graphics buffer.");
        long replacement = createHardwareBuffer(owner.width, owner.height, false, bgra);
        if (replacement == 0) throw new IllegalStateException("Unable to allocate a graphics buffer.");
        destroy();
        hardwareBufferPtr = replacement;
    }

    /** Pinned WrapperV2 exports BGRA bytes even when the AHB descriptor is
     * RGBA/RGBX. EGL honours the descriptor. Correct sampling once per texture,
     * without a CPU readback, extra draw, or changing correctly described BGRA.
     * glBlitFramebuffer copies components independently of texture swizzling. */
    private void setSamplingSwizzle(boolean swap) {
        if (samplingSwapsRedBlue == swap) return;
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_SWIZZLE_R,
                swap ? GLES30.GL_BLUE : GLES30.GL_RED);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_SWIZZLE_B,
                swap ? GLES30.GL_RED : GLES30.GL_BLUE);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0);
        samplingSwapsRedBlue = swap;
    }

    @Keep
    private void setHardwareBufferFormat(int format) {
        hardwareBufferFormat = format;
        importedBgraInRgba = format == 1 || format == 2; // Android RGBA_8888 / RGBX_8888
    }

    @Override
    public void allocateTexture(short width, short height, ByteBuffer data) {
        if (isAllocated()) return;
        super.allocateTexture(width, height, null);
        imageKHRPtr = createImageKHR(hardwareBufferPtr, textureId);
        if (imageKHRPtr == 0) {
            super.destroy();
            throw new IllegalStateException("Unable to import a graphics buffer.");
        }
    }

    @Override
    public void updateFromDrawable() {
        if (!isAllocated() && owner != null) allocateTexture(owner.width, owner.height, null);
        needsUpdate = false;
    }

    public short getStride() {
        return stride;
    }

    @Keep
    private void setStride(short stride) {
        this.stride = stride;
    }

    public int getNativeHandle() {
        return nativeHandle;
    }

    @Keep
    private void setNativeHandle(int nativeHandle) {
        this.nativeHandle = nativeHandle;
    }

    public ByteBuffer getVirtualData() {
        return virtualData;
    }

    @Override
    public void destroy() {
        if (copyFramebuffer[0] != 0) {
            GLES30.glDeleteFramebuffers(1, copyFramebuffer, 0);
            copyFramebuffer[0] = 0;
        }
        destroyImageKHR(imageKHRPtr);
        destroyHardwareBuffer(hardwareBufferPtr, locked);
        virtualData = null;
        imageKHRPtr = 0;
        hardwareBufferPtr = 0;
        locked = false;
        samplingSwapsRedBlue = false;
        super.destroy();
    }

    public long getHardwareBufferPtr() {
        return hardwareBufferPtr;
    }

    private native long createHardwareBuffer(short width, short height, boolean cpuAccess, boolean useHALPixelFormatBGRA8888);
    private native long receiveHardwareBuffer(int socketFd, short width, short height);
    private native long retainHardwareBuffer(long nativeBuffer, short width, short height);

    private native void destroyHardwareBuffer(long hardwareBufferPtr, boolean locked);

    private native ByteBuffer lockHardwareBuffer(long hardwareBufferPtr);

    private native long createImageKHR(long hardwareBufferPtr, int textureId);

    private native void destroyImageKHR(long imageKHRPtr);
}
