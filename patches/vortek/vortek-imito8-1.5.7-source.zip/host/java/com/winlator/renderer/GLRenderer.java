package com.winlator.renderer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;

import androidx.core.graphics.ColorUtils;

import com.winlator.R;
import com.winlator.core.Bitmask;
import com.winlator.core.Callback;
import com.winlator.core.GPUHelper;
import com.winlator.core.ImageUtils;
import com.winlator.math.Mathf;
import com.winlator.math.XForm;
import com.winlator.renderer.material.CursorMaterial;
import com.winlator.renderer.material.ScreenMaterial;
import com.winlator.renderer.material.WindowMaterial;
import com.winlator.widget.XServerView;
import com.winlator.xserver.Atom;
import com.winlator.xserver.Cursor;
import com.winlator.xserver.Decoration;
import com.winlator.xserver.Drawable;
import com.winlator.xserver.Pointer;
import com.winlator.xserver.Property;
import com.winlator.xserver.ScreenInfo;
import com.winlator.xserver.Window;
import com.winlator.xserver.WindowAttributes;
import com.winlator.xserver.WindowManager;
import com.winlator.xserver.XLock;
import com.winlator.xserver.XServer;
import com.winlator.wowmobile.touch.WrathRTFrameStateSampler;
import com.winlator.wowmobile.WrathRTRenderArea;
import com.winlator.wowmobile.GameFolder;
import com.winlator.wowmobile.GameRuntimeEvidence;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.function.Consumer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GLRenderer implements GLSurfaceView.Renderer, WindowManager.OnWindowModificationListener, Pointer.OnPointerMotionListener {
    public final XServerView xServerView;
    private final XServer xServer;
    protected final VertexAttribute quadVertices = new VertexAttribute("position", 2);
    private final float[] tmpXForm1 = XForm.getInstance();
    private final float[] tmpXForm2 = XForm.getInstance();
    private final CursorMaterial cursorMaterial = new CursorMaterial();
    private final WindowMaterial windowMaterial = new WindowMaterial();
    public final ViewTransformation viewTransformation = new ViewTransformation();
    private final Drawable rootCursorDrawable;
    private final ArrayList<RenderableWindow> renderableWindows = new ArrayList<>();
    private boolean forceWindowsFullscreen;
    private boolean fullscreen = false;
    private boolean toggleFullscreen = false;
    protected boolean viewportNeedsUpdate = true;
    private volatile boolean cursorVisible = true;
    private boolean defaultCursorVisible = true;
    private volatile boolean controllerCursor;
    private volatile boolean physicalMouseCursor;
    private float cursorScale = 1.0f;
    private int cursorBackColor = 0xffffff;
    private int cursorForeColor = 0x000000;
    private volatile boolean screenOffsetYRelativeToCursor = false;
    private volatile float magnifierZoom = 1.0f;
    protected short surfaceWidth;
    protected short surfaceHeight;
    public final EffectComposer effectComposer = new EffectComposer(this);
    private volatile WrathRTFrameStateSampler wrathrtStateSampler;
    private boolean wrathrtViewportEnabled;
    private volatile WrathRTRenderArea renderArea;
    private Consumer<WrathRTRenderArea> wrathrtViewportListener;
    private java.util.function.Predicate<Window> applicationViewportSelector;
    private java.util.Comparator<Window> applicationViewportOrder;
    private java.util.function.Function<Window, WrathRTRenderArea> applicationViewportArea;
    private volatile Window selectedApplicationViewport;
    private final java.util.concurrent.atomic.AtomicBoolean applicationSceneQueued = new java.util.concurrent.atomic.AtomicBoolean();
    private Window selectedWrathRTViewport;
    private final long viewportEvidenceGeneration;
    private volatile WrathRTRenderArea fullRenderArea;
    private com.winlator.renderer.DualHudReadback companionReadback;
    private volatile com.winlator.wowmobile.dualdisplay.DualHudGeometry companionGeometry;
    private float companionMainFraction;
    private boolean companionCrop;
    private volatile long companionSessionId;
    private final Runnable companionPoll = this::requestCompanionFrame;
    private void requestCompanionFrame() { xServerView.requestRender(); }

    /** Queue only CPU status consumption, never a new composition. */
    public void queueCompletedStatus() {
        WrathRTFrameStateSampler sampler = wrathrtStateSampler;
        if (sampler == null) return;
        xServerView.queueStatusEvent(() -> {
            // A completed row may outlive its owning game/sampler while this
            // event waits. Never publish that row into a replacement session.
            if (wrathrtStateSampler != sampler) return;
            sampler.consumeCompleted(surfaceWidth, surfaceHeight,
                    fullscreen ? 0 : viewTransformation.viewOffsetX,
                    fullscreen ? 0 : viewTransformation.viewOffsetY,
                    fullscreen ? surfaceWidth : viewTransformation.viewWidth,
                    fullscreen ? surfaceHeight : viewTransformation.viewHeight,
                    !screenOffsetYRelativeToCursor && magnifierZoom == 1.0f);
        });
    }

    public interface CompanionFrames {
        void frame(DualHudReadback.Frame frame,
                com.winlator.wowmobile.dualdisplay.DualHudGeometry geometry);
        void invalidated();
    }

    public GLRenderer(XServerView xServerView, XServer xServer) {
        this.xServerView = xServerView;
        this.xServer = xServer;
        viewportEvidenceGeneration = GameRuntimeEvidence.generation();
        renderArea = new WrathRTRenderArea(0, 0, xServer.screenInfo.width, xServer.screenInfo.height);
        fullRenderArea = renderArea;
        rootCursorDrawable = createRootCursorDrawable();

        quadVertices.put(new float[]{
            0.0f, 0.0f,
            0.0f, 1.0f,
            1.0f, 0.0f,
            1.0f, 1.0f
        });

        xServer.windowManager.addOnWindowModificationListener(this);
        xServer.pointer.addOnPointerMotionListener(this);
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GPUHelper.setGlobalEGLContext();
        if (companionReadback != null) {
            companionReadback.onContextLost();
            companionCrop = false;
            applyRenderArea(fullRenderArea);
            configureCompanionGeometry();
        }
        if (wrathrtStateSampler != null) wrathrtStateSampler.contextCreated();

        GLES20.glFrontFace(GLES20.GL_CCW);
        GLES20.glDisable(GLES20.GL_CULL_FACE);

        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glDepthMask(false);

        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        surfaceWidth = (short)width;
        surfaceHeight = (short)height;
        viewTransformation.update(width, height, renderArea.width, renderArea.height);
        viewportNeedsUpdate = true;
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        xServerView.beforeNativeFrameDraw();
        if (toggleFullscreen) {
            fullscreen = !fullscreen;
            toggleFullscreen = false;
            viewportNeedsUpdate = true;
        }

        if (effectComposer.hasEffects()) {
            effectComposer.render();
        }
        else drawFrame();
        WrathRTFrameStateSampler sampler = wrathrtStateSampler;
        if (sampler != null) {
            sampler.sample(surfaceWidth, surfaceHeight,
                    fullscreen ? 0 : viewTransformation.viewOffsetX,
                    fullscreen ? 0 : viewTransformation.viewOffsetY,
                    fullscreen ? surfaceWidth : viewTransformation.viewWidth,
                    fullscreen ? surfaceHeight : viewTransformation.viewHeight,
                    !screenOffsetYRelativeToCursor && magnifierZoom == 1.0f);
        }
        captureCompanion();
    }

    /** Disabled unless an explicitly connected companion requests a guest HUD region. */
    public void setCompanionCapture(float mainFraction, CompanionFrames listener) {
        if (listener != null && (!Float.isFinite(mainFraction) || mainFraction < .35f || mainFraction > .85f))
            throw new IllegalArgumentException("Invalid companion viewport");
        xServerView.queueEvent(() -> {
            final long session = ++companionSessionId;
            xServerView.removeCallbacks(companionPoll);
            if (companionReadback != null) companionReadback.releaseGl();
            companionReadback = null;
            companionGeometry = null;
            companionCrop = false;
            companionMainFraction = mainFraction;
            applyRenderArea(fullRenderArea);
            if (listener != null) {
                companionReadback = new DualHudReadback(new android.os.Handler(android.os.Looper.getMainLooper()),
                        new DualHudReadback.Listener() {
                    @Override public void onFrame(DualHudReadback.Frame frame) {
                        com.winlator.wowmobile.dualdisplay.DualHudGeometry geometry = companionGeometry;
                        if (session != companionSessionId || !frame.isCurrent() || geometry == null) { frame.release(); return; }
                        listener.frame(frame, geometry);
                    }
                    @Override public void onInvalidated(long generation) {
                        if (session == companionSessionId) {
                            setCompanionCrop(false);
                            listener.invalidated();
                        }
                    }
                });
                configureCompanionGeometry();
            }
        });
        xServerView.requestRender();
    }

    /** Acknowledged game pixels, rather than a timer, authorize the main-screen crop. */
    public void setCompanionCrop(boolean enabled) {
        xServerView.queueEvent(() -> {
            WrathRTRenderArea previous = renderArea;
            companionCrop = enabled && companionGeometry != null;
            applyRenderArea(companionCrop ? companionGeometry.world : fullRenderArea);
            if (renderArea != previous) recordViewportState(3);
        });
        xServerView.requestRender();
    }

    public WrathRTRenderArea getFullRenderArea() { return fullRenderArea; }

    private void configureCompanionGeometry() {
        if (companionReadback == null) return;
        WrathRTRenderArea area = fullRenderArea;
        int mainWidth = Math.round(area.width * companionMainFraction);
        if (mainWidth < 640 || area.width - mainWidth < 300 || area.height < 360) {
            companionGeometry = null;
            return;
        }
        companionGeometry = new com.winlator.wowmobile.dualdisplay.DualHudGeometry(area, mainWidth);
        companionReadback.configure(area.width - mainWidth, area.height);
    }

    private void captureCompanion() {
        DualHudReadback capture = companionReadback;
        com.winlator.wowmobile.dualdisplay.DualHudGeometry geometry = companionGeometry;
        if (capture == null || geometry == null) return;
        long now = android.os.SystemClock.uptimeMillis();
        capture.poll(now);
        capture.capture(now, (width, height) -> {
            WrathRTRenderArea saved = renderArea;
            try {
                renderArea = geometry.hud;
                GLES20.glClearColor(0, 0, 0, 1);
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
                XForm.makeTransform(tmpXForm2, -renderArea.x, -renderArea.y, 1, 1, 0);
                renderWindows();
                if (cursorVisible) renderCursor();
            } finally {
                renderArea = saved;
                GLES20.glClearColor(0, 0, 0, 0);
                viewportNeedsUpdate = true;
            }
        });
        if (capture.hasPending()) {
            xServerView.removeCallbacks(companionPoll);
            xServerView.postDelayed(companionPoll, 16);
        }
    }
    public void setWrathRTStateSampler(WrathRTFrameStateSampler sampler) {
        WrathRTFrameStateSampler previous = wrathrtStateSampler;
        wrathrtStateSampler = sampler;
        if (previous != null && previous != sampler) previous.close();
    }

    protected void drawFrame() {
        if (viewportNeedsUpdate) {
            if (fullscreen) {
                GLES20.glViewport(0, 0, surfaceWidth, surfaceHeight);
            }
            else GLES20.glViewport(viewTransformation.viewOffsetX, viewTransformation.viewOffsetY, viewTransformation.viewWidth, viewTransformation.viewHeight);
            viewportNeedsUpdate = false;
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);

        float pointerX = 0;
        float pointerY = 0;
        float magnifierZoom = !screenOffsetYRelativeToCursor ? this.magnifierZoom : 1.0f;

        if (magnifierZoom != 1.0f) {
            pointerX = Mathf.clamp(xServer.pointer.getX() * magnifierZoom - xServer.screenInfo.width * 0.5f, 0, xServer.screenInfo.width * Math.abs(1.0f - magnifierZoom));
        }

        if (screenOffsetYRelativeToCursor || magnifierZoom != 1.0f) {
            float scaleY = magnifierZoom != 1.0f ? Math.abs(1.0f - magnifierZoom) : 0.5f;
            float offsetY = xServer.screenInfo.height * (screenOffsetYRelativeToCursor ? 0.25f : 0.5f);
            pointerY = Mathf.clamp(xServer.pointer.getY() * magnifierZoom - offsetY, 0, xServer.screenInfo.height * scaleY);
        }

        XForm.makeTransform(tmpXForm2, -pointerX - renderArea.x, -pointerY - renderArea.y, magnifierZoom, magnifierZoom, 0);

        renderWindows();
        if (cursorVisible) renderCursor();
    }

    @Override
    public void onMapWindow(Window window) {
        queueSceneUpdate();
        xServerView.requestRender();
    }

    @Override
    public void onUnmapWindow(Window window) {
        queueSceneUpdate();
        xServerView.requestRender();
    }

    @Override
    public void onChangeWindowZOrder(Window window) {
        queueSceneUpdate();
        xServerView.requestRender();
    }

    @Override
    public void onUpdateWindowContent(Window window) {
        // Modern Wine identifies a game surface only on its first Present.
        // Promote that surface once, instead of keeping its decorated parent.
        Window selected = selectedApplicationViewport;
        if (applicationViewportSelector != null) {
            boolean firstFrame = window.takeNewNativeSurface();
            if (window != selected && window.isSurface() && applicationViewportSelector.test(window)) {
                int priority = selected == null ? 1 : applicationViewportOrder.compare(window, selected);
                // On a tie the scene walk chooses the topmost mapped surface. A
                // same-size replacement can become eligible only at its first Present.
                if (priority > 0 || (priority == 0 && firstFrame)) queueSceneUpdate();
            }
        }
        // Surface metadata may arrive after MapWindow. Observe geometry only;
        // the normal frame path performs no additional pixel readback.
        if (wrathrtViewportEnabled && isWrathRTSurface(window)) {
            WrathRTRenderArea current = fullRenderArea;
            int x = window.getRootX(), y = window.getRootY();
            int width = window.getWidth(), height = window.getHeight();
            if (current.x != x || current.y != y || current.width != width || current.height != height) {
                WrathRTRenderArea area = new WrathRTRenderArea(x, y, width, height);
                xServerView.queueEvent(() -> {
                    selectedWrathRTViewport = window;
                    updateRenderArea(area);
                    recordViewportState(2);
                });
            }
        }
        xServerView.requestContentRender();
    }

    @Override
    public void onUpdateWindowGeometry(final Window window, boolean resized) {
        if (resized || wrathrtViewportEnabled || applicationViewportSelector != null) {
            queueSceneUpdate();
        }
        else xServerView.queueEvent(() -> updateWindowPosition(window));
        xServerView.requestRender();
    }

    @Override
    public void onUpdateWindowAttributes(Window window, Bitmask mask) {
        if (cursorVisible && mask.isSet(WindowAttributes.FLAG_CURSOR)) xServerView.requestRender();
    }

    @Override
    public void onPointerMove(short x, short y) {
        // The game presents its own changed image. A hidden, non-magnifying
        // pointer changes no pixels; rendering it again competes with that frame.
        if (cursorVisible || screenOffsetYRelativeToCursor || magnifierZoom != 1.0f)
            xServerView.requestRender();
    }

    private void renderCursorDrawable(Drawable drawable, int x, int y) {
        synchronized (drawable.renderLock) {
            Texture texture = drawable.getTexture();
            texture.beginSharedAccess();
            texture.updateFromDrawable();

            XForm.set(tmpXForm1, x, y, drawable.width * cursorScale, drawable.height * cursorScale);
            XForm.multiply(tmpXForm1, tmpXForm1, tmpXForm2);

            cursorMaterial.setUniformColor(cursorMaterial.uniforms.backColor, cursorBackColor);
            cursorMaterial.setUniformColor(cursorMaterial.uniforms.foreColor, cursorForeColor);

            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture.getTextureId());
            cursorMaterial.setUniformInt(cursorMaterial.uniforms.texture, 0);
            cursorMaterial.setUniformFloatArray(cursorMaterial.uniforms.xform, tmpXForm1);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, quadVertices.count());
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
            texture.endSharedAccess();
        }
    }

    private void renderWindowDrawable(Drawable drawable, int x, int y, boolean transparent, FullscreenTransformation fullscreenTransformation) {
        synchronized (drawable.renderLock) {
            Texture texture = drawable.getTexture();
            texture.beginSharedAccess();
            texture.updateFromDrawable();

            if (fullscreenTransformation != null) {
                XForm.set(tmpXForm1, fullscreenTransformation.x, fullscreenTransformation.y, fullscreenTransformation.width, fullscreenTransformation.height);
            }
            else XForm.set(tmpXForm1, x, y, drawable.width, drawable.height);

            XForm.multiply(tmpXForm1, tmpXForm1, tmpXForm2);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture.getTextureId());
            windowMaterial.setUniformInt(windowMaterial.uniforms.texture, 0);
            windowMaterial.setUniformFloat(windowMaterial.uniforms.noAlpha, !transparent ? 1.0f : 0.0f);
            windowMaterial.setUniformFloatArray(windowMaterial.uniforms.xform, tmpXForm1);
            windowMaterial.setUniformBool(windowMaterial.uniforms.flipY, texture.isFlipY());

            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, quadVertices.count());
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
            texture.endSharedAccess();
        }
    }

    private void renderWindows() {
        windowMaterial.use();
        windowMaterial.setUniformVec2(windowMaterial.uniforms.viewSize, renderArea.width, renderArea.height);
        quadVertices.bind(windowMaterial.programId);
        // Opaque windows force output alpha to 1 in WindowMaterial. They do not
        // need destination blending; transparent windows and cursor still do.
        boolean blending = true;

        try (XLock lock = xServer.lock(XServer.Lockable.DRAWABLE_MANAGER)) {
            int first = 0;
            // The official game surface can entirely cover Battle.net and its
            // decorated parents. Those pixels contribute nothing to the final
            // frame. Keep every overlay above it, and retain the original path
            // for legacy sessions, transparent windows and translated/zoomed views.
            if (applicationViewportSelector != null && selectedApplicationViewport != null &&
                    selectedApplicationViewport.isSurface() && !screenOffsetYRelativeToCursor && magnifierZoom == 1.0f) {
                for (int i = renderableWindows.size() - 1; i >= 0; i--) {
                    RenderableWindow candidate = renderableWindows.get(i);
                    if (candidate.transparent || candidate.content.isOffscreenStorage()) continue;
                    FullscreenTransformation bounds = candidate.fullscreenTransformation;
                    if (renderArea.coveredBy(bounds == null ? candidate.rootX : bounds.x,
                            bounds == null ? candidate.rootY : bounds.y,
                            bounds == null ? candidate.content.width : bounds.width,
                            bounds == null ? candidate.content.height : bounds.height)) {
                        first = i;
                        break;
                    }
                }
            }
            for (int i = first; i < renderableWindows.size(); i++) {
                RenderableWindow window = renderableWindows.get(i);
                if (!window.content.isOffscreenStorage()) {
                    if (blending != window.transparent) {
                        blending = window.transparent;
                        if (blending) GLES20.glEnable(GLES20.GL_BLEND);
                        else GLES20.glDisable(GLES20.GL_BLEND);
                    }
                    renderWindowDrawable(window.content, window.rootX, window.rootY, window.transparent, window.fullscreenTransformation);
                }
            }
        }
        if (!blending) GLES20.glEnable(GLES20.GL_BLEND);

        quadVertices.disable();
    }

    private void renderCursor() {
        cursorMaterial.use();
        cursorMaterial.setUniformVec2(cursorMaterial.uniforms.viewSize, renderArea.width, renderArea.height);
        quadVertices.bind(cursorMaterial.programId);

        try (XLock lock = xServer.lock(XServer.Lockable.DRAWABLE_MANAGER)) {
            Window pointWindow = xServer.inputDeviceManager.getPointWindow();
            Cursor cursor = pointWindow != null ? pointWindow.attributes.getCursor() : null;
            short x = xServer.pointer.getClampedX();
            short y = xServer.pointer.getClampedY();

            // WoW's touch addon deliberately supplies a transparent guest cursor.
            // Controller navigation needs an independent, visible pointer.
            if (controllerCursor || physicalMouseCursor) renderCursorDrawable(rootCursorDrawable, x, y);
            else if (cursor != null) {
                if (cursor.isVisible()) renderCursorDrawable(cursor.cursorImage, x - cursor.hotSpotX, y - cursor.hotSpotY);
            }
            else renderCursorDrawable(rootCursorDrawable, x, y);
        }

        quadVertices.disable();
    }

    public void toggleFullscreen() {
        toggleFullscreen = true;
        xServerView.requestRender();
    }

    private Drawable createRootCursorDrawable() {
        Context context = xServerView.getContext();
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inScaled = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.cursor, options);
        return Drawable.fromBitmap(bitmap);
    }

    private void queueSceneUpdate() {
        if (applicationViewportSelector == null) {
            xServerView.queueEvent(this::updateScene);
            return;
        }
        if (applicationSceneQueued.compareAndSet(false, true)) {
            xServerView.queueEvent(() -> {
                // Rebuild from the current window tree. Changes arriving during the
                // rebuild must be able to schedule the next one.
                applicationSceneQueued.set(false);
                updateScene();
            });
        }
    }

    private void updateScene() {
        try (XLock lock = xServer.lock(XServer.Lockable.WINDOW_MANAGER, XServer.Lockable.DRAWABLE_MANAGER)) {
            renderableWindows.clear();
            collectRenderableWindows(xServer.windowManager.rootWindow, xServer.windowManager.rootWindow.getX(), xServer.windowManager.rootWindow.getY());
            if (applicationViewportSelector != null) {
                Window application = findApplicationViewport(xServer.windowManager.rootWindow);
                selectedApplicationViewport = application;
                if (application != null) updateRenderArea(applicationViewportArea.apply(application));
            } else if (wrathrtViewportEnabled) {
                Window game = findWrathRTSurface(xServer.windowManager.rootWindow);
                selectedWrathRTViewport = game;
                if (game != null) updateRenderArea(new WrathRTRenderArea(game.getRootX(), game.getRootY(),
                        game.getWidth(), game.getHeight()));
            }
            recordViewportState(1);
        }
    }

    /** Event-driven numeric evidence; no pixel readback, GL query or frame-loop work. */
    private void recordViewportState(int cause) {
        // Classic launch resets its evidence before creating this renderer.
        // Forever owns a later, independent report epoch and keeps its own path.
        Window window = wrathrtViewportEnabled && applicationViewportSelector == null ? selectedWrathRTViewport : null;
        if (window == null) return;
        Drawable drawable = window.getContent();
        Texture texture = drawable == null ? null : drawable.getTexture();
        Drawable owner = texture == null ? null : texture.getOwner();
        FullscreenTransformation transform = window.getFullscreenTransformation();
        WrathRTRenderArea full = fullRenderArea, shown = renderArea;
        GameRuntimeEvidence.viewport(viewportEvidenceGeneration, new long[]{1, cause,
                Integer.toUnsignedLong(window.id), window.getRootX(), window.getRootY(),
                window.getWidth(), window.getHeight(), drawable == null ? 0 : drawable.width,
                drawable == null ? 0 : drawable.height, owner == null ? 0 : owner.width,
                owner == null ? 0 : owner.height, texture == null ? 0 : texture instanceof GPUImage ? 2 : 1,
                full.x, full.y, full.width, full.height, shown.x, shown.y, shown.width, shown.height,
                companionCrop ? 1 : 0, transform == null ? 0 : transform.x, transform == null ? 0 : transform.y,
                transform == null ? 0 : transform.width, transform == null ? 0 : transform.height,
                xServer.screenInfo.width, xServer.screenInfo.height});
    }

    public void setWrathRTViewportListener(Consumer<WrathRTRenderArea> listener) {
        wrathrtViewportEnabled = listener != null;
        wrathrtViewportListener = listener;
    }

    /** Optional official-launcher viewport; the existing game surface policy is unchanged. */
    public void setApplicationViewport(java.util.function.Predicate<Window> selector,
            java.util.function.Function<Window, WrathRTRenderArea> area, Consumer<WrathRTRenderArea> listener) {
        setApplicationViewport(selector, area, listener,
                java.util.Comparator.comparingInt(window -> window.getWidth() * window.getHeight()));
    }

    public void setApplicationViewport(java.util.function.Predicate<Window> selector,
            java.util.function.Function<Window, WrathRTRenderArea> area, Consumer<WrathRTRenderArea> listener,
            java.util.Comparator<Window> order) {
        applicationViewportSelector = selector;
        applicationViewportOrder = order;
        applicationViewportArea = area;
        wrathrtViewportListener = listener;
        queueSceneUpdate();
    }

    private Window findApplicationViewport(Window parent) {
        if (!parent.attributes.isMapped()) return null;
        Window found = parent.isRenderable() && parent.attributes.isViewable() &&
                parent.getWidth() >= 240 && parent.getHeight() >= 160 && applicationViewportSelector.test(parent) ? parent : null;
        for (Window child : parent.getChildren()) {
            Window candidate = findApplicationViewport(child);
            if (candidate != null && (found == null || applicationViewportOrder.compare(candidate, found) >= 0))
                found = candidate;
        }
        return found;
    }

    @Override public void onModifyWindowProperty(Window window, Property property) {
        // Wine may publish the game identity/surface flag after MapWindow.
        // Classic sessions need the same reselection as application selectors;
        // otherwise a replacement surface can retain the previous viewport.
        boolean classicIdentityChanged = wrathrtViewportEnabled &&
                (property.name == Atom.WM_CLASS || property.name == Atom._NET_WM_SURFACE);
        if (applicationViewportSelector != null || classicIdentityChanged) {
            queueSceneUpdate();
            xServerView.requestRender();
        }
    }

    private static boolean isWrathRTSurface(Window window) {
        if (!window.isSurface() || !window.isRenderable() || !window.attributes.isViewable() ||
                window.getWidth() < 640 || window.getHeight() < 360) return false;
        for (Window owner = window; owner != null; owner = owner.getParent()) {
            String name = owner.getClassName();
            if (!name.isEmpty()) return GameFolder.isGameExecutable(name);
        }
        return false;
    }

    private static Window findWrathRTSurface(Window parent) {
        if (!parent.attributes.isMapped()) return null;
        Window found = isWrathRTSurface(parent) ? parent : null;
        for (Window child : parent.getChildren()) {
            Window candidate = findWrathRTSurface(child);
            if (candidate != null && (found == null ||
                    candidate.getWidth() * candidate.getHeight() >= found.getWidth() * found.getHeight()))
                found = candidate;
        }
        return found;
    }

    private void updateRenderArea(WrathRTRenderArea area) {
        if (!area.sameBounds(fullRenderArea)) {
            fullRenderArea = area;
            companionCrop = false;
            if (companionReadback != null) {
                companionReadback.releaseGl();
                configureCompanionGeometry();
            }
        }
        applyRenderArea(companionCrop && companionGeometry != null ? companionGeometry.world : area);
    }

    private void applyRenderArea(WrathRTRenderArea area) {
        if (area.sameBounds(renderArea)) return;
        renderArea = area;
        if (surfaceWidth > 0 && surfaceHeight > 0)
            viewTransformation.update(surfaceWidth, surfaceHeight, area.width, area.height);
        viewportNeedsUpdate = true;
        Consumer<WrathRTRenderArea> listener = wrathrtViewportListener;
        if (listener != null) xServerView.post(() -> listener.accept(area));
    }

    private void collectRenderableWindows(Window window, int x, int y) {
        if (!window.isRenderable()) return;
        if (window != xServer.windowManager.rootWindow && window.attributes.isViewable()) {
            Window parent = window.getParent();
            boolean transparent = window.attributes.isTransparent() || parent.attributes.isTransparent() || parent.isLayered() || window.isLayered();

            if (forceWindowsFullscreen) {
                short width = window.getWidth();
                short height = window.getHeight();
                FullscreenTransformation fullscreenTransformation = null;

                boolean inBounds = width >= ScreenInfo.MIN_WIDTH && height >= ScreenInfo.MIN_HEIGHT && width < xServer.screenInfo.width && height < xServer.screenInfo.height;
                if (window.getType() == Window.Type.NORMAL && inBounds && window.hasNoDecorations()) {
                    fullscreenTransformation = window.getFullscreenTransformation();
                    if (fullscreenTransformation == null) window.setFullscreenTransformation(fullscreenTransformation = new FullscreenTransformation(window));
                    fullscreenTransformation.update(xServer.screenInfo, window.getWidth(), window.getHeight());

                    if (parent != xServer.windowManager.rootWindow && parent.getChildCount() == 1 && parent.hasDecoration(Decoration.BORDER) && parent.hasDecoration(Decoration.TITLE)) {
                        FullscreenTransformation parentFullscreenTransformation = parent.getFullscreenTransformation();
                        if (parentFullscreenTransformation == null) parent.setFullscreenTransformation(parentFullscreenTransformation = new FullscreenTransformation(parent));
                        parentFullscreenTransformation.update(xServer.screenInfo, parent.getWidth(), parent.getHeight());

                        removeRenderableWindow(parent);
                    }
                    else parent.setFullscreenTransformation(null);
                }
                else window.setFullscreenTransformation(null);

                renderableWindows.add(new RenderableWindow(window.getContent(), x, y, transparent, fullscreenTransformation));
            }
            else renderableWindows.add(new RenderableWindow(window.getContent(), x, y, transparent, null));
        }

        if (window.attributes.isRenderSubwindows()) {
            for (Window child : window.getChildren()) {
                collectRenderableWindows(child, child.getX() + x, child.getY() + y);
            }
        }
    }

    private void removeRenderableWindow(Window window) {
        for (int i = 0; i < renderableWindows.size(); i++) {
            if (renderableWindows.get(i).content == window.getContent()) {
                renderableWindows.remove(i);
                break;
            }
        }
    }

    private void updateWindowPosition(Window window) {
        for (RenderableWindow renderableWindow : renderableWindows) {
            if (renderableWindow.content == window.getContent()) {
                renderableWindow.rootX = window.getRootX();
                renderableWindow.rootY = window.getRootY();
                break;
            }
        }
    }

    public void setCursorVisible(boolean cursorVisible) {
        if (defaultCursorVisible == cursorVisible) return;
        defaultCursorVisible = cursorVisible;
        updateCursorVisibility();
    }

    public void setControllerCursorVisible(boolean visible) {
        if (controllerCursor == visible) return;
        controllerCursor = visible;
        updateCursorVisibility();
    }

    /** Captured mice have no Android pointer; do not let controller state hide them. */
    public void setPhysicalMouseCursorVisible(boolean visible) {
        if (physicalMouseCursor == visible) return;
        physicalMouseCursor = visible;
        updateCursorVisibility();
    }

    private void updateCursorVisibility() {
        cursorVisible = defaultCursorVisible || controllerCursor || physicalMouseCursor;
        xServerView.requestRender();
    }

    public boolean isCursorVisible() {
        return cursorVisible;
    }

    public float getCursorScale() {
        return cursorScale;
    }

    public void setCursorScale(float cursorScale) {
        this.cursorScale = cursorScale;
    }

    public int getCursorColor() {
        return cursorBackColor;
    }

    public void setCursorColor(int cursorColor) {
        this.cursorBackColor = cursorColor;
        this.cursorForeColor = ColorUtils.calculateLuminance(cursorColor) < 0.5f ? 0xffffff : 0x000000;
    }

    public boolean isScreenOffsetYRelativeToCursor() {
        return screenOffsetYRelativeToCursor;
    }

    public void setScreenOffsetYRelativeToCursor(boolean screenOffsetYRelativeToCursor) {
        this.screenOffsetYRelativeToCursor = screenOffsetYRelativeToCursor;
        xServerView.requestRender();
    }

    public boolean isForceWindowsFullscreen() {
        return forceWindowsFullscreen;
    }

    public void setForceWindowsFullscreen(boolean forceWindowsFullscreen) {
        this.forceWindowsFullscreen = forceWindowsFullscreen;
    }

    public boolean isFullscreen() {
        return fullscreen;
    }

    public float getMagnifierZoom() {
        return magnifierZoom;
    }

    public void setMagnifierZoom(float magnifierZoom) {
        this.magnifierZoom = magnifierZoom;
        xServerView.requestRender();
    }

    public int[] getPixelsARGB(int x, int y, int width, int height, boolean flipY) {
        ByteBuffer pixelBuffer = ByteBuffer.allocateDirect(width * height * 4).order(ByteOrder.nativeOrder());
        GLES20.glReadPixels(x, y, width, height, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, pixelBuffer);

        IntBuffer colors = pixelBuffer.asIntBuffer();
        int[] result = new int[width * height];
        if (flipY) {
            for (int i = 0; i < height; i++) {
                colors.position((height - i - 1) * width);
                colors.get(result, i * width, width);
            }
        }
        else colors.get(result);

        for (int i = 0; i < result.length; i++) {
            result[i] = ((result[i] & 0xff00ff00)) | ((result[i] & 0x000000ff) << 16) | ((result[i] & 0x00ff0000) >> 16);
        }
        return result;
    }

    public void takeWindowScreenshot(final Drawable drawable, final Callback<Bitmap> callback) {
        xServerView.queueEvent(() -> {
            synchronized (drawable.renderLock) {
                Texture texture = drawable.getTexture();
                texture.beginSharedAccess();
                texture.updateFromDrawable();

                int[] framebufferSize = ImageUtils.getScaledSize(drawable.width, drawable.height, 0, 256);

                RenderTarget renderTarget = new RenderTarget();
                renderTarget.allocateFramebuffer(framebufferSize[0], framebufferSize[1]);

                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, renderTarget.getFramebuffer());
                GLES20.glViewport(0, 0, framebufferSize[0], framebufferSize[1]);
                viewportNeedsUpdate = true;
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);

                ScreenMaterial material = new ScreenMaterial();
                material.use();
                material.setUniformBool(material.uniforms.flipY, texture.isFlipY());
                quadVertices.bind(material.programId);

                GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture.getTextureId());
                material.setUniformInt(material.uniforms.screenTexture, 0);
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, quadVertices.count());
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
                texture.endSharedAccess();
                quadVertices.disable();

                int[] colors = getPixelsARGB(0, 0, framebufferSize[0], framebufferSize[1], false);
                Bitmap bitmap = Bitmap.createBitmap(colors, framebufferSize[0], framebufferSize[1], Bitmap.Config.ARGB_8888);

                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
                renderTarget.destroy();
                material.destroy();

                callback.call(bitmap);
            }
        });
        xServerView.requestRender();
    }
}
