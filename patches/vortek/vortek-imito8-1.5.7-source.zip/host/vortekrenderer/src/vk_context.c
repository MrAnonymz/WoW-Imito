#include "vk_context.h"
#include "vulkan_helper.h"
#include "request_handler.h"
#include "sysvshared_memory.h"
#include "string_utils.h"
#include "jni_utils.h"
#include <android/log.h>
#include <errno.h>
#include <sys/socket.h>

static void loadJMethods(JMethods* jmethods) {
    JNIEnv* env;
    (*jmethods->jvm)->AttachCurrentThread(jmethods->jvm, &env, NULL);
    jmethods->env = env;

    jclass cls = (*env)->GetObjectClass(env, jmethods->obj);
    jmethods->getWindowWidth = (*env)->GetMethodID(env, cls, "getWindowWidth", "(I)I");
    jmethods->getWindowHeight = (*env)->GetMethodID(env, cls, "getWindowHeight", "(I)I");
    jmethods->attachWindowHardwareBuffer = (*env)->GetMethodID(env, cls, "attachWindowHardwareBuffer", "(IIJ)Z");
    jmethods->releaseWindowHardwareBuffer = (*env)->GetMethodID(env, cls, "releaseWindowHardwareBuffer", "(J)V");
    jmethods->updateWindowContent = (*env)->GetMethodID(env, cls, "updateWindowContent", "(IJ)I");
    jmethods->awaitWindowContent = (*env)->GetMethodID(env, cls, "awaitWindowContent", "(JZ)I");
    jmethods->recordSwapchainStartup = (*env)->GetMethodID(env, cls, "recordSwapchainStartup", "(IIIIII)V");
    (*env)->DeleteLocalRef(env, cls);
}

static ExtraDataRequest* waitForExtraDataRequest(VkContext* context, uint16_t requestId) {
    ExtraDataRequest* result = NULL;
    pthread_mutex_lock(&context->extraDataRequestsMutex);
    while (context->status >= 0) {
        result = NULL;
        for (int i = 0; i < context->extraDataRequests.size; i++) {
            ExtraDataRequest* extraDataRequest = context->extraDataRequests.elements[i];
            if (extraDataRequest->requestId == requestId) {
                result = extraDataRequest;
                ArrayList_removeAt(&context->extraDataRequests, i);
                break;
            }
        }
        if (result) break;
        // The socket receiver signals after queuing data. Do not poll at 10 kHz
        // while that thread is descheduled on a busy or thermally limited phone.
        pthread_cond_wait(&context->extraDataRequestsReady, &context->extraDataRequestsMutex);
    }
    pthread_mutex_unlock(&context->extraDataRequestsMutex);
    return result;
}

static void* requestHandlerThread(void* param) {
    VkContext* context = param;
    loadJMethods(&context->jmethods);
    ExtraDataRequest* extraDataRequest = NULL;

    while (context->status >= 0) {
        int requestCode = vt_recv(context->serverRing, &context->inputBuffer, &context->inputBufferSize, &context->memoryPool);
        if (requestCode < 0) break;

        if (requestCode > INT16_MAX) {
            uint16_t requestId = requestCode & 0xffff;
            requestCode = requestCode >> 16;
            extraDataRequest = waitForExtraDataRequest(context, requestId);
            if (!extraDataRequest) break;
            context->inputBufferSize = extraDataRequest->size;
            context->inputBuffer = extraDataRequest->data;
        }

#if DEBUG_MODE
        println("handleRequest name=%s size=%d", requestCodeToString(requestCode), context->inputBufferSize);
#endif

        HandleRequestFunc handleRequestFunc = getHandleRequestFunc(requestCode);
        if (handleRequestFunc) handleRequestFunc(context);

        vt_free(&context->memoryPool);

        if (extraDataRequest) {
            MEMFREE(extraDataRequest->data);
            MEMFREE(extraDataRequest);
        }

        context->inputBuffer = NULL;
        context->inputBufferSize = 0;
    }

    (*context->jmethods.jvm)->DetachCurrentThread(context->jmethods.jvm);
    vt_free(&context->memoryPool);
    return NULL;
}

static bool setupRingBuffers(VkContext* context) {
    const char* stage = "allocate_server";
    int shmFds[2] = {-1, -1};
    shmFds[0] = ashmemCreateRegion("vt-server-ring", RingBuffer_getSHMemSize(SERVER_RING_BUFFER_SIZE));
    if (shmFds[0] < 0) goto failed;
    stage = "allocate_client";
    shmFds[1] = ashmemCreateRegion("vt-client-ring", RingBuffer_getSHMemSize(CLIENT_RING_BUFFER_SIZE));
    if (shmFds[1] < 0) goto failed;

    stage = "map_server";
    context->serverRing = RingBuffer_create(shmFds[0], SERVER_RING_BUFFER_SIZE);
    if (!context->serverRing) goto failed;

    stage = "map_client";
    context->clientRing = RingBuffer_create(shmFds[1], CLIENT_RING_BUFFER_SIZE);
    if (!context->clientRing) goto failed;

    stage = "send_descriptors";
    int result = send_fds(context->clientFd, shmFds, 2, NULL, 0);
    if (result < 0) goto failed;
    close(shmFds[0]);
    close(shmFds[1]);
    int threadError = pthread_create(&context->requestHandlerThread, NULL, requestHandlerThread, context);
    if (threadError) {
        context->requestHandlerThread = 0;
        __android_log_print(ANDROID_LOG_ERROR, "WrathRTVortek", "ring_thread error=%d", threadError);
        return false;
    }
    return true;
failed:
    __android_log_print(ANDROID_LOG_ERROR, "WrathRTVortek", "ring_setup stage=%s errno=%d", stage, errno);
    if (shmFds[0] >= 0) close(shmFds[0]);
    if (shmFds[1] >= 0) close(shmFds[1]);
    return false;
}

VkContext* createVkContext(JNIEnv* env, jobject obj, int clientFd, jobject options) {
    jobjectArray exposedDeviceExtensions = getJFieldByName(env, options, "exposedDeviceExtensions", JSIGNATURE_ARRAY_STRING).l;

    VkContext* context = calloc(1, sizeof(VkContext));
    if (!context) return NULL;
    context->clientFd = clientFd;
    context->vkMaxVersion = getJFieldByName(env, options, "vkMaxVersion", "I").i;
    context->maxDeviceMemory = getJFieldByName(env, options, "maxDeviceMemory", "S").s;
    context->imageCacheSize = getJFieldByName(env, options, "imageCacheSize", "S").s;
    context->resourceMemoryType = getJFieldByName(env, options, "resourceMemoryType", "B").b;
    context->linearDmaPresentation = getJFieldByName(env, options, "linearDmaPresentation", "Z").z;
    context->exposedDeviceExtensions = jstringArrayToCharArray(env, exposedDeviceExtensions);

    pthread_mutex_init(&context->extraDataRequestsMutex, NULL);
    pthread_cond_init(&context->extraDataRequestsReady, NULL);

    context->memoryPool.data = calloc(MEMORY_POOL_MAX_SIZE, 1);
    context->threadPool = ThreadPool_init(THREAD_POOL_NUM_THREADS);
    int compilerThreads = getJFieldByName(env, options, "compilerThreads", "I").i;
    context->pipelineThreadPool = ThreadPool_init(compilerThreads);
    context->waitThreadPool = ThreadPool_init(THREAD_POOL_NUM_THREADS);
    if (!context->memoryPool.data || !context->threadPool || !context->pipelineThreadPool || !context->waitThreadPool) {
        destroyVkContext(env, context);
        return NULL;
    }

    (*env)->GetJavaVM(env, &context->jmethods.jvm);
    context->jmethods.obj = (*env)->NewGlobalRef(env, obj);

    if (!setupRingBuffers(context)) {
        destroyVkContext(env, context);
        return NULL;
    }

    return context;
}

void failVkContext(VkContext* context, VkResult error) {
    pthread_mutex_lock(&context->extraDataRequestsMutex);
    context->status = error;
    pthread_cond_broadcast(&context->extraDataRequestsReady);
    pthread_mutex_unlock(&context->extraDataRequestsMutex);
    if (context->serverRing) RingBuffer_setStatus(context->serverRing, RING_STATUS_EXIT);
    if (context->clientRing) RingBuffer_setStatus(context->clientRing, RING_STATUS_EXIT);
    // A guest may await a descriptor instead of a ring reply: release both.
    shutdown(context->clientFd, SHUT_RDWR);
}

void destroyVkContext(JNIEnv* env, VkContext* context) {
    if (!context) return;
    failVkContext(context, VK_ERROR_DEVICE_LOST);

    if (context->requestHandlerThread) {
        RingBuffer_setStatus(context->serverRing, RING_STATUS_EXIT);
        RingBuffer_setStatus(context->clientRing, RING_STATUS_EXIT);
        pthread_join(context->requestHandlerThread, NULL);

        context->requestHandlerThread = 0;
    }
    if (context->threadPool) ThreadPool_destroy(context->threadPool);
    context->threadPool = NULL;
    ThreadPool_destroy(context->waitThreadPool);
    ThreadPool_destroy(context->pipelineThreadPool);
    if (context->shaderInspector) {
        free(context->shaderInspector);
    }
    RingBuffer_free(context->serverRing);
    RingBuffer_free(context->clientRing);

    if (context->jmethods.obj) {
        (*env)->DeleteGlobalRef(env, context->jmethods.obj);
        context->jmethods.obj = NULL;
    }

    context->graphicsQueueIndex = 0;

    if (context->textureDecoder && !context->gpuWorkRetired) {
        TextureDecoder_destroy(context->textureDecoder);
    }
    // A cancelled/failed fence wait does not prove GPU completion, even if the
    // relay returns DEVICE_LOST. Keep staging allocations and imported images
    // alive on this terminal path; do not free them under pending GPU work or
    // hang shutdown in an unbounded DeviceWaitIdle. Process exit retires them.
    context->textureDecoder = NULL;

    ArrayList_free(context->exposedDeviceExtensions, true);
    MEMFREE(context->exposedDeviceExtensions);

    ArrayList_free(context->disabledDeviceExtensions, true);
    MEMFREE(context->disabledDeviceExtensions);

    for (int i=0; i<context->extraDataRequests.size; i++) {
        ExtraDataRequest* pending=context->extraDataRequests.elements[i];
        free(pending->data);
    }
    ArrayList_free(&context->extraDataRequests, true);
    pthread_cond_destroy(&context->extraDataRequestsReady);
    pthread_mutex_destroy(&context->extraDataRequestsMutex);

    MEMFREE(context->memoryPool.data);
    MEMFREE(context->engineName);
    forgetPresentationDevice(&context->presentationDevices,&context->presentationQueues,VK_NULL_HANDLE);
    free(context);
}

bool handleExtraDataRequest(VkContext* context, uint16_t requestId, int requestLength) {
    if (requestLength < 0) return false;
    void* data = NULL;
    if (requestLength > 0) {
        data = calloc(requestLength, 1);
        if (!data) return false;
        int bytesRead = sock_read(context->clientFd, data, requestLength);
        if (bytesRead != requestLength) {free(data); return false;}
    }

    ExtraDataRequest* extraDataRequest = calloc(1, sizeof(ExtraDataRequest));
    if (!extraDataRequest) {free(data); return false;}
    extraDataRequest->requestId = requestId;
    extraDataRequest->size = requestLength;
    extraDataRequest->data = data;

    pthread_mutex_lock(&context->extraDataRequestsMutex);
    if (context->status < 0) {
        pthread_mutex_unlock(&context->extraDataRequestsMutex);
        free(data);free(extraDataRequest);return false;
    }
    ArrayList_add(&context->extraDataRequests, extraDataRequest);
    pthread_cond_signal(&context->extraDataRequestsReady);
    pthread_mutex_unlock(&context->extraDataRequestsMutex);
    return true;
}
