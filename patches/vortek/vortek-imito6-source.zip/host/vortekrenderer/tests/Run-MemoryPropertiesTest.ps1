$ErrorActionPreference = 'Stop'
$project = 'E:\Code\MD\WoW-Enorial-Android'
$compiler = Join-Path $project 'build-tools\sdk\ndk\24.0.8215888\toolchains\llvm\prebuilt\windows-x86_64\bin\clang.exe'
$kernel32 = 'C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0\um\x64\kernel32.lib'
$header = Get-Content -LiteralPath (Join-Path $PSScriptRoot '..\include\vortek_serializer.h') -Raw
$begin = $header.IndexOf('static inline int vt_sizeof_VkMemoryHeap(')
$end = $header.IndexOf('static inline int vt_sizeof_VkPhysicalDeviceMemoryBudgetPropertiesEXT(', $begin)
if ($begin -lt 0 -or $end -lt $begin) { throw 'Serializer block not found' }
$production = $header.Substring($begin, $end - $begin)
$guestHeader = Get-Content -LiteralPath (Join-Path $project 'build-tools/compat-native/vortek-source/brunodev85-vortek-b1730c5/include/vortek_serializer.h') -Raw
$guestBegin = $guestHeader.IndexOf('static inline int vt_sizeof_VkMemoryHeap(')
$guestEnd = $guestHeader.IndexOf('static inline int vt_sizeof_VkPhysicalDeviceMemoryBudgetPropertiesEXT(', $guestBegin)
if ($guestBegin -lt 0 -or $guestEnd -lt $guestBegin) { throw 'Guest serializer block not found' }
$guest = $guestHeader.Substring($guestBegin, $guestEnd - $guestBegin)
if (($production -replace '\s+', '') -cne ($guest -replace '\s+', '')) {
    throw 'Host/guest memory wire serializers differ; do not deploy only one endpoint'
}
# Test the real, already-shipped implementation. The historical proposal was
# applied to both endpoints; treating it as pending would encourage a bad redo.
$results = foreach ($variant in @('production', 'guest')) {
    $code = if ($variant -eq 'production') { $production } else { $guest }
    [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'memory_properties_wire.inc'), $code)
    $exe = Join-Path $PSScriptRoot "memory_properties_$variant.exe"
    $obj = Join-Path $PSScriptRoot "memory_properties_$variant.obj"
    & $compiler --target=x86_64-pc-windows-msvc -ffreestanding -fno-builtin -fno-stack-protector -O1 -c `
        '-I' (Join-Path $PSScriptRoot '..\include') `
        (Join-Path $PSScriptRoot 'memory_properties_wire_test.c') -o $obj
    if ($LASTEXITCODE -ne 0) { throw "Compile failed: $variant" }
    & (Join-Path (Split-Path $compiler) 'ld.lld.exe') -flavor link /entry:mainCRTStartup /subsystem:console $obj $kernel32 "/out:$exe"
    if ($LASTEXITCODE -ne 0) { throw "Link failed: $variant" }
    & $exe
    $failed = $LASTEXITCODE
    if ($failed -ne 0) { throw "$variant serializer failed $failed cases" }
    [pscustomobject]@{ Variant = $variant; Cases = 16; FailedCases = $failed }
    Remove-Item -LiteralPath $exe, $obj
}
Remove-Item -LiteralPath (Join-Path $PSScriptRoot 'memory_properties_wire.inc')
$results | ConvertTo-Json
