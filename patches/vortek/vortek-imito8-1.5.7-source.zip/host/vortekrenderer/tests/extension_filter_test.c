#include "../include/extension_filter.h"
__declspec(dllimport) void __stdcall ExitProcess(unsigned int exit_code);

static void name(VkExtensionProperties* property, const char* value) {
    uint32_t i = 0;
    do { property->extensionName[i] = value[i]; } while (value[i++]);
}
void mainCRTStartup(void) {
    const char* extras[] = {"VK_KHR_external_memory", "VK_KHR_external_memory_fd",
                           "VK_ANDROID_external_memory_android_hardware_buffer"};
    VkExtensionProperties supported[5];
    const char* output[4] = {0};
    unsigned failures = 0;
    name(&supported[0], extras[0]);
    name(&supported[1], extras[1]);
    name(&supported[2], extras[2]);
    if (vt_filter_supported_extensions(extras, 3, supported, 3, output) != 3) failures++;
    name(&supported[1], "VK_KHR_external_fence_fd");
    if (vt_filter_supported_extensions(extras, 3, supported, 3, output) != 2 ||
        output[0] != extras[0] || output[1] != extras[2]) failures++;
    if (vt_filter_supported_extensions(extras, 3, supported, 0, output) != 0) failures++;
    if (vt_filter_supported_extensions(extras, 0, supported, 3, output) != 0) failures++;
    name(&supported[0], "VK_KHR_external_memory_fd_suffix");
    name(&supported[1], "vk_khr_external_memory_fd");
    name(&supported[2], "VK_KHR_external_memor");
    if (vt_filter_supported_extensions(extras, 3, supported, 3, output) != 0) failures++;
    name(&supported[0], extras[1]);
    name(&supported[1], extras[1]);
    if (vt_filter_supported_extensions(extras, 3, supported, 2, output) != 1 ||
        output[0] != extras[1]) failures++;
    /* Filtering never modifies the caller's requested extension array. */
    if (!vt_extension_name_equal(extras[1], "VK_KHR_external_memory_fd")) failures++;
    ExitProcess(failures);
}
