#include <stddef.h>
#include <stdint.h>
#include "../include/vulkan/vulkan_core.h"

typedef void MemoryPool;
static void *memcpy(void *dst, const void *src, size_t count) {
    unsigned char *d = dst;
    const unsigned char *s = src;
    for (size_t i = 0; i < count; i++) d[i] = s[i];
    return dst;
}
static void fill(void *dst, unsigned char value, size_t count) {
    unsigned char *d = dst;
    for (size_t i = 0; i < count; i++) d[i] = value;
}
#include "memory_properties_wire.inc"

__declspec(dllimport) void __stdcall ExitProcess(unsigned int exit_code);
_Static_assert(sizeof(VkMemoryHeap) == 16, "Test requires the 64-bit Vulkan ABI.");

static int test_case(uint32_t heap_count) {
    VkPhysicalDeviceMemoryProperties original, decoded;
    unsigned char wire[1024];
    fill(&original, 0xA7, sizeof(original));
    fill(&decoded, 0xCD, sizeof(decoded));
    fill(wire, 0xE3, sizeof(wire));
    original.memoryTypeCount = 17;
    original.memoryHeapCount = heap_count;
    for (uint32_t i = 0; i < original.memoryTypeCount; i++) {
        original.memoryTypes[i].propertyFlags = (i % 3) + 1;
        original.memoryTypes[i].heapIndex = i % heap_count;
    }
    for (uint32_t i = 0; i < heap_count; i++) {
        original.memoryHeaps[i].size = UINT64_C(0x234000000) + UINT64_C(0x100000000) * i;
        original.memoryHeaps[i].flags = (i % 2) ? 0 : 3;
    }
    int size = vt_sizeof_VkPhysicalDeviceMemoryProperties(&original);
    if (size != 8 + 17 * 8 + (int)heap_count * 12) return 1;
    vt_serialize_VkPhysicalDeviceMemoryProperties(&original, (char *)wire);
    for (size_t i = size; i < sizeof(wire); i++) if (wire[i] != 0xE3) return 2;
    size_t offset = 8 + 17 * 8;
    for (uint32_t i = 0; i < heap_count; i++) {
        uint64_t size_value;
        uint32_t flags;
        memcpy(&size_value, wire + offset, 8);
        memcpy(&flags, wire + offset + 8, 4);
        if (size_value != original.memoryHeaps[i].size || flags != original.memoryHeaps[i].flags) return 3;
        offset += 12;
    }
    vt_unserialize_VkPhysicalDeviceMemoryProperties(&decoded, (char *)wire, NULL);
    if (decoded.memoryHeapCount != heap_count || decoded.memoryTypeCount != 17) return 4;
    for (uint32_t i = 0; i < heap_count; i++)
        if (decoded.memoryHeaps[i].size != original.memoryHeaps[i].size ||
            decoded.memoryHeaps[i].flags != original.memoryHeaps[i].flags) return 5;
    for (uint32_t i = 0; i < 17; i++)
        if (decoded.memoryTypes[i].propertyFlags != original.memoryTypes[i].propertyFlags ||
            decoded.memoryTypes[i].heapIndex != original.memoryTypes[i].heapIndex) return 6;
    return 0;
}
void mainCRTStartup(void) {
    unsigned failures = 0;
    for (uint32_t count = 1; count <= VK_MAX_MEMORY_HEAPS; count++)
        if (test_case(count)) failures++;
    ExitProcess(failures);
}
