#ifndef VORTEK_TIMELINE_SEMAPHORE_H
#define VORTEK_TIMELINE_SEMAPHORE_H

#include "vortek.h"

extern void TimelineSemaphore_asyncWait(VkContext* context, char* inputBuffer, int inputBufferSize);
extern void NativeFence_asyncWait(VkContext* context, char* inputBuffer, int inputBufferSize);

#endif
