#include "shader_inspector.h"
#include "vulkan_helper.h"
#include "spirv.h"
#include "string_utils.h"

// Shader handles can be shared between Vulkan connections as well as workers.
static pthread_mutex_t shaderModuleMutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct ShaderVariantKey {
    uint32_t location;
    uint32_t value; /* vertex signedness, or fragment producer component count */
} ShaderVariantKey;

struct ShaderVariant {
    VkShaderModule module;
    ShaderVariantKey* key;
    uint32_t keyCount;
    struct ShaderVariant* next;
};

#define PACK_SPV_INST(opcode, instLength) ((opcode << 0) | (instLength << SpvWordCountShift))
#define ADD_SPV_INST(intArray, instLength, opcode, ...) \
    IntArray_addAll(intArray, instLength, PACK_SPV_INST(opcode, instLength), __VA_ARGS__)
#define IS_SPV_OP_TYPE(op) (op >= SpvOpTypeVoid && op <= SpvOpTypeForwardPointer)
#define CODE_START 5
#define MAX_ID_BOUND_OFFSET 3
#define SPV_INST_OPCODE(val) (val & SpvOpCodeMask)
#define SPV_INST_LENGTH(val) (val >> SpvWordCountShift)

#define WRITE_FILE(filename, code, sizeInBytes) \
    do { \
        char path[PATH_MAX] = {0}; \
        sprintf(path, APP_CACHE_DIR "/%s", filename); \
        FILE* f = fopen(path, "wb"); \
        fwrite((const char*)code, 1, sizeInBytes, f); \
        fclose(f); \
    } \
    while(0)

typedef struct VertexAnnotation {
    int location;
    int vecId;
    int varId;
    int varOffset;
    int signedness;
    VkFormat format;
} VertexAnnotation;

typedef struct MergeCode {
    int position;
    IntArray code;
} MergeCode;

typedef struct SpvVariableOffsets {
    int decorate;
    int variable;
    int pointer;
    int vector;
} SpvVariableOffsets;

typedef struct SpvInstFilter {
    uint32_t fields[4];
    uint32_t values[4];
    int count;
    int endIndex;
} SpvInstFilter;

typedef struct MergeSpvInstOptions {
    uint32_t* code;
    uint32_t codeSize;
    ArrayList* mergeCodes;
    int mergePosition;
    int fetchStart;
    SpvInstFilter fetchFilter;
} MergeSpvInstOptions;

static VkFormat getFallbackFormat(VkFormat format) {
    switch (format) {
        case VK_FORMAT_R8_USCALED:
            return VK_FORMAT_R8_UINT;
        case VK_FORMAT_R8_SSCALED:
            return VK_FORMAT_R8_SINT;
        case VK_FORMAT_R16_USCALED:
            return VK_FORMAT_R16_UINT;
        case VK_FORMAT_R16_SSCALED:
            return VK_FORMAT_R16_SINT;
        case VK_FORMAT_R8G8_USCALED:
            return VK_FORMAT_R8G8_UINT;
        case VK_FORMAT_R8G8_SSCALED:
            return VK_FORMAT_R8G8_SINT;
        case VK_FORMAT_R16G16_USCALED:
            return VK_FORMAT_R16G16_UINT;
        case VK_FORMAT_R16G16_SSCALED:
            return VK_FORMAT_R16G16_SINT;
        case VK_FORMAT_R16G16B16A16_USCALED:
            return VK_FORMAT_R16G16B16A16_UINT;
        case VK_FORMAT_R16G16B16A16_SSCALED:
            return VK_FORMAT_R16G16B16A16_SINT;
        case VK_FORMAT_R8G8B8A8_USCALED:
            return VK_FORMAT_R8G8B8A8_UINT;
        case VK_FORMAT_R8G8B8A8_SSCALED:
            return VK_FORMAT_R8G8B8A8_SINT;
        default:
            return format;
    }
}

static void getSpvLiteralString(uint32_t* words, int instLength, char* outString, size_t capacity) {
    if (!capacity) return;
    int numBit = 0;
    for (size_t i = 0; i < (size_t)instLength * 4 && i + 1 < capacity; i++) {
        outString[i] = (*words >> numBit) & 0xff;
        if (outString[i] == '\0') break;

        if ((numBit += 8) == 32) {
            words++;
            numBit = 0;
        }
    }
    outString[capacity - 1] = '\0';
}

static uint32_t fetchSpvInstIndex(uint32_t* code, uint32_t sizeInBytes, int start, SpvOp targetOpcode, int field, uint32_t value, bool stopOnOpFunction) {
    uint32_t instLength;
    SpvOp opcode = SpvOpNop;
    SpvOp stopOpcode = stopOnOpFunction ? SpvOpFunction : SpvOpMax;

    for (int i = start, size = sizeInBytes / sizeof(int); i < size && opcode != stopOpcode;) {
        opcode = SPV_INST_OPCODE(code[i]);
        instLength = SPV_INST_LENGTH(code[i]);

        if (opcode == targetOpcode) {
            if (field != -1) {
                if (field < instLength && code[i+field] == value) return i;
            }
            else return i;
        }
        i += instLength;
    }

    return -1;
}

static uint32_t fetchSpvInstIndex2(uint32_t* code, uint32_t sizeInBytes, int start, SpvOp targetOpcode, SpvInstFilter* filter, bool stopOnOpFunction) {
    uint32_t instLength;
    SpvOp opcode = SpvOpNop;
    SpvOp stopOpcode = stopOnOpFunction ? SpvOpFunction : SpvOpMax;
    int size = sizeInBytes / sizeof(int);
    int end = filter->endIndex > 0 && filter->endIndex < size ? filter->endIndex : size;

    for (int i = start, j; i < end && opcode != stopOpcode;) {
        opcode = SPV_INST_OPCODE(code[i]);
        instLength = SPV_INST_LENGTH(code[i]);

        if (opcode == targetOpcode && filter->count < instLength) {
            bool match = true;
            for (j = 0; j < filter->count && match; j++) match = code[i+filter->fields[j]] == filter->values[j];
            if (match) return i;
        }

        i += instLength;
    }

    return -1;
}

static void getSpvVariableName(uint32_t* code, uint32_t sizeInBytes, int varId, char* outName, size_t capacity) {
    int index = fetchSpvInstIndex(code, sizeInBytes, CODE_START, SpvOpName, 1, varId, true);
    outName[0] = '\0';
    if (index != -1) {
        int strLen = SPV_INST_LENGTH(code[index]) - 2;
        getSpvLiteralString(&code[index+2], strLen, outName, capacity);
    }
}

static uint32_t fetchSpvOpTypeIndex(uint32_t* code, uint32_t sizeInBytes, int start, int field, uint32_t value) {
    uint32_t instLength;
    SpvOp opcode = SpvOpNop;

    for (int i = start, size = sizeInBytes / sizeof(int); i < size && opcode != SpvOpFunction;) {
        opcode = SPV_INST_OPCODE(code[i]);
        instLength = SPV_INST_LENGTH(code[i]);

        if (IS_SPV_OP_TYPE(opcode)) {
            if (field != -1) {
                if (field < instLength && code[i+field] == value) return i;
            }
            else return i;
        }
        i += instLength;
    }

    return -1;
}

static void fetchSpvVariableOffsets(ShaderModule* module, SpvStorageClass storageClass, ArrayList* result) {
    uint32_t instLength;
    SpvOp opcode = SpvOpNop;
    char varname[32] = {0};
    char location[12] = {0};

    for (int i = CODE_START, j, k, l, size = module->codeSize / sizeof(uint32_t); i < size && opcode != SpvOpFunction && !IS_SPV_OP_TYPE(opcode);) {
        opcode = SPV_INST_OPCODE(module->code[i]);
        instLength = SPV_INST_LENGTH(module->code[i]);

        if (opcode == SpvOpDecorate && module->code[i+2] == SpvDecorationLocation) {
            j = fetchSpvInstIndex(module->code, module->codeSize, i, SpvOpVariable, 2, module->code[i+1], true);
            if (j != -1 && module->code[j+3] == storageClass) {
                k = fetchSpvInstIndex(module->code, module->codeSize, i, SpvOpTypePointer, 1, module->code[j+1], true);
                if (k != -1 && module->code[k+2] == storageClass) {
                    l = fetchSpvInstIndex(module->code, module->codeSize, i, SpvOpTypeVector, 1, module->code[k+3], true);
                    if (l == -1) l = fetchSpvInstIndex(module->code, module->codeSize, i, SpvOpTypeFloat, 1, module->code[k+3], true);
                    if (l != -1) {
                        getSpvVariableName(module->code, module->codeSize, module->code[j+2], varname, sizeof(varname));
                        if ((varname[0] == 'o' || varname[0] == 'v')) {
                            snprintf(location, sizeof(location), "%u", module->code[i+3]);
                            if (strcmp(varname + 1, location) == 0) {
                                SpvVariableOffsets* variableOffsets = calloc(1, sizeof(SpvVariableOffsets));
                                variableOffsets->decorate = i;
                                variableOffsets->variable = j;
                                variableOffsets->pointer = k;
                                variableOffsets->vector = l;
                                ArrayList_add(result, variableOffsets);
                            }
                        }
                    }
                }
            }
        }

        i += instLength;
    }
}

static uint32_t mergeSpvInst(MergeSpvInstOptions* options, uint32_t instLength, ...) {
    va_list valist;
    va_start(valist, instLength);
    SpvOp opcode = va_arg(valist, SpvOp);

    uint32_t resultId = 0;
    int mergePosition = 0;
    int index = fetchSpvInstIndex2(options->code, options->codeSize, options->fetchStart, opcode, &options->fetchFilter, true);
    if (index == -1) {
        for (int i = 0; i < options->mergeCodes->size; i++) {
            MergeCode* mergeCode = options->mergeCodes->elements[i];
            int oldEndIndex = options->fetchFilter.endIndex;
            options->fetchFilter.endIndex = 0;
            index = fetchSpvInstIndex2(mergeCode->code.values, mergeCode->code.size * sizeof(int), 0, opcode, &options->fetchFilter, false);
            options->fetchFilter.endIndex = oldEndIndex;
            if (index != -1) {
                resultId = mergeCode->code.values[index+1];
                mergePosition = (i + 1) * -1;
                break;
            }
        }
    }
    else {
        resultId = options->code[index+1];
        mergePosition = index + SPV_INST_LENGTH(options->code[index]);
    }

    if (resultId > 0) {
        options->mergePosition = mergePosition;
        va_end(valist);
        return resultId;
    }

    int mergeCodeIdx = options->mergePosition < 0 ? (options->mergePosition * -1) - 1 : -1;
    MergeCode* mergeCode = mergeCodeIdx == -1 ? calloc(1, sizeof(MergeCode)) : options->mergeCodes->elements[mergeCodeIdx];

    ENSURE_ARRAY_CAPACITY(mergeCode->code.size + instLength, mergeCode->code.capacity, mergeCode->code.values, sizeof(uint32_t));
    mergeCode->code.values[mergeCode->code.size++] = PACK_SPV_INST(opcode, instLength);

    for (int i = 1; i < instLength; i++) {
        uint32_t value = va_arg(valist, uint32_t);
        if (value == UINT32_MAX) value = resultId = options->code[MAX_ID_BOUND_OFFSET]++;
        mergeCode->code.values[mergeCode->code.size++] = value;
    }
    va_end(valist);

    if (mergeCodeIdx == -1) {
        mergeCode->position = options->mergePosition;
        mergeCodeIdx = options->mergeCodes->size;
        ArrayList_add(options->mergeCodes, mergeCode);
    }

    options->mergePosition = (mergeCodeIdx + 1) * -1;
    return resultId;
}

static void convertInputVariableFormatScaled(ShaderModule* module, ArrayList* mergeCodes, int decorOffset, VertexAnnotation* vertexAnnotation) {
    int index = fetchSpvInstIndex(module->code, module->codeSize, decorOffset, SpvOpTypePointer, 1, module->code[vertexAnnotation->varOffset+1], true);
    int componentCount = 1;
    if (index != -1) {
        uint32_t typeVectorId = module->code[index+3];
        index = fetchSpvInstIndex(module->code, module->codeSize, decorOffset, SpvOpTypeVector, 1, typeVectorId, true);
        if (index != -1) componentCount = module->code[index+3];
    }

    int signedness;
    switch (vertexAnnotation->format) {
        case VK_FORMAT_R8_UINT:
        case VK_FORMAT_R16_UINT:
        case VK_FORMAT_R8G8_UINT:
        case VK_FORMAT_R16G16_UINT:
        case VK_FORMAT_R8G8B8A8_UINT:
        case VK_FORMAT_R16G16B16A16_UINT:
            signedness = 0;
            break;
        default:
            signedness = 1;
            break;
    }

    index = fetchSpvOpTypeIndex(module->code, module->codeSize, decorOffset, -1, 0);
    if (index == -1) return;

    MergeSpvInstOptions typeIntOptions = {module->code, module->codeSize, mergeCodes, index, index, {{2, 3}, {32, signedness}, 2, vertexAnnotation->varOffset}};
    uint32_t typeIntId = mergeSpvInst(&typeIntOptions, 4, SpvOpTypeInt, UINT32_MAX, 32, signedness);

    MergeSpvInstOptions typeVectorOptions = {module->code, module->codeSize, mergeCodes, typeIntOptions.mergePosition, index, {{2, 3}, {typeIntId, componentCount}, 2, vertexAnnotation->varOffset}};
    uint32_t typeVectorId = componentCount == 1 ? typeIntId : mergeSpvInst(&typeVectorOptions, 4, SpvOpTypeVector, UINT32_MAX, typeIntId, componentCount);

    MergeSpvInstOptions typePointerOptions = {module->code, module->codeSize, mergeCodes, typeVectorOptions.mergePosition, index, {{2, 3}, {SpvStorageClassInput, typeVectorId}, 2, vertexAnnotation->varOffset}};
    uint32_t typePointerId = mergeSpvInst(&typePointerOptions, 4, SpvOpTypePointer, UINT32_MAX, SpvStorageClassInput, typeVectorId);

    vertexAnnotation->signedness = signedness;
    vertexAnnotation->vecId = typeVectorId;
    module->code[vertexAnnotation->varOffset+1] = typePointerId;
}

static void mergeShaderCode(ShaderModule* module, IntArray* mergeCode, int mergeOffset) {
    size_t newCodeSize;
    uint32_t* newCode = memmerge(mergeCode->values, mergeCode->size * sizeof(int), module->code, module->codeSize,
                                 mergeOffset * sizeof(int), &newCodeSize);

    MEMFREE(module->code);
    module->code = newCode;
    module->codeSize = newCodeSize;
    IntArray_clear(mergeCode);
}

static void mergeCodesSorted(ShaderModule* module, ArrayList* mergeCodes) {
    while (mergeCodes->size > 0) {
        int index = 0;
        int maxPosition = -INT32_MAX;

        for (int i = 0; i < mergeCodes->size; i++) {
            MergeCode* mergeCode = mergeCodes->elements[i];
            if (mergeCode->position > maxPosition) {
                maxPosition = mergeCode->position;
                index = i;
            }
        }

        MergeCode* mergeCode = mergeCodes->elements[index];
        mergeShaderCode(module, &mergeCode->code, mergeCode->position);
        free(mergeCode);
        ArrayList_removeAt(mergeCodes, index);
    }

    MEMFREE(mergeCodes->elements);
}

static void removeSpvInstIndices(ShaderModule* module, IntArray* instIndices) {
    if (instIndices->size == 0) return;
    IntArray_sort(instIndices);

    uint32_t instLength;
    for (int i = instIndices->size-1, j; i >= 0; i--) {
        j = instIndices->values[i];
        instLength = SPV_INST_LENGTH(module->code[j]);

        size_t newCodeSize;
        uint32_t* newCode = memdel(module->code, module->codeSize, j * sizeof(int),
                                   instLength * sizeof(int), &newCodeSize);
        if (newCode) {
            MEMFREE(module->code);
            module->code = newCode;
            module->codeSize = newCodeSize;
        }
    }

    IntArray_clear(instIndices);
}

static void removePointSizeExport(ShaderModule* module, int decorOffset, IntArray* removeInsts, ArrayList* mergeCodes) {
    int index = fetchSpvInstIndex(module->code, module->codeSize, decorOffset, SpvOpTypeFloat, 2, 32, true);
    if (index == -1) return;

    const float constValue = 1.0f;
    SpvInstFilter filter = {{1, 3}, {module->code[index+1], *(uint32_t*)&constValue}, 2, 0};
    index = fetchSpvInstIndex2(module->code, module->codeSize, decorOffset, SpvOpConstant, &filter, true);
    if (index == -1) return;

    uint32_t constf32Id = module->code[index+2];
    uint32_t varId = module->code[decorOffset+1];

    int position = decorOffset;
    bool opStoreFound = false;
    do {
        index = fetchSpvInstIndex(module->code, module->codeSize, position, SpvOpStore, 1, varId, false);
        if (index != -1) {
            if (module->code[index+2] == constf32Id) {
                opStoreFound = true;
                break;
            }
            position = index + SPV_INST_LENGTH(module->code[index+0]);
        }
    }
    while (index != -1);

    if (!opStoreFound) return;

    int varOffset = fetchSpvInstIndex(module->code, module->codeSize, decorOffset, SpvOpVariable, 2, varId, true);
    if (varOffset == -1 || module->code[varOffset+3] != SpvStorageClassOutput) return;

    int pointerOffset = fetchSpvInstIndex(module->code, module->codeSize, decorOffset, SpvOpTypePointer, 1, module->code[varOffset+1], true);
    if (pointerOffset == -1) return;

    uint32_t baseTypeId = module->code[pointerOffset+3];
    MergeSpvInstOptions typePointerOptions = {module->code, module->codeSize, mergeCodes, pointerOffset, decorOffset, {{2, 3}, {SpvStorageClassPrivate, baseTypeId}, 2, 0}};
    uint32_t typePointerId = mergeSpvInst(&typePointerOptions, 4, SpvOpTypePointer, UINT32_MAX, SpvStorageClassPrivate, baseTypeId);

    module->code[varOffset+3] = SpvStorageClassPrivate;
    module->code[varOffset+1] = typePointerId;

    IntArray_add(removeInsts, decorOffset);
}

static void removePrivateEntryPointInterfaces(ShaderModule* module) {
    // SPIR-V < 1.4 only permits Input/Output variables in OpEntryPoint.
    // Point-size adaptation makes its Output private; leaving that ID in the
    // interface produces invalid SPIR-V on stricter mobile drivers. From 1.4
    // onward used private globals MUST remain listed, so retain them there.
    if (module->code[1] >= 0x00010400) return;
    uint32_t* code = module->code;
    for (uint32_t i = CODE_START; i < module->codeSize / 4;) {
        uint32_t length = SPV_INST_LENGTH(code[i]);
        if (SPV_INST_OPCODE(code[i]) == SpvOpEntryPoint) {
            uint32_t end = i + length, first = i + 3;
            while (first < end) {
                uint32_t word = code[first++];
                if (!(word & 0xff) || !(word & 0xff00) ||
                    !(word & 0xff0000) || !(word & 0xff000000)) break;
            }
            uint32_t write = first;
            for (uint32_t read = first; read < end; read++) {
                int variable = fetchSpvInstIndex(code, module->codeSize, CODE_START,
                    SpvOpVariable, 2, code[read], true);
                if (variable == -1 || code[variable+3] != SpvStorageClassPrivate)
                    code[write++] = code[read];
            }
            uint32_t removed = end - write;
            if (removed) {
                memmove(code + write, code + end, module->codeSize - end * 4);
                module->codeSize -= removed * 4;
                length -= removed;
                code[i] = PACK_SPV_INST(SpvOpEntryPoint, length);
            }
        }
        i += length;
    }
}

static bool convertScaledInputLoads(ShaderModule* module, VertexAnnotation* annotations, int count) {
    // A shader may load the input directly or access v0.x through an Input
    // pointer first. Rewriting only the variable and direct loads leaves the
    // access-chain pointer floating-point while its base is integer, which is
    // invalid SPIR-V. Propagate the integer type through derived pointers, then
    // convert each loaded scalar/vector back to the original float result ID.
    typedef struct InputPointer { uint32_t id, type, signedness; } InputPointer;
    size_t capacity = count + 8;
    InputPointer* pointers = calloc(capacity, sizeof(*pointers));
    if (!pointers) return false;
    int pointerCount = 0;
    for (int i = 0; i < count; i++) if (annotations[i].varId != -1)
        pointers[pointerCount++] = (InputPointer){annotations[i].varId, annotations[i].vecId, annotations[i].signedness};
    int start = fetchSpvInstIndex(module->code, module->codeSize, CODE_START, SpvOpFunction, -1, 0, false);
    ArrayList merges = {0};
    for (int i = start; i != -1 && i < module->codeSize / 4;) {
        uint32_t length = SPV_INST_LENGTH(module->code[i]);
        SpvOp op = SPV_INST_OPCODE(module->code[i]);
        bool chain = op == SpvOpAccessChain || op == SpvOpInBoundsAccessChain ||
                     op == SpvOpPtrAccessChain || op == SpvOpInBoundsPtrAccessChain || op == SpvOpCopyObject;
        if (chain || op == SpvOpLoad) {
            InputPointer base = {0};
            for (int j = 0; j < pointerCount; j++)
                if (pointers[j].id == module->code[i+3]) { base = pointers[j]; break; }
            if (base.id && chain) {
                int ptr = fetchSpvInstIndex(module->code, module->codeSize, CODE_START, SpvOpTypePointer, 1, module->code[i+1], true);
                if (ptr != -1) {
                    int type = fetchSpvOpTypeIndex(module->code, module->codeSize, CODE_START, 1, module->code[ptr+3]);
                    if (type == -1) goto failed;
                    if (pointerCount == capacity) {
                        InputPointer* grown = realloc(pointers,capacity * 2 * sizeof(*pointers));
                        if (!grown) goto failed;
                        pointers = grown; capacity *= 2;
                    }
                    uint32_t components = SPV_INST_OPCODE(module->code[type]) == SpvOpTypeVector ? module->code[type+3] : 1;
                    MergeSpvInstOptions integer = {module->code,module->codeSize,&merges,start,CODE_START,{{2,3},{32,base.signedness},2,start}};
                    uint32_t integerId = mergeSpvInst(&integer,4,SpvOpTypeInt,UINT32_MAX,32,base.signedness);
                    MergeSpvInstOptions vector = {module->code,module->codeSize,&merges,integer.mergePosition,CODE_START,{{2,3},{integerId,components},2,start}};
                    uint32_t valueType = components == 1 ? integerId : mergeSpvInst(&vector,4,SpvOpTypeVector,UINT32_MAX,integerId,components);
                    MergeSpvInstOptions pointer = {module->code,module->codeSize,&merges,vector.mergePosition,CODE_START,{{2,3},{SpvStorageClassInput,valueType},2,start}};
                    module->code[i+1] = mergeSpvInst(&pointer,4,SpvOpTypePointer,UINT32_MAX,SpvStorageClassInput,valueType);
                    pointers[pointerCount++] = (InputPointer){module->code[i+2],valueType,base.signedness};
                }
            } else if (base.id && op == SpvOpLoad) {
                uint32_t resultType = module->code[i+1], resultId = module->code[i+2];
                uint32_t integerLoad = module->code[MAX_ID_BOUND_OFFSET]++;
                module->code[i+1] = base.type; module->code[i+2] = integerLoad;
                MergeCode* conversion = calloc(1,sizeof(*conversion));
                if (!conversion) goto failed;
                conversion->position = i + length;
                ADD_SPV_INST(&conversion->code,4,base.signedness ? SpvOpConvertSToF : SpvOpConvertUToF,resultType,resultId,integerLoad);
                ArrayList_add(&merges,conversion);
            }
        }
        i += length;
    }
    if (merges.size) mergeCodesSorted(module,&merges);
    free(pointers);
    return true;
failed:
    for (int i = 0; i < merges.size; i++) {
        MergeCode* merge = merges.elements[i];
        IntArray_clear(&merge->code);
    }
    ArrayList_free(&merges,true);
    free(pointers);
    return false;
}

static bool inspectVertexShaderCode(ShaderInspector* shaderInspector, ShaderModule* module, VertexAnnotation* vertexAnnotations, int vertexAnnotationCount) {
    uint32_t instLength;
    SpvOp opcode = SpvOpNop;
    ArrayList mergeCodes = {0};
    IntArray removeInsts = {0};

    for (int i = CODE_START, size = module->codeSize / sizeof(uint32_t); i < size && opcode != SpvOpFunction && !IS_SPV_OP_TYPE(opcode);) {
        opcode = SPV_INST_OPCODE(module->code[i]);
        instLength = SPV_INST_LENGTH(module->code[i]);

        if (opcode == SpvOpCapability) {
            if (shaderInspector->checkClipDistance && module->code[i+1] == SpvCapabilityClipDistance) IntArray_add(&removeInsts, i);
        }
        else if (opcode == SpvOpDecorate && module->code[i+2] == SpvDecorationBuiltIn) {
            SpvBuiltIn builtIn = module->code[i+3];
            if (shaderInspector->checkClipDistance && builtIn == SpvBuiltInClipDistance) {
                IntArray_add(&removeInsts, i);
            }
            else if (shaderInspector->removePointSizeExport && builtIn == SpvBuiltInPointSize) {
                removePointSizeExport(module, i, &removeInsts, &mergeCodes);
            }
        }

        i += instLength;
    }

    removeSpvInstIndices(module, &removeInsts);

    if (shaderInspector->convertFormatScaled) {
        opcode = SpvOpNop;
        for (int i = CODE_START, j, size = module->codeSize / sizeof(uint32_t); i < size && opcode != SpvOpFunction && !IS_SPV_OP_TYPE(opcode);) {
            opcode = SPV_INST_OPCODE(module->code[i]);
            instLength = SPV_INST_LENGTH(module->code[i]);

            if (opcode == SpvOpDecorate && module->code[i+2] == SpvDecorationLocation) {
                uint32_t location = module->code[i+3];
                for (j = 0; j < vertexAnnotationCount; j++) {
                    VertexAnnotation* vertexAnnotation = &vertexAnnotations[j];
                    if (vertexAnnotation->location == location) {
                        uint32_t varId = module->code[i+1];

                        int index = fetchSpvInstIndex(module->code, module->codeSize, i, SpvOpVariable, 2, varId, true);
                        if (index != -1 && module->code[index+3] == SpvStorageClassInput) {
                            vertexAnnotation->varId = varId;
                            vertexAnnotation->varOffset = index;
                            convertInputVariableFormatScaled(module, &mergeCodes, i, vertexAnnotation);
                        }
                        break;
                    }
                }
            }

            i += instLength;
        }
    }

    if (mergeCodes.size > 0) {
        mergeCodesSorted(module, &mergeCodes);
    }
    if (shaderInspector->convertFormatScaled && vertexAnnotationCount &&
        !convertScaledInputLoads(module,vertexAnnotations,vertexAnnotationCount)) return false;
    if (shaderInspector->removePointSizeExport) removePrivateEntryPointInterfaces(module);
    return true;
}

static void inspectFragmentShaderCode(ShaderInspector* shaderInspector, ShaderModule* vsModule, ShaderModule* fsModule) {
    if (!shaderInspector->checkInOutVariablesSize) return;

    ArrayList mergeCodes = {0};

    ArrayList vsVariables = {0};
    fetchSpvVariableOffsets(vsModule, SpvStorageClassOutput, &vsVariables);

    ArrayList fsVariables = {0};
    fetchSpvVariableOffsets(fsModule, SpvStorageClassInput, &fsVariables);
    typedef struct WidenedInput { uint32_t variable, type, components; } WidenedInput;
    WidenedInput* widened = fsVariables.size ? calloc(fsVariables.size, sizeof(*widened)) : NULL;
    if (fsVariables.size && !widened) {
        ArrayList_free(&vsVariables, true); ArrayList_free(&fsVariables, true); return;
    }
    int widenedCount = 0;

    for (int i = 0, j; i < fsVariables.size; i++) {
        SpvVariableOffsets* fsVariableOffsets = fsVariables.elements[i];
        uint32_t fsLocation = fsModule->code[fsVariableOffsets->decorate+3];
        uint32_t fsComponentCount = SPV_INST_OPCODE(fsModule->code[fsVariableOffsets->vector]) == SpvOpTypeVector ? fsModule->code[fsVariableOffsets->vector+3] : 1;

        for (j = 0; j < vsVariables.size; j++) {
            SpvVariableOffsets* vsVariableOffsets = vsVariables.elements[j];
            uint32_t vsLocation = vsModule->code[vsVariableOffsets->decorate+3];
            uint32_t vsComponentCount = SPV_INST_OPCODE(vsModule->code[vsVariableOffsets->vector]) == SpvOpTypeVector ? vsModule->code[vsVariableOffsets->vector+3] : 1;

            if (fsLocation == vsLocation && fsComponentCount < vsComponentCount) {
                uint32_t componentType = fsComponentCount > 1 ? fsModule->code[fsVariableOffsets->vector+2] : fsModule->code[fsVariableOffsets->vector+1];
                int componentTypeIndex = fsComponentCount > 1 ? fetchSpvOpTypeIndex(fsModule->code, fsModule->codeSize, fsVariableOffsets->decorate, 1, componentType) : fsVariableOffsets->vector;
                if (componentTypeIndex != -1) {
                    uint32_t componentCount = MAX(vsComponentCount, fsComponentCount);
                    int mergePosition = componentTypeIndex + SPV_INST_LENGTH(fsModule->code[componentTypeIndex]);

                    MergeSpvInstOptions typeVectorOptions = {fsModule->code, fsModule->codeSize, &mergeCodes, mergePosition, componentTypeIndex, {{2, 3}, {componentType, componentCount}, 2, fsVariableOffsets->variable}};
                    uint32_t typeVectorId = mergeSpvInst(&typeVectorOptions, 4, SpvOpTypeVector, UINT32_MAX, componentType, componentCount);

                    MergeSpvInstOptions typePointerOptions = {fsModule->code, fsModule->codeSize, &mergeCodes, typeVectorOptions.mergePosition, componentTypeIndex, {{2, 3}, {SpvStorageClassInput, typeVectorId}, 2, fsVariableOffsets->variable}};
                    uint32_t typePointerId = mergeSpvInst(&typePointerOptions, 4, SpvOpTypePointer, UINT32_MAX, SpvStorageClassInput, typeVectorId);

                    fsModule->code[fsVariableOffsets->variable+1] = typePointerId;
                    widened[widenedCount++] = (WidenedInput){
                        fsModule->code[fsVariableOffsets->variable+2], typeVectorId, fsComponentCount};
                }

                break;
            }
        }
    }

    ArrayList_free(&vsVariables, true);
    ArrayList_free(&fsVariables, true);

    mergeCodesSorted(fsModule, &mergeCodes);
    // Changing just the Input pointer type leaves OpLoad with its old result
    // type, which is invalid SPIR-V. Read the widened value, then preserve the
    // consumer's original scalar/vector value and result ID.
    IntArray instructions = {0};
    for (int i = 0; i < widenedCount; i++) {
        int position = fetchSpvInstIndex(fsModule->code, fsModule->codeSize, CODE_START, SpvOpFunction, -1, 0, false);
        while (position != -1) {
            int load = fetchSpvInstIndex(fsModule->code, fsModule->codeSize, position, SpvOpLoad, 3, widened[i].variable, false);
            if (load == -1) break;
            uint32_t originalType = fsModule->code[load+1], originalId = fsModule->code[load+2];
            uint32_t wideId = fsModule->code[MAX_ID_BOUND_OFFSET]++;
            fsModule->code[load+1] = widened[i].type;
            fsModule->code[load+2] = wideId;
            position = load + SPV_INST_LENGTH(fsModule->code[load]);
            if (widened[i].components == 1) {
                ADD_SPV_INST(&instructions, 5, SpvOpCompositeExtract, originalType, originalId, wideId, 0);
            } else {
                IntArray_add(&instructions, PACK_SPV_INST(SpvOpVectorShuffle, 5 + widened[i].components));
                IntArray_add(&instructions, originalType); IntArray_add(&instructions, originalId);
                IntArray_add(&instructions, wideId); IntArray_add(&instructions, wideId);
                for (uint32_t c = 0; c < widened[i].components; c++) IntArray_add(&instructions, c);
            }
            int inserted = instructions.size;
            mergeShaderCode(fsModule, &instructions, position);
            position += inserted;
        }
    }
    IntArray_clear(&instructions);
    free(widened);
}

static void removeImageBoundCheck(uint32_t* code, uint32_t codeSize) {
    uint32_t instLength;
    SpvOp opcode = SpvOpNop;
    bool inspectOpSelect = false;

    for (int i = CODE_START, size = codeSize / sizeof(uint32_t); i < size;) {
        opcode = SPV_INST_OPCODE(code[i]);
        instLength = SPV_INST_LENGTH(code[i]);

        if (opcode == SpvOpSampledImage || opcode == SpvOpImageFetch) {
            inspectOpSelect = true;
        }
        else if (opcode == SpvOpSelect && inspectOpSelect) {
            uint32_t* object1Id = &code[i+4];
            uint32_t* object2Id = &code[i+5];
            int index = fetchSpvInstIndex(code, codeSize, CODE_START, SpvOpConstantComposite, 2, *object2Id, true);

            uint32_t scalarId = index != -1 ? code[index+3] : *object2Id;
            index = fetchSpvInstIndex(code, codeSize, CODE_START, SpvOpConstant, 2, scalarId, true);
            if (index != -1) {
                uint32_t constValue = code[index+3];
                if (constValue == 0) *object2Id = *object1Id;
            }

            inspectOpSelect = false;
        }
        else if (opcode == SpvOpStore) {
            inspectOpSelect = false;
        }

        i += instLength;
    }
}

static SpvExecutionModel getSpvExecutionModel(const uint32_t* code, uint32_t sizeInBytes) {
    if (code[0] != SpvMagicNumber) return SpvExecutionModelMax;
    int index = fetchSpvInstIndex(code, sizeInBytes, CODE_START, SpvOpEntryPoint, -1, 0, true);
    return index != -1 ? code[index+1] : SpvExecutionModelMax;
}

ShaderInspector* ShaderInspector_create(VkContext* context, VkPhysicalDevice physicalDevice, VkPhysicalDeviceFeatures* supportedFeatures) {
    ShaderInspector* shaderInspector = calloc(1, sizeof(ShaderInspector));
    if (!shaderInspector) return NULL;
    shaderInspector->checkClipDistance = supportedFeatures->shaderClipDistance == VK_FALSE;

    bool isMaliDevice = context->driverID == VK_DRIVER_ID_ARM_PROPRIETARY;
    bool isDXVKEngine = context->engineName ? strcmp(context->engineName, "DXVK") == 0 : false;

    if (isMaliDevice) {
        VkFormatProperties formatProperties = {0};
        vulkanWrapper.vkGetPhysicalDeviceFormatProperties(physicalDevice, VK_FORMAT_R8G8B8A8_SSCALED, &formatProperties);
        shaderInspector->convertFormatScaled = !(formatProperties.bufferFeatures & VK_FORMAT_FEATURE_VERTEX_BUFFER_BIT);
    }
    else shaderInspector->convertFormatScaled = true;

    shaderInspector->removeImageBoundCheck = isMaliDevice && isDXVKEngine;
    if (isDXVKEngine && context->engineVersion > MAKE_ENGINE_VERSION(2, 3, 1)) {
        shaderInspector->removePointSizeExport = true;
        shaderInspector->checkInOutVariablesSize = true;
    }

    return shaderInspector;
}

VkResult ShaderInspector_createModule(ShaderInspector* shaderInspector, VkDevice device, const uint32_t* code, size_t codeSize, ShaderModule** ppModule) {
    *ppModule = NULL;
    if (!shaderInspector) return VK_ERROR_OUT_OF_HOST_MEMORY;
    ShaderModule* shaderModule = calloc(1, sizeof(ShaderModule));
    if (!shaderModule) return VK_ERROR_OUT_OF_HOST_MEMORY;
    shaderModule->module = VK_NULL_HANDLE;
    SpvExecutionModel executionModel = getSpvExecutionModel(code, codeSize);

    VkResult result = VK_SUCCESS;
    if (executionModel == SpvExecutionModelVertex || executionModel == SpvExecutionModelFragment) {
        shaderModule->codeSize = codeSize;
        shaderModule->code = memdup(code, codeSize);
        if (!shaderModule->code) {free(shaderModule);return VK_ERROR_OUT_OF_HOST_MEMORY;}
        if (shaderInspector->removeImageBoundCheck)
            removeImageBoundCheck(shaderModule->code, codeSize);
    }
    else {
        VkShaderModuleCreateInfo createInfo = {0};
        createInfo.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
        createInfo.pCode = code;
        createInfo.codeSize = codeSize;
        result = vulkanWrapper.vkCreateShaderModule(device, &createInfo, NULL, &shaderModule->module);
        if (result != VK_SUCCESS) {free(shaderModule);return result;}
    }

    *ppModule = shaderModule;
    return result;
}

static int compareVariantKey(const void* left, const void* right) {
    const ShaderVariantKey *a = left, *b = right;
    if (a->location != b->location) return a->location < b->location ? -1 : 1;
    return a->value == b->value ? 0 : a->value < b->value ? -1 : 1;
}

static bool unsignedScaled(VkFormat format) {
    return format == VK_FORMAT_R8_USCALED || format == VK_FORMAT_R8G8_USCALED ||
        format == VK_FORMAT_R8G8B8A8_USCALED || format == VK_FORMAT_R16_USCALED ||
        format == VK_FORMAT_R16G16_USCALED || format == VK_FORMAT_R16G16B16A16_USCALED;
}

static VkResult materializeVariant(ShaderInspector* inspector, VkDevice device,
        ShaderModule* source, VkShaderStageFlagBits stage, ShaderModule* vertex,
        const VkPipelineVertexInputStateCreateInfo* input, VkShaderModule* result) {
    ShaderVariantKey* key = NULL;
    uint32_t count = 0;
    if (stage == VK_SHADER_STAGE_VERTEX_BIT && inspector->convertFormatScaled && input) {
        if (input->vertexAttributeDescriptionCount > 1024) return VK_ERROR_OUT_OF_HOST_MEMORY;
        if (input->vertexAttributeDescriptionCount) {
            key = calloc(input->vertexAttributeDescriptionCount, sizeof(*key));
            if (!key) return VK_ERROR_OUT_OF_HOST_MEMORY;
        }
        for (uint32_t i = 0; i < input->vertexAttributeDescriptionCount; i++) {
            const VkVertexInputAttributeDescription* attr = &input->pVertexAttributeDescriptions[i];
            if (isFormatScaled(attr->format))
                key[count++] = (ShaderVariantKey){attr->location, unsignedScaled(attr->format) ? 1u : 2u};
        }
    } else if (stage == VK_SHADER_STAGE_FRAGMENT_BIT && inspector->checkInOutVariablesSize && vertex) {
        // Fragment adaptation depends on the producer interface, not on the
        // order in which pipelines happen to compile. Preserve the original
        // vertex SPIR-V so an already compiled producer works here as well.
        ArrayList variables = {0};
        fetchSpvVariableOffsets(vertex, SpvStorageClassOutput, &variables);
        if (variables.size) {
            key = calloc(variables.size, sizeof(*key));
            if (!key) { ArrayList_free(&variables, true); return VK_ERROR_OUT_OF_HOST_MEMORY; }
        }
        for (int i = 0; i < variables.size; i++) {
            SpvVariableOffsets* offsets = variables.elements[i];
            key[count++] = (ShaderVariantKey){vertex->code[offsets->decorate+3],
                SPV_INST_OPCODE(vertex->code[offsets->vector]) == SpvOpTypeVector ? vertex->code[offsets->vector+3] : 1};
        }
        ArrayList_free(&variables, true);
    }
    if (count > 1) qsort(key, count, sizeof(*key), compareVariantKey);
    for (ShaderVariant* cached = source->variants; cached; cached = cached->next) {
        if (cached->keyCount == count && (!count || !memcmp(cached->key, key, count * sizeof(*key)))) {
            free(key); *result = cached->module; return VK_SUCCESS;
        }
    }
    ShaderVariant* variant = calloc(1, sizeof(*variant));
    ShaderModule work = {.codeSize = source->codeSize};
    work.code = memdup(source->code, source->codeSize);
    if (!variant || !work.code) { free(key); free(variant); free(work.code); return VK_ERROR_OUT_OF_HOST_MEMORY; }
    if (stage == VK_SHADER_STAGE_VERTEX_BIT) {
        VertexAnnotation* annotations = count ? calloc(count, sizeof(*annotations)) : NULL;
        if (count && !annotations) { free(key); free(variant); free(work.code); return VK_ERROR_OUT_OF_HOST_MEMORY; }
        for (uint32_t i = 0; i < count; i++) {
            annotations[i] = (VertexAnnotation){.location = key[i].location,
                .format = key[i].value == 1 ? VK_FORMAT_R8_UINT : VK_FORMAT_R8_SINT,
                .vecId = -1, .varId = -1, .varOffset = -1};
        }
        bool converted = inspectVertexShaderCode(inspector, &work, annotations, count);
        free(annotations);
        if (!converted) { free(key); free(variant); free(work.code); return VK_ERROR_OUT_OF_HOST_MEMORY; }
    } else if (vertex) {
        inspectFragmentShaderCode(inspector, vertex, &work);
    }
    VkShaderModuleCreateInfo info = {.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
        .pCode = work.code, .codeSize = work.codeSize};
    VkResult status = vulkanWrapper.vkCreateShaderModule(device, &info, NULL, &variant->module);
    free(work.code);
    if (status != VK_SUCCESS) { free(key); free(variant); return status; }
    variant->key = key; variant->keyCount = count;
    variant->next = source->variants; source->variants = variant;
    *result = variant->module;
    return VK_SUCCESS;
}

VkResult ShaderInspector_inspectShaderStages(ShaderInspector* inspector, VkDevice device, VkPipelineShaderStageCreateInfo* stages, uint32_t stageCount, const VkPipelineVertexInputStateCreateInfo* input) {
    if (!inspector || stageCount > 64) return VK_ERROR_OUT_OF_HOST_MEMORY;
    VkShaderModule resolved[64] = {0};
    pthread_mutex_lock(&shaderModuleMutex);
    ShaderModule* vertex = NULL;
    for (uint32_t i = 0; i < stageCount; i++)
        if (stages[i].stage == VK_SHADER_STAGE_VERTEX_BIT) vertex = (ShaderModule*)stages[i].module;
    VkResult status = VK_SUCCESS;
    for (uint32_t i = 0; i < stageCount; i++) {
        ShaderModule* module = (ShaderModule*)stages[i].module;
        if (!module) continue;
        if (stages[i].stage == VK_SHADER_STAGE_VERTEX_BIT || stages[i].stage == VK_SHADER_STAGE_FRAGMENT_BIT) {
            status = materializeVariant(inspector, device, module, stages[i].stage, vertex, input, &resolved[i]);
        } else {
            if (!module->module) {
                VkShaderModuleCreateInfo info = {.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
                    .pCode = module->code, .codeSize = module->codeSize};
                status = vulkanWrapper.vkCreateShaderModule(device, &info, NULL, &module->module);
                if (status == VK_SUCCESS) { MEMFREE(module->code); module->codeSize = 0; }
            }
            resolved[i] = module->module;
        }
        if (status != VK_SUCCESS) break;
    }
    if (status == VK_SUCCESS) {
        if (vertex && input && inspector->convertFormatScaled)
            for (uint32_t i = 0; i < input->vertexAttributeDescriptionCount; i++) {
                VkVertexInputAttributeDescription* attr = (VkVertexInputAttributeDescription*)&input->pVertexAttributeDescriptions[i];
                attr->format = getFallbackFormat(attr->format);
            }
        for (uint32_t i = 0; i < stageCount; i++) stages[i].module = resolved[i];
    }
    pthread_mutex_unlock(&shaderModuleMutex);
    return status;
}

void ShaderInspector_destroyModule(VkDevice device, ShaderModule* module) {
    if (!module) return;
    pthread_mutex_lock(&shaderModuleMutex);
    for (ShaderVariant* variant = module->variants; variant;) {
        ShaderVariant* next = variant->next;
        vulkanWrapper.vkDestroyShaderModule(device, variant->module, NULL);
        free(variant->key); free(variant); variant = next;
    }
    if (module->module) vulkanWrapper.vkDestroyShaderModule(device, module->module, NULL);
    free(module->code); free(module);
    pthread_mutex_unlock(&shaderModuleMutex);
}

bool isFormatScaled(VkFormat format) {
    switch (format) {
        case VK_FORMAT_R8_USCALED:
        case VK_FORMAT_R8_SSCALED:
        case VK_FORMAT_R8G8_USCALED:
        case VK_FORMAT_R8G8_SSCALED:
        case VK_FORMAT_R8G8B8A8_USCALED:
        case VK_FORMAT_R8G8B8A8_SSCALED:
        case VK_FORMAT_R16_USCALED:
        case VK_FORMAT_R16_SSCALED:
        case VK_FORMAT_R16G16_USCALED:
        case VK_FORMAT_R16G16_SSCALED:
        case VK_FORMAT_R16G16B16A16_USCALED:
        case VK_FORMAT_R16G16B16A16_SSCALED:
            return true;
        default:
            return false;
    }
}
