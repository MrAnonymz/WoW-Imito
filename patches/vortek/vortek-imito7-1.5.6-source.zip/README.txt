WoW Imito 1.5.6: Vortek Vulkan relay and presentation
Guest upstream: https://github.com/brunodev85/vortek/tree/b1730c5
Host integration: Winlator and WoW Mobile. Original notices and LGPL-2.1 are included.
Build the paired guest and host from the revision 7 protocol. The host directory
contains the Android CMake target and the adjoining texture consumer and probe.
The guest build record identifies the source revision and changed inputs.
packaged-result.json identifies the signed APK, guest relay, host renderer and
texture consumer. The application build applies its public identifier substitutions.

Changes include bounded extension enumeration with retry, packet sizes for driver
names and descriptions, capability-checked SYNC_FD export, explicit ownership and
synchronization when copying a guest image into a shared Android buffer, reuse of
completed command buffers, and capability detection for importing fresh DMA buffers.
